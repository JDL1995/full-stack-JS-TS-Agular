# Summary

Date : 2021-12-21 20:02:25

Directory /Users/jonathanlathrop/Desktop/Appointment-moving/appointment2/Appointments2 copy/src

Total : 160 files,  6916 codes, 807 comments, 1916 blanks, all 9639 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| TypeScript | 98 | 4,651 | 664 | 917 | 6,232 |
| SCSS | 32 | 1,416 | 126 | 578 | 2,120 |
| HTML | 30 | 849 | 17 | 421 | 1,287 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 160 | 6,916 | 807 | 1,916 | 9,639 |
| app | 151 | 6,693 | 609 | 1,816 | 9,118 |
| app/appointment | 14 | 1,053 | 83 | 141 | 1,277 |
| app/appointment/confirmation-dialog | 4 | 66 | 0 | 13 | 79 |
| app/auth | 30 | 737 | 77 | 166 | 980 |
| app/auth/confirmation | 10 | 73 | 0 | 26 | 99 |
| app/auth/confirmation/reset | 4 | 32 | 0 | 13 | 45 |
| app/auth/forgot | 4 | 116 | 3 | 25 | 144 |
| app/auth/login | 4 | 98 | 0 | 24 | 122 |
| app/auth/signup | 4 | 143 | 26 | 26 | 195 |
| app/console | 44 | 2,955 | 347 | 585 | 3,887 |
| app/console/action-dialog | 4 | 58 | 0 | 14 | 72 |
| app/console/console | 5 | 128 | 60 | 26 | 214 |
| app/console/custom-paginator | 5 | 178 | 1 | 48 | 227 |
| app/console/edit | 4 | 190 | 61 | 34 | 285 |
| app/console/finish | 4 | 112 | 5 | 28 | 145 |
| app/console/invoice-dialog | 4 | 60 | 0 | 15 | 75 |
| app/console/mainService | 2 | 336 | 49 | 64 | 449 |
| app/console/payments | 4 | 255 | 8 | 51 | 314 |
| app/console/table | 6 | 1,262 | 134 | 234 | 1,630 |
| app/console/testimonials | 4 | 331 | 28 | 64 | 423 |
| app/error | 5 | 51 | 17 | 19 | 87 |
| app/frontpage | 4 | 217 | 0 | 236 | 453 |
| app/frontpageadmin | 4 | 189 | 0 | 240 | 429 |
| app/header | 4 | 173 | 0 | 206 | 379 |
| app/logout | 4 | 32 | 0 | 13 | 45 |
| app/payment | 9 | 373 | 36 | 57 | 466 |
| app/payment/payment-page | 5 | 249 | 20 | 34 | 303 |
| app/resize | 1 | 31 | 5 | 7 | 43 |
| app/success | 4 | 48 | 1 | 13 | 62 |
| app/testimonials | 19 | 600 | 35 | 107 | 742 |
| app/testimonials/basic-dialog | 4 | 57 | 0 | 13 | 70 |
| app/testimonials/make | 9 | 396 | 24 | 71 | 491 |
| app/testimonials/make/selector | 5 | 131 | 15 | 20 | 166 |
| environments | 2 | 6 | 11 | 4 | 21 |
| sass | 2 | 145 | 126 | 74 | 345 |
| sass/base | 1 | 143 | 126 | 73 | 342 |

[details](details.md)