# Summary

Date : 2021-12-21 20:19:36

Directory /Users/jonathanlathrop/Desktop/Appointment-moving/appointment2/Appointments2 copy/backend

Total : 46 files,  5094 codes, 188 comments, 355 blanks, all 5637 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 2 | 3,103 | 0 | 2 | 3,105 |
| JavaScript | 42 | 1,974 | 188 | 351 | 2,513 |
| HTML | 1 | 16 | 0 | 2 | 18 |
| CSS | 1 | 1 | 0 | 0 | 1 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 46 | 5,094 | 188 | 355 | 5,637 |
| angular | 8 | 152 | 8 | 17 | 177 |
| angular/assets | 1 | 130 | 5 | 15 | 150 |
| controllers | 6 | 1,465 | 144 | 201 | 1,810 |
| middleware | 3 | 40 | 5 | 11 | 56 |
| models | 16 | 142 | 0 | 45 | 187 |
| routes | 9 | 99 | 12 | 58 | 169 |

[details](details.md)