# Details

Date : 2021-12-21 20:19:36

Directory /Users/jonathanlathrop/Desktop/Appointment-moving/appointment2/Appointments2 copy/backend

Total : 46 files,  5094 codes, 188 comments, 355 blanks, all 5637 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [backend/angular/5.3bc6e82a6b4d1df9c9c0.js](/backend/angular/5.3bc6e82a6b4d1df9c9c0.js) | JavaScript | 1 | 0 | 0 | 1 |
| [backend/angular/assets/graph.js](/backend/angular/assets/graph.js) | JavaScript | 130 | 5 | 15 | 150 |
| [backend/angular/index.html](/backend/angular/index.html) | HTML | 16 | 0 | 2 | 18 |
| [backend/angular/main.61d6290c17cf7bb0d66e.js](/backend/angular/main.61d6290c17cf7bb0d66e.js) | JavaScript | 1 | 1 | 0 | 2 |
| [backend/angular/polyfills-es5.a721b8b874123d7d422a.js](/backend/angular/polyfills-es5.a721b8b874123d7d422a.js) | JavaScript | 1 | 1 | 0 | 2 |
| [backend/angular/polyfills.d8827e9411c2371410e7.js](/backend/angular/polyfills.d8827e9411c2371410e7.js) | JavaScript | 1 | 1 | 0 | 2 |
| [backend/angular/runtime.7094e2aca620bcd90e94.js](/backend/angular/runtime.7094e2aca620bcd90e94.js) | JavaScript | 1 | 0 | 0 | 1 |
| [backend/angular/styles.97174bcbe81ce28429d1.css](/backend/angular/styles.97174bcbe81ce28429d1.css) | CSS | 1 | 0 | 0 | 1 |
| [backend/app.js](/backend/app.js) | JavaScript | 51 | 17 | 12 | 80 |
| [backend/controllers/admin.js](/backend/controllers/admin.js) | JavaScript | 273 | 34 | 23 | 330 |
| [backend/controllers/date.js](/backend/controllers/date.js) | JavaScript | 36 | 0 | 10 | 46 |
| [backend/controllers/pay.js](/backend/controllers/pay.js) | JavaScript | 168 | 38 | 18 | 224 |
| [backend/controllers/posts.js](/backend/controllers/posts.js) | JavaScript | 583 | 61 | 83 | 727 |
| [backend/controllers/testimonials.js](/backend/controllers/testimonials.js) | JavaScript | 166 | 1 | 32 | 199 |
| [backend/controllers/user.js](/backend/controllers/user.js) | JavaScript | 239 | 10 | 35 | 284 |
| [backend/middleware/check-auth.js](/backend/middleware/check-auth.js) | JavaScript | 12 | 0 | 1 | 13 |
| [backend/middleware/confirmEmail.js](/backend/middleware/confirmEmail.js) | JavaScript | 2 | 5 | 6 | 13 |
| [backend/middleware/file.js](/backend/middleware/file.js) | JavaScript | 26 | 0 | 4 | 30 |
| [backend/models/appointment.js](/backend/models/appointment.js) | JavaScript | 18 | 0 | 4 | 22 |
| [backend/models/blogInfo.js](/backend/models/blogInfo.js) | JavaScript | 6 | 0 | 3 | 9 |
| [backend/models/hero.js](/backend/models/hero.js) | JavaScript | 6 | 0 | 3 | 9 |
| [backend/models/mailVar.js](/backend/models/mailVar.js) | JavaScript | 3 | 0 | 2 | 5 |
| [backend/models/oneTime.js](/backend/models/oneTime.js) | JavaScript | 5 | 0 | 3 | 8 |
| [backend/models/orderlist.js](/backend/models/orderlist.js) | JavaScript | 6 | 0 | 3 | 9 |
| [backend/models/payment.js](/backend/models/payment.js) | JavaScript | 10 | 0 | 3 | 13 |
| [backend/models/pictureBlock.js](/backend/models/pictureBlock.js) | JavaScript | 6 | 0 | 3 | 9 |
| [backend/models/post.js](/backend/models/post.js) | JavaScript | 9 | 0 | 3 | 12 |
| [backend/models/postAdmin.js](/backend/models/postAdmin.js) | JavaScript | 11 | 0 | 3 | 14 |
| [backend/models/postAdminST.js](/backend/models/postAdminST.js) | JavaScript | 11 | 0 | 3 | 14 |
| [backend/models/recordId.js](/backend/models/recordId.js) | JavaScript | 7 | 0 | 3 | 10 |
| [backend/models/testimonial.js](/backend/models/testimonial.js) | JavaScript | 11 | 0 | 3 | 14 |
| [backend/models/tokemeister.js](/backend/models/tokemeister.js) | JavaScript | 8 | 0 | 1 | 9 |
| [backend/models/token.js](/backend/models/token.js) | JavaScript | 10 | 0 | 1 | 11 |
| [backend/models/user.js](/backend/models/user.js) | JavaScript | 15 | 0 | 4 | 19 |
| [backend/package-lock.json](/backend/package-lock.json) | JSON | 3,027 | 0 | 1 | 3,028 |
| [backend/package.json](/backend/package.json) | JSON | 76 | 0 | 1 | 77 |
| [backend/routes/admin.js](/backend/routes/admin.js) | JavaScript | 16 | 0 | 14 | 30 |
| [backend/routes/administrate.js](/backend/routes/administrate.js) | JavaScript | 5 | 2 | 5 | 12 |
| [backend/routes/confirm.js](/backend/routes/confirm.js) | JavaScript | 8 | 0 | 9 | 17 |
| [backend/routes/confirma.js](/backend/routes/confirma.js) | JavaScript | 7 | 2 | 5 | 14 |
| [backend/routes/date.js](/backend/routes/date.js) | JavaScript | 7 | 2 | 6 | 15 |
| [backend/routes/pay.js](/backend/routes/pay.js) | JavaScript | 13 | 0 | 0 | 13 |
| [backend/routes/posts.js](/backend/routes/posts.js) | JavaScript | 18 | 3 | 4 | 25 |
| [backend/routes/testimonials.js](/backend/routes/testimonials.js) | JavaScript | 17 | 2 | 4 | 23 |
| [backend/routes/user.js](/backend/routes/user.js) | JavaScript | 8 | 1 | 11 | 20 |
| [backend/server.js](/backend/server.js) | JavaScript | 42 | 2 | 9 | 53 |

[summary](results.md)