import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { FrontpageAdminComponent } from './frontpageadmin/frontpageAdmin.component';
import { MakeComponent } from './testimonials/make/make.component';

const routes: Routes = [
  { path: "", component: FrontpageComponent },
  { path:"testimonials", loadChildren:()=> import('./testimonials/testimonials.module').then(a=>a.testimonialsModule)},
  { path: "appointments", loadChildren:()=> import('./appointment/appointment.module').then(a=>a.AppointmentModule) },
  { path:"admin/999", component:FrontpageAdminComponent},
  { path: "auth", loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule)},
  {path: "console", loadChildren: () => import('./console/console.module').then(l => l.ConsoleModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
