import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frontpage-admin',
  templateUrl: './frontpageAdmin.component.html',
  styleUrls: ['./frontpageAdmin.component.scss']
})
export class FrontpageAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
