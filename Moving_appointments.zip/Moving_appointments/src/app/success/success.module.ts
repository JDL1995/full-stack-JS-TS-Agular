import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SuccessComponent } from './success.component';
import { AngularMaterialModule } from '../angular-material.module';
import { MatIconModule } from '@angular/material/icon';



@NgModule({
  declarations: [SuccessComponent],
  imports: [
    CommonModule,
    AngularMaterialModule,
    MatIconModule
  ]
})
export class SuccessModule { }
