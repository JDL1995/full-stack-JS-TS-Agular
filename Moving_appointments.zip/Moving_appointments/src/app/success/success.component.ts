import { Component, OnInit, OnDestroy,Input,Inject } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Subscription } from "rxjs";
import {
  MatSnackBarRef,
  MAT_SNACK_BAR_DATA
} from "@angular/material/snack-bar";

import {MatSnackBar
} from '@angular/material/snack-bar';
import { SnackService } from "../auth/snack.service";
import { NgModule } from "@angular/core";



@Component({
    selector: 'snack-bar-component-example-snack',
    templateUrl: 'success.component.html',
    styles: [`
      }
    `],
  })
  export class SuccessComponent implements OnInit {
    constructor(
      public sbRef: MatSnackBarRef<SuccessComponent>,
      @Inject(MAT_SNACK_BAR_DATA) public data:string
    ) {}
    ngOnInit() {
        //this.data=SnackService
    }
  
  }