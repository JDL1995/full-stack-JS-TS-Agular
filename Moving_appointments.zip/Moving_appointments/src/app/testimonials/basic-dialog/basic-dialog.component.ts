import { AfterContentInit, Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AppointmentService } from 'src/app/appointment/appointment.service';

@Component({
  selector: 'app-basic-dialog',
  templateUrl: './basic-dialog.component.html',
  styleUrls: ['./basic-dialog.component.scss']
})
export class BasicDialogComponent implements OnInit, AfterContentInit {
  notLoading=false;

  constructor(public dialogRef: MatDialogRef<BasicDialogComponent>
    ,
    @Inject(MAT_DIALOG_DATA) public data:string) { }
public thisUrl!:string;
  ngOnInit(): void {
    this.thisUrl=this.data;
  }
  ngAfterContentInit(){
    console.log(this.data)
   setTimeout(()=> this.notLoading=true,500);
  }

  onYesClick(): void {
    this.dialogRef.close(true);

  }

}
