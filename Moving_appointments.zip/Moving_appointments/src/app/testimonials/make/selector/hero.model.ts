export interface Hero{
    _id:string,
    img:string
}