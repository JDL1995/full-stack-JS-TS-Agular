import { AfterContentInit, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatProgressSpinnerModule, MatSpinner } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AppointmentService } from 'src/app/appointment/appointment.service';
import { BasicDialogComponent } from '../../basic-dialog/basic-dialog.component';
import { Hero } from './hero.model';

@Component({
  selector: 'app-selector',
  templateUrl: './selector.component.html',
  styleUrls: ['./selector.component.scss']
})
export class SelectorComponent implements OnInit, AfterContentInit {
heroes!:Hero[]
@Output() emitSelected=new EventEmitter<Hero>();
  constructor(public appointmentService:AppointmentService,
    private dialog:MatDialog,
    private snackBar:MatSnackBar) { }
    isLoading=true;
    classChange='visin';
  selected!:Hero;
  public this:{[key:string]:string}={}
    public any!:any;
    public thisUrl!:string;
  ngOnInit(): void {
    this.appointmentService.getHeroes();
    this.appointmentService.getHeroesUpdated().subscribe(heroes=>{
      this.heroes=heroes.heroes
      
      console.log(this.heroes);
    })
  }
  ngAfterContentInit(){
   setTimeout(()=> this.isLoading=false,1000)
   setTimeout(()=> this.classChange='visDun',1000)
  }

  onClose(){
    this.emitSelected.emit(this.selected);
    
  }
  openDialog() 
{
  /*
  this.appointmentService.getAHero(this.selected._id).subscribe(val=>{
    let b = JSON.stringify(val);
    this.this=JSON.parse(b); 
  
    let mcgee=JSON.stringify(this.this.hero);
      /*
    this.any=JSON.parse(mcgee);
    this.thisUrl=this.any._id;


  })*/
  const dialogRef = this.dialog.open(BasicDialogComponent,{data:this.selected.img});
  //const snack = this.snackBar.open('Snack bar open before dialog');

  dialogRef.afterClosed().subscribe((showSnackBar: boolean) => {
    if (showSnackBar) {
     this.onClose();
     // snack.dismiss();
      const a = document.createElement('a');
      a.click();
      a.remove();
     // snack.dismiss();
      this.snackBar.open('Nice Choice!', '', {
        duration: 2000,
      });
    }
  } );}
  tileClicked(id:string){
    
    this.heroes.forEach((value, index) => { 
        if(value._id==id){
          this.selected=value;
        }

    })
    this.openDialog()
  }
  clickCancel(){
    let a:Hero={_id:'close',img:''}
    this.emitSelected.emit(a);
  }


}
