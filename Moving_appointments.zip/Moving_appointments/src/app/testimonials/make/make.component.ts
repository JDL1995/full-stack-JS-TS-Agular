import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, Validators } from '@angular/forms';
import { NgxImageCompressService } from 'ngx-image-compress';
import { formatDate } from '@angular/common';
import { AppointmentService } from 'src/app/appointment/appointment.service';
import { mimeType } from 'src/app/appointment/mime-type.validator';
import { Hero } from './selector/hero.model';
import { MatDialog } from '@angular/material/dialog';
import { BasicDialogComponent } from '../basic-dialog/basic-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-make',
  templateUrl: './make.component.html',
  styleUrls: ['./make.component.scss']
})
export class MakeComponent implements OnInit {
public form2!:FormGroup;
public date!:string;
public noImage=false;
public imageUploaded=false;
public selectedHero!:Hero|undefined;
public imagePreview!:string;
public finished!:boolean;
public openSelector=false;
public ger!:string;
public id!:string;
public reg!:string;
selectedImage:File|undefined=undefined;
public beauxton!:FormGroup;
  constructor(public imageCompress:NgxImageCompressService,
    private appointmentService:AppointmentService,
    private dialog:MatDialog,
    private snackBar:MatSnackBar,
    private route:ActivatedRoute) { }
    public radioVal!:number|undefined;
public clickRadio(event:Event, value:any) {
    event.preventDefault();

    if (! this.radioVal || this.radioVal !== value) {
        this.radioVal = value;
        this.beauxton.patchValue({bouton: this.radioVal});
        return;
    }

    if (this.radioVal === value) {
        this.radioVal = undefined;
        this.beauxton.get('bouton')?.reset();
    }
}
chooser(){
  this.openSelector=true;
}

public isRadioSelected(value:any) {
    return (this.radioVal === value);
}



  ngOnInit(): void {
    this.ger=this.route.snapshot.params['email'];
    this.reg=this.route.snapshot.params['token'];
    this.finished=false;
   
    this.appointmentService.getSingle(this.reg,this.ger).subscribe(val=>{
      let amaha='3982'
      let b = JSON.stringify(val);
      let tis=JSON.parse(b); 
    
      let mcgee=JSON.stringify(tis._id);
      this.id=mcgee
      let woohoo=[...mcgee]
      let eep=woohoo.length;
      let newArray:string[]=[];
      woohoo.forEach((val,index)=>{
        if (index>0 && index<eep-1){
          newArray.push(val)
        }

      })
      let newId=newArray.join("")
      console.log('newId: ',newId)
      console.log(this.id)
      console.log(amaha)
      this.id=newId;
    })
    this.beauxton = new FormGroup({
      bouton: new FormControl('',{})
    })

    this.form2 = new FormGroup({
      
      name: new FormControl('', {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      date: new FormControl('', {
        validators: [Validators.required, Validators.minLength(3)]
      }),datetoggle: new FormControl('', {
        
      }),
      body: new FormControl('', {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      image: new FormControl('', {asyncValidators: [mimeType]
      }),
    
    })
    this.form2.get("pictureToggle")?.valueChanges.subscribe(x => {
      this.noImage=true;
   })
  }
  runDaHeroes(){
    this.appointmentService.runTheHeroes().subscribe(val=>{
      console.log(val)
    })

  }
  submit2(){
    console.log('racism');
    this.date='your gay'
    console.log(this.form2.value.name);
    console.log(this.form2.value.body);
    console.log(this.selectedHero?.img);
    console.log(this.date);
    this.appointmentService.postTestimonialWithHero(this.id,this.form2.value.name,this.form2.value.body,this.date,this.selectedHero!.img).subscribe(response=>{
      console.log(response)
     })
  }
  submitter(){
    if(this.form2.value.datetoggle=='yes'){
      const locale = 'en-US';
      let a= new Date();
      this.date=formatDate(a, 'short', locale);
    }
    else{
      this.date='nodate'
    }
    if(this.selectedHero!=undefined && this.selectedHero._id !='close'){
     this.appointmentService.postTestimonialWithHero(this.id,this.form2.value.name,this.form2.value.body,this.date,this.selectedHero.img).subscribe(response=>{
      let b = JSON.stringify(response);
      var bis=JSON.parse(b); 
    
      let mcgee=JSON.stringify(bis.message);
        /**/
      let any=JSON.parse(mcgee);
      console.log(any)
      
      if(any=='success'){
        this.finished=true;
      }
      console.log(response)
     })
    }
   if(this.beauxton.value.bouton==1 && this.beauxton.value.bouton!=undefined){
      this.appointmentService.postTestimonial(this.id,this.form2.value.name,this.form2.value.body,this.date).subscribe(response=>{

        let b = JSON.stringify(response);
        var bis=JSON.parse(b); 
      
        let mcgee=JSON.stringify(bis.message);
          /**/
        let any=JSON.parse(mcgee);
        console.log(any)
        
        if(any=='success'){
          this.finished=true;
        }

      })}
    else if(this.imageUploaded==true){
      console.log(this.selectedImage);
      
        this.appointmentService.postTestimonialWithImage(this.id,this.form2.value.name,this.form2.value.body,this.date,this.selectedImage!).then(val=>{
          if(val.message=='success'){
            this.finished=true;
          }
        })
      }
    
   // this.appointmentService.postTestimonial(this.form2.value.name,this.date)
  }
  heroSelected(event:Hero){
    if(event._id=='close'){
      this.openSelector=false;
      this.imageUploaded=false;
    }
    else{
    this.selectedHero=event;
      this.openSelector=false;
      this.imagePreview=this.selectedHero.img;
  }
  
  }
  compressFile() {
    this.imageUploaded=true;
    this.selectedHero=undefined;
    this.imageCompress.uploadFile().then(({image, orientation}) => {
  
     
      console.log('Size in bytes was:', this.imageCompress.byteCount(image));
      
      this.imageCompress.compressFile(image, orientation, 50, 50).then(
        result => {
         
         
          console.log('size in bytes is now',this.imageCompress.byteCount(result))
  const file0 = result as unknown as File;
 // this.compressFile(file0,this.uploadCount)

 

  const reader = new FileReader();
  reader.onload = () => {
    this.imagePreview = reader.result as string;
    
  };
  const file2=this.dataURItoBlob(result as unknown as string); 
  this.selectedImage=file2 as unknown as File;
  reader.readAsDataURL(file2);
  
        })
      })
      
      }
      dataURItoBlob(dataURI:string) {
        // convert base64 to raw binary data held in a string
        var byteString = atob(dataURI.split(',')[1]);
    
        // separate out the mime component
        var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    
        // write the bytes of the string to an ArrayBuffer
        var arrayBuffer = new ArrayBuffer(byteString.length);
        var _ia = new Uint8Array(arrayBuffer);
        for (var i = 0; i < byteString.length; i++) {
            _ia[i] = byteString.charCodeAt(i);
        }
    
        var dataView = new DataView(arrayBuffer);
        var blob = new Blob([dataView], { type: mimeString });
        return blob;
    }
    public blobToFile = (theBlob: Blob): File => {
      var b: any = theBlob;
      //A Blob() is almost a File() - it's just missing the two properties below which we will add
      b.lastModifiedDate = new Date();
     
  
      //Cast to a File() type
      return <File>theBlob;
  }
}
