import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//import { TableComponent } from './table/table.component';
//import { CustomPaginatorComponent } from './custom-paginator/custom-paginator.component';
////import { EditComponent } from './edit/edit.component';
//import { ActionDialog } from './action-dialog/action-dialog.component';
import { AngularMaterialModule } from '../angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTable, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
//import { ConsoleComponent } from './console/console.component';
import { MatDialogModule } from '@angular/material/dialog';
import { Router, RouterModule } from '@angular/router';
//import { ConsoleRoutingModule } from './console-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from '../auth/auth-interceptor';
//import { FinishComponent } from './finish/finish.component';
//import { InvoiceDialogComponent } from './invoice-dialog/invoice-dialog.component';
//import { TestimonialsComponeent } from './testimonials/testimonials.component';
import { TestimonialsComponent } from './testimonials.component';
import { MakeComponent } from './make/make.component';
import { SelectorComponent } from './make/selector/selector.component';
import { TestimonialsRoutingModule } from './testimonials-routing.module';
import { NgxImageCompressService } from 'ngx-image-compress';
import { BasicDialogComponent } from './basic-dialog/basic-dialog.component';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule, MatSpinner } from '@angular/material/progress-spinner';



@NgModule({
  declarations: [TestimonialsComponent,MakeComponent,SelectorComponent, BasicDialogComponent],
  imports: [
    CommonModule,AngularMaterialModule,FormsModule,ReactiveFormsModule,MatTableModule,MatSortModule,MatDialogModule,RouterModule,TestimonialsRoutingModule
  ],
  providers:[NgxImageCompressService]
})
export class testimonialsModule { }
