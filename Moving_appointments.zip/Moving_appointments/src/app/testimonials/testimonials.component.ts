import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../appointment/appointment.service';
import { Testimonial } from '../appointment/testimonial.model';

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.scss']
})
export class TestimonialsComponent implements OnInit {

  constructor(private mainService:AppointmentService) { }
  public testimonials:Testimonial[]=[];
  ngOnInit(): void {
    this.mainService.getTestimonials();
    this.mainService.getTestimonialsUpdateListener().subscribe(testimonials=>{
      this.testimonials=testimonials.testimonials;
    })
   

  }
  datified(da:string){
    console.log(da)
    if(da=='nodate'){
      return false
    }
    else{
      return true
    }
      
  }
  img(da:string){
    if(da==''){
      return false
    }
    else{
      return true
    }
  }

}
