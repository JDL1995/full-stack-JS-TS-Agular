import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "src/app/auth/auth.guard";
import { MakeComponent } from './make/make.component';
import { TestimonialsComponent } from './testimonials.component';
//import { ConsoleComponent } from './console/console.component';

//import { SignupComponent } from "./signup/signup.component";

const routes: Routes = [
  { path: "", component: TestimonialsComponent  },
  {path:"make/:token/:email",component:MakeComponent }

];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  providers:[AuthGuard]
})
export class TestimonialsRoutingModule {}