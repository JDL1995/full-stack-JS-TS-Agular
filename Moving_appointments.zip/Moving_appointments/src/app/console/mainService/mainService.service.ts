import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { map } from "rxjs/operators";
import { Router } from "@angular/router";
import { FormattedAppointment, FormattedAppointment2, FormattedAppointment3 } from "src/app/formattedAppointment.model"
//import { Post } from "./posts/post.model";

//import { stringToKeyValue } from "@angular/flex-layout/extended/typings/style/style-transforms";
//import { AuthData } from "../auth/auth-data.model";
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { domain } from 'process';
import { _MatDialogContainerBase } from '@angular/material/dialog';
import { formatDate } from '@angular/common';
import { _DisposeViewRepeaterStrategy } from '@angular/cdk/collections';
import { Appointment, transfer } from 'src/app/appointment/appointment.model';
import { payment } from './payment.model';
const appointment_url =  "http://localhost:3000/api/appointments";
const admin_url = "http://localhost:3000/admin/console";
const appointment_confirm_url="http://localhost:3000/api/confirm"
//const sendBackR="http://localhost:3000/admin/reset/resetit";
//const setBackR="http://localhost:3000/users/reset/confirmit";
@Injectable({ providedIn: "root" })
export class MainService {

    public postedata:any;
  private store:transfer={name:'',from:'',to:'',date:'',phone:1,email:''};
  private token!:string;
  public confirmationInfo = new BehaviorSubject<transfer>(this.store);
  private email!:string;
  private appointmentCountUpdated = new Subject<{ count:number}>();
  public appointmentSubject = new BehaviorSubject<FormattedAppointment2[]>([]);
  public dates = new BehaviorSubject<string[]>([]);
  public ideer = new BehaviorSubject<string>('');
  private paymentsUpdated = new Subject<{ payments: payment[]}>();
  private appointmentsUpdated = new Subject<{ appointments: FormattedAppointment[]}>();
  public appointments!:FormattedAppointment[];
  public posting=new Subject();
  public dooting=new Subject();
  public refresh=new Subject();
  public refresh2=new Subject();
  public zang!:Date;
  dee!:FormattedAppointment3;
  public payments!:payment[]

  public selectedAppointment=new BehaviorSubject<FormattedAppointment3>(this.dee);
  //private posts: Post[] = [];
  //private postsUpdated = new Subject<{ posts: Post[]; postCount: number }>();
  public newUrl!:string;
  constructor(private http: HttpClient, private router: Router) {}


  submitConfirm(id:number,body:string){
    console.log(id);
    console.log(body);
    let mcgee={_id:id,bady:body}
    const postData= new FormData();
    postData.append("_id", id.toString());
    postData.append("body", body);
    return this.http.post(appointment_confirm_url,mcgee)}


  async signalGo(data:FormattedAppointment[]){
    console.log(data);
    this.transformFormat(data).then(val=>{
      this.appointmentSubject.next(val);
      console.log(val);
 this.dooting.next();})}


  async transformFormat(app:FormattedAppointment[]):Promise<FormattedAppointment2[]>{
    console.log(app);
   let newAppointment:FormattedAppointment2;
   let raturn:Promise<FormattedAppointment2[]>;
   let newAppointments:FormattedAppointment2[]=[];
   let bal=app.length;
    let z=await this.pusher(app).then((val)=>{
    return this.combinate(app,val).then(val=>{
      newAppointments= val;
    let a=newAppointments;
    var mcgee =new Promise<FormattedAppointment2[]>((resolve,reject)=>{
      resolve (newAppointments)});
    return mcgee;})})
   var mcgee2 =new Promise<FormattedAppointment2[]>((resolve,reject)=>{
     let dang=z;
     resolve(dang);})
   return mcgee2;
  }


  async pusher(app:FormattedAppointment[]){
    let damn:string[]=[];
    for(let appl of app){ let a= Object.keys(appl);let b=Object.entries(appl);
     let a1=undefined;let a2=undefined;
        for (let ba of b){
            if(ba[0]=='date'){a1=ba[1];}
            if(ba[0]=='time'){a2=ba[1];}
            if(a1 && a2){let za=a1+", ".concat(a2);
           console.log(za);
           damn.push(za);}}}return damn;}


  async combinate(app:FormattedAppointment[],date:string[]){
    let newAppointments:FormattedAppointment2[]=[];
    for(let [index,appl] of app.entries()){
      let a= Object.keys(appl);
      //console.log(a);

        let b=Object.entries(appl);
       let a1=undefined;
        let a2=undefined;
        for(let [index, i] of a.entries()){


        }
        let dayme=new Date(date[index]);


        let newAppointment:FormattedAppointment2={_id:b[0][1],name:b[1][1],number:b[6][1],email:b[2][1],date:dayme,contactType:b[5][1],fromAddress:b[7][1],toAddress:b[8][1],additionalInfo:b[9][1],confirmed:b[10][1],completed:b[11][1],cancelled:b[12][1],paid:b[13][1]}
          newAppointments.push(newAppointment);
    }
    return newAppointments;

  }
  updateAppointment(appointment:FormattedAppointment2){
    const locale = 'en-US';
    console.log(appointment);
    const queryParams = `?_id=${appointment._id}`;
    let formattedDate = formatDate(appointment.date, 'shortDate', locale);
    let formattedTime = formatDate(appointment.date, 'shortTime', locale);


    const postData= new FormData();
    const postInfo={_id:appointment._id,name:appointment.name,phone:appointment.number,email:appointment.email,date:formattedDate,time:formattedTime,confirmed:appointment.confirmed.toString(),
    completed:appointment.completed.toString(),from:appointment.fromAddress,to:appointment.toAddress,contactType:appointment.contactType,additionalInfo:appointment.additionalInfo}
    postData.append("_id",appointment._id.toString());
    postData.append("name", appointment.name);
    postData.append("phone",appointment.number.toString());
    postData.append("email",appointment.email);
    //postData.append("contactType",appointment.month.toString());
    postData.append("date",formattedDate);
    postData.append("time",formattedTime);
    postData.append("confirmed",appointment.confirmed.toString());
    postData.append("completed",appointment.completed.toString());
    postData.append("from",appointment.fromAddress);
    postData.append("to",appointment.toAddress);
    //postData.append("morningNight",appointment.morningNight);
    postData.append("contactType",appointment.contactType);
    postData.append("additionalInfo",appointment.additionalInfo);
    //for(var pair of postData.entries()) {    console.log(pair[0]+ ', '+ pair[1]); }
    return this.http.put(
        appointment_url,
        postInfo
      )


  }
  submitAppointment0(appointment:Appointment,files:File[]){
    this.submitAppointment(appointment).subscribe((response)=>{
        console.log(response);
      let z = JSON.stringify(response);
      let dang:{[key:string]:string}
      dang=JSON.parse(z);
      console.log(dang['a']);
          let amen= dang['a'];


        let meeng=files.length
        let productIds:number[]=[];
        for(let a=0; a<meeng;a++){
          productIds.push(a)
        }
        console.log(productIds)
        let loop = (id: number) => {

          this.uploadFile(+amen,files[id])
            .subscribe((result) => {
              console.log(result);
              // This logic can be modified to any way you want if you don't want to mutate the `producIds` array
              if (productIds.length>0) {
                console.log(productIds)
                setTimeout(() =>  100);
                loop(productIds.shift()!)
              }
            })
        }

        loop(productIds.shift()!)



        //this.uploadFiles(+val,files);




    })




  }
  getPayments():Promise<boolean>{
    this.http.get<{payment:any}>('http://localhost:3000/api/appointments/payments') .pipe(
      map(postData => {
        this.postedata=postData;

        if(this.postedata.payment){
        return {
          payments: postData.payment.map((_payment: {email: any; amount: any; paid:boolean; }) => {

            return {
              email: _payment.email,
              amount:_payment.amount,
              status:_payment.paid
            };
          })

        };}
        else{
          return{
            email:"not available",
            amount:"not available",
                status:"not available",
                  }}
     })
    )
    .subscribe(transformedPostData => {
      if(transformedPostData.payments){
      this.payments = transformedPostData.payments;

      this.paymentsUpdated.next({
        payments: [...this.payments]
      });
    }});
    return new Promise((resolve, reject) => { resolve(true); })
  }

  getPhotos(id:number){
    const queryParams = `?_id=${id}`;

    return this.http.get<{message:string;photos:string[]}>(appointment_url+"/photos/"+queryParams);
  }


  uploadFile(a:number,file:File){
    const postData=new FormData();
    //console.log(x);
    console.log(a);
    postData.append("a", a.toString());
    postData.append("image", file);
    return this.http.post(
      appointment_url+"/photos",
      postData
    )

  }
  /*  uploadFiles(a:number,files:File[]){
    let top:number;
    if(files){
      console.log('files exist');
      console.log(files.length);
      top=+files.length;
    }
    let x=0;
    this.uploadFile(a,x,files).subscribe((response)=>{
      x=x+1
        console.log(response)
        if(x<top){
          this.uploadFile(a,x,files);

        }
      })


   };
 */
cancelAppointment(_id:number){
  var body ={_id:_id}
  return this.http.post(appointment_url+'/cancel',body);
}
completeAppointment(_id:number){
  var body ={_id:_id}
  return this.http.post(appointment_url+'/complete1',body);
}
   submitAppointment(appointment:Appointment){

    console.log(appointment.email);
    let a=Object.keys(appointment).length;
    let daz=Object.entries(appointment);
    var alabamaMan:{[key:string]:string}={};
    console.log(a);
    let d=Object.keys(appointment);
    for (let y of d){
      for (let maz of daz){
        if (maz[0]==y){
          alabamaMan[y]=maz[1];
          console.log(maz[1])
        }
      }

    }

    console.log(alabamaMan);

    const postData = new FormData();


 // postData.append("image",files2);
    postData.append("name", appointment.name);
    postData.append("phone",appointment.phone.toString());
    postData.append("email",'sooo long gaybooooysss!!');
    postData.append("month",appointment.month.toString());
    postData.append("day",appointment.day.toString());
    postData.append("year",appointment.year.toString());
    postData.append("hour",appointment.hour.toString());
    postData.append("minute",appointment.minute.toString());
    postData.append("from",appointment.addressFrom);
    postData.append("to",appointment.addressTo);
    postData.append("morningNight",appointment.morningNight);
    postData.append("contactType",appointment.contactType);
    postData.append("additionalInfo",appointment.additionalInfo);

    return this.http.post(
        appointment_url,
        alabamaMan
      )
    /*
    .subscribe(response=>{
      console.log(response);
    let z = JSON.stringify(response);
    let dang:{[key:string]:string}
    dang=JSON.parse(z);
    console.log(dang['a']);


        let amen= dang['a'];
        this.ideer.next(amen);

    });
    */



  }
  getAppointments():Promise<boolean> {
    this.http
      .get<{ message: string; appointments: any; count:number  }>(
        appointment_url
      )
      .pipe(
        map(postData => {
          this.postedata=postData;
          this.appointmentCountUpdated.next({count:postData.count})
          if(this.postedata.appointments){
          return {
            appointments: postData.appointments.map((_appointment: {_id:number; name: any; email: any; date: any; time: any; contactType: any; number: any; fromAddress: any; toAddress: any; additionalInfo: any; confirmed:boolean,completed:boolean,cancelled:boolean,paid:boolean }) => {
              return {
                _id:_appointment._id,
                name:_appointment.name,
                email: _appointment.email,
                date:_appointment.date,
                time:_appointment.time,
                contactType:_appointment.contactType,
                number: _appointment.number,
                fromAddress: _appointment.fromAddress,
                toAddress: _appointment.toAddress,
                additionalInfo:_appointment.additionalInfo,
                confirmed:_appointment.confirmed,
                completed:_appointment.completed,
                cancelled:_appointment.cancelled,
                paid:_appointment.paid
              };
            })

          };}
          else{
            return{
              name:"not available",
              date:"not available",
                  time:"not available",
                      email:"not available",
                      contactType:"not available",
                    fromAddress:"not available",
                  toAddress:'not available',
                aditionalInfo:'not available',
                number:'not available'}}
        })
      )
      .subscribe(transformedPostData => {
        if(transformedPostData.appointments){
        this.appointments = transformedPostData.appointments;

        this.appointmentsUpdated.next({
          appointments: [...this.appointments]
        });
      }});
      return new Promise((resolve, reject) => { resolve(true); })
  }

  getAppointmentsUpdateListener() {
    return this.appointmentsUpdated.asObservable();
  }
  getPaymentsUpdateListener() {
    return this.paymentsUpdated.asObservable();
  }
  getAppointmentCountUpdateListener() {
    return this.appointmentCountUpdated.asObservable();
  }
  getSelectedListener() {
    return this.selectedAppointment.asObservable();
  }
  setPaid(_id:number){
    let a={_id:_id}
    return this.http.post('http://localhost:3000/api/appointments/setpaid',a)
  }
 getAppointment(_id:number){
var a={_id:_id};
const queryParams = `?_id=${_id}`;
   return this.http.get<{appointment:FormattedAppointment}>('http://localhost:3000/api/getOne/appointment/'+queryParams);

 }
 sendInvoice(price:number,_id:number,body:string,date:string,address:string,email:string){
  var a={price:price,_id:_id,body:body,date:date,address:address,email:email};
   return this.http.post('http://localhost:3000/api/pay/gorilla',a)
 }
 getDates(){
   console.log('doing anal')
   this.http.get<{message:string;list:string[]}>('http://localhost:3000/dates').pipe(
    map(postData => {
      return postData
    })

    ).subscribe(val=>{
      this.dates.next(val.list);
      console.log(val);
    })
}
getDatesObs() {
  return this.dates.asObservable();
}
}
