export interface payment{
  email:string,
  amount:string,
  status:boolean
}
