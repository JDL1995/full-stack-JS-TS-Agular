import { DataSource } from '@angular/cdk/table';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTable } from '@angular/material/table';
import { Observable, of } from 'rxjs';
import { AppointmentService } from 'src/app/appointment/appointment.service';
import { MainService } from '../mainService/mainService.service';
import { payment } from '../mainService/payment.model';
import { PageVent } from '../table/pageVent.model';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss']
})
export class PaymentsComponent implements OnInit {
  expandedElement: any;
  photosToggled=false;
  constructor(public appService:AppointmentService,public mainService:MainService) { }
  public pageIndex!:number;
  totalNum!:number;
 // displayedColumns2=['Name','Date','Status']
  pagesize=50;
 openPaginator=false;
  public dataTableElements!:payment[];
  public idear=0;
  public idList:string[]=[];
  public ah!:ExampleDataSource3;
  @ViewChild('table')
  table!: MatTable<payment>;
  public displayedColumns2=['Email','Amount', 'Status'];
public payments!:payment[];
  ngOnInit(): void {
    this.mainService.getPayments();
    this.mainService.getPaymentsUpdateListener().subscribe(payments=>{
      this.dataTableElements=payments.payments;
      this.totalNum=this.dataTableElements.length;
    })
    let ah=new ExampleDataSource3;
    //this.table.dataSource=this.ah;
    setTimeout(()=> console.log(this.payments),500);
    setTimeout(()=> ah.setdata(this.dataTableElements),250);
    setTimeout(()=> this.ah=ah,350);
    setTimeout(()=> this.table.renderRows(),650);




  }

  refresh(){
    this.mainService.getPayments();
    this.mainService.getPaymentsUpdateListener().subscribe(payments=>{
      this.dataTableElements=payments.payments;
      this.totalNum=this.dataTableElements.length;
    })
    let ah=new ExampleDataSource3;
    //this.table.dataSource=this.ah;
    setTimeout(()=> console.log(this.payments),500);
    setTimeout(()=> ah.setdata(this.dataTableElements),250);
    setTimeout(()=> this.ah=ah,350);
    setTimeout(()=> this.table.renderRows(),650);



  }

isPaid(status:boolean){
  if(status==true){
    return true
  }
  else{
    return false
  }

}

  onPageFired(event:PageVent){
    let yeem:payment[]=[];
  console.log('yeem')
  this.pagesize=event.pageSize;
  this.pageIndex=event.pageIndex;
  console.log('pageIndex: '+event.pageIndex+' pageSize: '+event.pageSize);
    this.dataTableElements.forEach((value, index) => {
      if(event.pageIndex==0){ console.log('event pageindex registered as equal to 1');
        if(index<event.pageSize){console.log('pushing index < event.pagesize');
          yeem.push(value); }}
      if (event.pageIndex==1){
        if (index>event.pageSize && index <= event.pageSize*2){
          yeem.push(value);
        }}
      if (event.pageIndex>1){
        console.log('event pageIndex registered as greater than one');
        if(index>(event.pageSize*(event.pageIndex)) && index<=(event.pageSize*(event.pageIndex+1))){
          yeem.push(value);
        }}})
    let ah = new ExampleDataSource3;
  // then you can assign data to your dataSource like so
  ah.setdata(yeem);
  this.ah=ah;
  this.table.renderRows();
}
}


export class ExampleDataSource3 extends DataSource<any> {

  data:payment[]=[];
 setdata(payment:payment[]){
   this.data=payment;}
 /** Connect function called by the table to retrieve one stream containing the data to render. */
 connect(): Observable<payment[]> {
   const rows:any = [];
   this.data.forEach(element => rows.push(element));
   console.log(rows);
   return of(rows);}
 disconnect() { }}
