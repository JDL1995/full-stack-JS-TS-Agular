

import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, Subject, Subscription } from 'rxjs';
//import { DataSetService } from 'src/app/data-set-service/dataSet.service';
import { Appointment } from 'src/app/appointment/appointment.model';
import { FormattedAppointment, FormattedAppointment2, FormattedAppointment3 } from 'src/app/formattedAppointment.model';
import { MainService } from 'src/app/console/mainService/mainService.service';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
public form2!:FormGroup;
appointment!:Appointment;
currentOh!:string;
showingForm:boolean=false;
  constructor(
    private mainService:MainService) {

  }
  @Output() pageEvent=new EventEmitter<Close2Event>();
  isLoading=false;
 curid!:number;
 curname!:string;
 curemail!:string;
 curdate!:Date;
 curFrom!:string;
 confirmed!:boolean;
 completed!:boolean;
 curTo!:string;
 curAdditional!:string;
 curNumber!:number;
 curContactType!:string;
paid!:boolean;

  isEdit=true;
  closeClicked(){
    let a:Close2Event={go:true,refresh:false}
    this.pageEvent.emit(a)
  }
  ngOnInit(): void {
    this.mainService.selectedAppointment.subscribe(app=>{
      this.curid=app._id;
      this.curname=app.name;
      this.curemail=app.email;
      this.curNumber=app.number;
      this.curdate=app.date;
      this.curFrom=app.fromAddress;
      this.curTo=app.toAddress;
      this.curAdditional=app.additionalInfo;
      this.curContactType=app.contactType;
      this.paid=app.paid;
      if(app.confirmed){
      this.confirmed=app.confirmed;}
      else{this.confirmed=false;}
      if(app.completed){
      this.completed=app.completed;
      }
      else{this.completed=false;}

    })
    this.form2 = new FormGroup({

      name: new FormControl(this.curname, {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      number: new FormControl(this.curNumber, {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      email: new FormControl(this.curemail, {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      date: new FormControl(this.curdate, {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      from: new FormControl(this.curFrom, {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      to: new FormControl(this.curTo, {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      additionalInfo: new FormControl(this.curAdditional, {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      contactType: new FormControl(this.curContactType, {
      }),
    })


      this.showingForm=true;





  }

goBack(){
  this.showingForm=false;
}


  onEditInit(){
    /*
    console.log(this.curlname);
    this.form2 = new FormGroup({
      lastName: new FormControl(this.curlname, {
        validators: [Validators.required, Validators.minLength(3)]
      }),firstName: new FormControl(this.curfname, {
        validators: [Validators.required, Validators.minLength(3)]
      }),email: new FormControl(this.curemail, {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      job: new FormControl(this.curjob, {
        validators: [Validators.required, Validators.minLength(3)]
      })
    })
*/
  }
onUpdate(){
  let d:FormattedAppointment2={
    _id:this.curid,
    name:this.form2.value.name,
    number:this.form2.value.number,
    email:this.form2.value.email,
    date:this.form2.value.date,
    contactType:this.form2.value.contactType,
    fromAddress:this.form2.value.from,
    toAddress:this.form2.value.to,
    additionalInfo:this.form2.value.additionalInfo,
    confirmed:this.confirmed,
    completed:this.completed,
    cancelled:false,
    paid:this.paid
  }

  this.mainService.updateAppointment(d).subscribe(val=>{
    console.log(val);
    //this.mainService.refresh.next();
    let a:Close2Event={go:true,refresh:true}
    this.pageEvent.emit(a)
    //location.reload();
  })

}
/*
onUpdate(){
let items:string[]=[];
let replacements:string[]=[];
items.push(this.curemail!);
if(this.form2.value.email!=this.curemail){
  items.push()
  replacements.push(this.form2.value.email)
}
if(this.form2.value.lastName!=this.curlname){
  items.push()
  replacements.push(this.form2.value.lastName)
}
if(this.form2.value.firstname!=this.curfname){
  items.push()
  replacements.push(this.form2.value.firstName)
}
if(this.form2.value.job!=this.curjob){
  items.push(this.curjob!)
  replacements.push(this.form2.value.job)
}



  this.dss.updatePython(this.currentOh,items,replacements)

}


  editRow(id:number){
    for(let d of this.list){
      if (d.id==id){
        this.curid=d.id;
        this.curlname=d.lastname;
        this.curfname=d.firstname;
        this.curemail=d.email;
        this.curjob=d.job;
        this.initrow=true;
      }

    }

  }*/

}
export interface Close2Event{
  go:boolean;
  refresh:boolean;
}

