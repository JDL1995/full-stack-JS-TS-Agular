import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MainService } from '../mainService/mainService.service';

@Component({
  selector: 'app-action-dialog',
  templateUrl: './action-dialog.component.html',
  styleUrls: ['./action-dialog.component.scss']
})
export class ActionDialog implements OnInit{

  public confirmed!:boolean;
  public completed!:boolean;
  constructor(
    public dialogRef: MatDialogRef<ActionDialog>,
    public mainService:MainService,
    @Inject(MAT_DIALOG_DATA) public data:boolean) { }

    ngOnInit(){
      this.confirmed=this.data;
      
    }
  onConfirmClick(): void {
    this.dialogRef.close('confirm');
  }
  onCompleteClick():void{
    this.dialogRef.close('complete');
  }
  onCancelClick():void{
    this.dialogRef.close('cancel');
  }
onInvoiceClick():void{
  this.dialogRef.close('invoice');
}
}