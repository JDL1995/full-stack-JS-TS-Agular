import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { PageEvent } from '@angular/material/paginator';
import { Subject } from 'rxjs';
import { PageVent } from '../table/pageVent.model';
import { sortieService } from './sortieService.service';

@Component({
  selector: 'app-custom-paginator',
  templateUrl: './custom-paginator.component.html',
  styleUrls: ['./custom-paginator.component.scss']
})
export class CustomPaginatorComponent implements OnInit {
  public a:PageVent= new PageEvent();
    constructor(public sortieservice:sortieService) { 
      sortieservice.sortIssuance.subscribe(val=>{
        
        this.pageIndex=0;
        this.isFirst=true;
      })
    }
    @Output() pageEvent=new EventEmitter<PageVent>();
    @Input() pageSize!:number;
    @Input() pageIndex!:number;
    @Input() pageSizeOptions!:number[];
    @Input() numOfItems!:number;
    public selectedPageSize!:number;
   public totalPages!:number;
   isLast!:boolean;
   isFirst!:boolean;
   public selectedCountry=10;
  
   public form!:FormGroup;
    public pageevent:{[key:string]:number}={}
   // bagelstein!:EventEmitter;
  
    optionsSelected(sta:number){
      console.log('the total number of items is '+this.numOfItems);

      this.totalPages=Math.ceil(this.numOfItems/sta);
      console.log('total pages is '+this.totalPages);
      console.log(this.selectedCountry);
      setTimeout(() => this.a.pageSize=this.selectedCountry,200);
  
      setTimeout(() => this.pageEvent.emit(this.a),300)
  
      
      console.log('selected '+sta+' items per page')
    }
    
    async pageSizer(){
  
    }
   changePageSize(){
  this.a.pageSize=this.pageSize;
   }
  hasSortted = new Subject()
  isLastPage(){
    if(this.pageIndex==this.totalPages-1){
      return true;
  
    }
    else{return false}
    {
  
    }
  }
  isFirstPage(){
    if(this.pageIndex==0){
      return true;
  
    }
    else{return false}
    {
  
    }
  }
    ngOnInit(): void {
     this.form = new FormGroup({
        
       options:new FormControl(this.pageSizeOptions[1])
      })
      this.isFirst=this.isFirstPage();
      this.totalPages=Math.ceil(this.numOfItems/this.pageSize);
      this.isLast=this.isLastPage();
      this.a.pageIndex=this.pageIndex;
      this.a.pageSize=this.pageSize;
      this.a
  
    }
    leftClick(){
  this.a.pageIndex=this.pageIndex-1;
  this.pageIndex=this.pageIndex-1;
  this.isFirst=this.isFirstPage();
  this.isLast=this.isLastPage();
  this.pageEvent.emit(this.a)
  
  
    }
    rightClick(){
      this.a.pageIndex=this.pageIndex+1;
      this.pageIndex=this.pageIndex+1;
      this.isFirst=this.isFirstPage();
      this.isLast=this.isLastPage();
      this.pageEvent.emit(this.a)
    }
    changeTotal(){
  
    }
  
  }
  