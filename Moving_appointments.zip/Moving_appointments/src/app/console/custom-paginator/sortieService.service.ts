import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';



@Injectable({ providedIn: "root" })
export class sortieService {
    public sortIssuance=new Subject();
  constructor(){



  }
  issueSort(){
      this.sortIssuance.next()
  }
  



  }