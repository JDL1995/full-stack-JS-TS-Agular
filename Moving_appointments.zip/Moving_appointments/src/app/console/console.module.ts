import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableComponent } from './table/table.component';
import { CustomPaginatorComponent } from './custom-paginator/custom-paginator.component';
import { EditComponent } from './edit/edit.component';
import { ActionDialog } from './action-dialog/action-dialog.component';
import { AngularMaterialModule } from '../angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTable, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { ConsoleComponent } from './console/console.component';
import { MatDialogModule } from '@angular/material/dialog';
import { Router, RouterModule } from '@angular/router';
import { ConsoleRoutingModule } from './console-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from '../auth/auth-interceptor';
import { FinishComponent } from './finish/finish.component';
import { InvoiceDialogComponent } from './invoice-dialog/invoice-dialog.component';
import { TestimonialsComponeent } from './testimonials/testimonials.component';
import { MatPseudoCheckboxModule } from '@angular/material/core';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { PaymentsComponent } from './payments/payments.component';


@NgModule({
  declarations: [TableComponent, CustomPaginatorComponent, EditComponent,ActionDialog, ConsoleComponent, FinishComponent, InvoiceDialogComponent, TestimonialsComponeent, PaymentsComponent],
  imports: [
    CommonModule,AngularMaterialModule,FormsModule,ReactiveFormsModule,MatTableModule,MatSortModule,MatDialogModule,RouterModule,ConsoleRoutingModule,HttpClientModule,MatCheckboxModule
  ],
  providers:[]
})
export class ConsoleModule { }
