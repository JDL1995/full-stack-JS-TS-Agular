import { ChangeDetectorRef, EventEmitter, HostListener, Inject, InjectionToken, Input, Output, PipeTransform, ViewChild } from '@angular/core';
import { Pipe } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BehaviorSubject, Subject, Subscription } from 'rxjs';
//import { DataSetService } from 'src/app/data-set-service/dataSet.service';
//import { mimeType } from './mime-type.validator';
//import { myObj } from './obj.model';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';
//import { DataSetService } from 'src/app/data-set-service/dataSet.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
//import { returnable, TablePaginationSettingsModel } from './returnable';
//import { ViewOptions } from './returnable';
import { element, promise } from 'protractor';
//import {Elemental} from './returnable'
import { Element } from '@angular/compiler';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
//import { Elemental, returnable, TablePaginationSettingsModel, ViewOptions } from './returnable';
//import { myObj } from '../mailer-module/mail-page/obj.model';
//import { mimeType } from '../mailer-module/mail-page/mime-type.validator';
import { AfterViewInit } from '@angular/core';
import { MainService } from '../mainService/mainService.service';
import { FormattedAppointment, FormattedAppointment2,FormattedAppointment3,statusManager } from 'src/app/formattedAppointment.model';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/internal/Observable';
import { of } from 'rxjs/internal/observable/of';
import { PageVent } from './pageVent.model';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
//import { ConfirmationDialog } from '../appointment/appointment.component';
import { ResizeService } from 'src/app/resize/resize.service';
import { ActionDialog } from '../action-dialog/action-dialog.component';
import { returnable } from './returnable';
import { InvoiceEvent } from 'src/app/console/console/invoiceEvent'

export interface Tile {
  id:number;
  img: string;
  expanded:number;}




@Pipe({name: 'foraiur'})
export class KeysPipe4 implements PipeTransform {
  transform(value:object) : any {
    let keys = [];
    console.log(value)
    for (let key in value) {
      keys.push(key);
    }
    var keys2= Object.keys(value)
    return keys2;
  }
}




@Pipe({name: 'keys2'})
export class KeysPipe2 implements PipeTransform {
  transform(value:any, args:string[]) : any {
    let keys = [];
    for (let key in value) { keys.push(key);  }
    return keys;}}




@Pipe({name: 'keys3'})
export class KeysPipe3 implements PipeTransform {
  transform(value:any, args:string) : any {
      let keys:string;
    for (let key in value) {
      return key;}}}




@Pipe({name: 'keysa'})
export class KeysPipe implements PipeTransform {
	transform(value: { [x: string]: any; }) : any {
    let keys = [];let keys2= Object.keys(value.message);return keys2;}}




@Pipe({name: 'keys'})
export class listPipe implements PipeTransform {
  public goodobj:{[key:string]:string[]}={'':[]}
  pageSize=5;
  public damnGoodObj:{[key:string]:string[]}={'':[]};
  //public nextlist2:myObj[]=[]
  public  nextlist:{[key:number]:string[]}=[];
  public getit:string[]=[];
  public returnable:returnable={items:[],arraylist:{'':[]}};
	transform(value: { [x: string]: any; },list:string[]) : any {
    //let jsonArray:JSONArray = jsonObject.getJSONArray("names");
    let returnList : {[bey:number]:string[]}=[];
    //let obj:{ b:myObj[]} = JSON.parse()
   let keys2= Object.values(value.message)
   const someArray = list;
   console.log('my goid souy mooch anal');
   console.log(list);
   const van=value;
   let v =Object(value);
   for(let xm=0; xm<someArray.length; xm++){this.damnGoodObj['']=[''];
    this.damnGoodObj[someArray[xm]]=this.damnGoodObj[''];}
someArray.forEach((value, index) => {
  this.getit.push(value);
  let pemgor=value;
  let goodobj:{[key:string]:string[]}={'':[]}
  console.log('much ANAL AHEAD');
  console.log(v.message[value].length)
  console.log('damn good');
  console.log(this.damnGoodObj);
  for(let xm=0; xm<v.message[value].length; xm++){
    this.goodobj['']=[];
    this.goodobj[value]=this.goodobj[''];
      this.goodobj[value].push(v.message[value][xm]);  }
  for(let xm=0; xm<v.message[value].length; xm++){
 this.damnGoodObj[value].push(v.message[value][xm])  }
  console.log(value);
  this.nextlist[index]=[];
    //////////////////////////////////////////////////////////////////////////////////////////////
   console.log(v.message[value])
    let dislist=v.message[value]
    dislist.forEach((malue: any,indeex:number)=>{
      let b=JSON.stringify(malue)
    })});
console.log(this.nextlist)
console.log('MAXIMUM ANAL AHEAD');
console.log('MAXIMUM ANAL AHEAD');
console.log(this.damnGoodObj);
console.log(this.goodobj)
console.log(' m a x i mi iz i i n g an al',this.getit)
let zam = this.damnGoodObj[''].length
console.log(zam)
//this.damnGoodObj['id']=this.damnGoodObj[""]
delete this.damnGoodObj[""];
this.damnGoodObj['id']=[];
for (let i=0; i<zam; i++){
  if(i==0){this.getit.splice(0,0,'id')}
  this.damnGoodObj['id'].push((i).toString());}
console.log(this.damnGoodObj)
this.returnable.items=this.getit;
this.returnable.arraylist=this.damnGoodObj;
    return this.returnable; }}




@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  providers:[KeysPipe,KeysPipe2,KeysPipe3,KeysPipe4,listPipe]})




export class TableComponent implements OnInit, AfterViewInit {
 // tablePaginationSettings: TablePaginationSettingsModel = <TablePaginationSettingsModel>{};
 isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
 expandedElement: any;
  macklegee={};
  public dataTableElements:FormattedAppointment3[]=[];
  tableColumns:string[]=[];
  //public dataSource!: RecordsDataSource | null;
  form!: FormGroup;
  public sub!:Subscription;
  public currentSort!:string;
  public dataSorted=false;
  public showEdit=false;
  public openSaveOption:boolean=false;
  public parsedItems:{[key:string]:string[]}={'':[]};
  public status=false;
  public imagePreview!: string;
  public isLoading!:boolean;
  public thisItem:{[key:string]:string}={['']:''};
  public badoot:string[]=[];
  public nameShowing!:string;
  public dateShowing!:Date;
  public fromShowing!:string;
  public toShowing!:string;
  public returnMessage!:number;
  public mcGee!:string;
  public columneister!:{[key:string]:string[]};
  public mein:object[]=[];
  public mord!:string;
  public iconic2!:string;
  public allmein:object[]=[];
  public displayedColumns=['id','Name', 'Email', 'Date', 'Preferred'];
  public displayedColumns2=['id','Name', 'Email', 'Date', 'Preferred','Actions','Status'];
  public dataSubject = new BehaviorSubject<FormattedAppointment3[]>([]);
  //public datasource!: RecordsDataSource|null;
  public dataSource= new MatTableDataSource<FormattedAppointment2>([]);
  //public sourceSource$= new BehaviorSubject<Elemental[]>([]);
  public heads:string[]=[]
  public items:{[key:number]:string[]}=[]
  public v:{[key:string]:string[]}={'col1':[]};
  public items2!:{[key:string]:[]};
  public gerry!:{[key: string]:string[]}
  public anObj:object[]=[];
  public idval!:number;
  public isHovering=false;
  public notificationSource$: BehaviorSubject<object[]> = new BehaviorSubject(this.anObj);
  public myanus:{[key:string]:string[]}={['']:['']}
  public notificationSource2$: BehaviorSubject<{[key:string]:string[]}> = new BehaviorSubject(this.myanus);
public datahelper=new Subject;
  public changeSource$=new Subject;
  public pageIndex:number=0;
  public openPaginator=false;
  public editChosen=true;
  public notificationSource$2: BehaviorSubject<number> = new BehaviorSubject(0);
  public mcGeen2=this.notificationSource$2.asObservable();
  public selectedApp!:FormattedAppointment3;
  public sortDirection!:string;
  //public powerSource= new BehaviorSubject<Elemental[]>([]);
  public iconic='neenelMobile';
  public mcGeen=this.notificationSource$.asObservable();
  public mcGeem=this.notificationSource2$.asObservable();
  public superDamnGoodObject!:{[key:string]:string[]};
  public photosToggled=false;
  public currentSize!:number;
  public confirmationShowing=false;
  public form3!:FormGroup;
  public totalNum!:number;
  public tiles:Tile[]=[];
  //public becauseyes= new ubject;
  pagesize=10;
  sortby:any;
  resultsLength=0;

  @Output() invoiceEvent=new EventEmitter<InvoiceEvent>();
  @Input() isEdit?:boolean;
  //@Input() sqPaginationConfig?: TablePaginationSettingsModel;

  updateId(data:number){
    this.notificationSource$2.next(data);
  }
  getId(){
    return this.mcGeen2;
  }
  updateDataSelection(data: object[]){
    this.notificationSource$.next(data);

  }
  launch(){

  }
  onCloseInvoice(){
this.mainService.getSelectedListener().subscribe(val=>{
  this.confirmationShowing=false;
  let a:InvoiceEvent={go:true,email:val.email,_id:val._id}
    this.invoiceEvent.emit(a)
})

  }
  onCloseConfirm(){
  }
  onCloseComplete(){
    this.mainService.getSelectedListener().subscribe(val=>{
      this.mainService.completeAppointment(val._id).subscribe(val=>{
        this.confirmationShowing=false;

        console.log(val);

      })
    });

  }


  onClose(Event:Close2Event){
    if(Event.go==true){

      this.showEdit=false;}
    }
  updateDataSelection1(data: {[key:string]:string[]}){
    this.notificationSource2$.next(data);}


  @Input() Item!:string;
  //@Input() sqPaginationConfig?: TablePaginationSettingsModel;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) public sort!: MatSort;
  @ViewChild('table')
  table!: MatTable<FormattedAppointment2>;
  tableSort!:MatSort;
  public ah!:ExampleDataSource;

  constructor(
    public keypipe:KeysPipe,
   public ListPipe:listPipe,
  public keypiper:KeysPipe2,
  public keyOf:KeysPipe3,
  public superPipe: KeysPipe4,
  public mainService:MainService,
  private _cdr: ChangeDetectorRef,
  public resizeservice: ResizeService,
  private dialog: MatDialog ) {
      /*
    this.dss.notifyAbduct.subscribe(val=>{
      console.log('woohoo!')
      this.table.renderRows();
    })*/
   //  this.tablePaginationSettings.enablePagination = true;
   // this.tablePaginationSettings.pageSize = 5;
   // this.tablePaginationSettings.pageSizeOptions = [5, 10, 15];
  //  this.tablePaginationSettings.showFirstLastButtons = true;
 }

 upsize(){
   if (this.mord=='m'){
     this.doDivsUp()
   }

 }
 downSize(){
  if (this.mord=='d'){
    this.doDivsDown()
  }

}
 doDivsUp(){
  this.iconic='neenelDesktop';
  this.iconic2='heemelDesktop';
  console.log('neenelDesktop');
  this.mord='d'

 }
 doDivsDown(){
  this.iconic='neenelMobile';
  this.iconic2='heemelMobile'
  console.log('neenelMobile');
this.mord='m'
 }
 statify(id:FormattedAppointment2){
  if(id.paid==true){
    let d:statusManager={text:'Paid',color:'green'};

    return d;
   }
     if(id.cancelled==true){
      let d:statusManager={text:'Cancelled',color:'red'};

      return d;
     }
    else if(id.completed==true){
      let d:statusManager={text:'Completed',color:'blue'};

       return d;
     }
    else if(id.confirmed==true){
      let d:statusManager={text:'Confirmed',color:'green'};
      return d;
     }
     else{
      let d:statusManager={text:'Unconfirmed',color:'orange'};
      return d;
     }



 }
 onDecisions(id:number){
  for(let o of this.dataTableElements){
    if (o._id==id){
      this.mainService.selectedAppointment.next(o);
    }
  }
setTimeout(() => this.showDecisions(),500)
 }
 showDecisions(){

 }

 onEdit(id:number){

  for(let o of this.dataTableElements){
    if (o._id==id){
      this.mainService.selectedAppointment.next(o);
    }
  }
  this.confirmationShowing=false;
setTimeout(() => this.showEdit=true,500)
 }
 clickClose(){
   console.log('closing Edit')
   this.showEdit=false;
 }
 getColor(a:statusManager){
   return a.color;
 }
  ngOnInit(): void {
    this.pageIndex=0;
    this.mainService.getAppointments();
    this.mainService.getAppointmentsUpdateListener().subscribe(val=>{
      this.mainService.signalGo(val.appointments);
    })

    this.currentSize=window.innerWidth;
  this.resizeservice.sizeSubject.subscribe(val=>{
    console.log(val);
    if(val>516){
      this.mord='d';
      this.iconic='neenelDesktop';
      console.log('neenelDesktop');
      this.iconic2='heemelDesktop';
    }else{this.mord='m';
    console.log('neenelMobile')
    this.iconic='neenelMobile';
    this.iconic='heemelMobile'
  }


  })
let b=this.resizeservice.getWindowMetric2().width
let z=b
  if(z>516){
    this.mord='d';
    this.iconic='neenelDesktop';
    console.log('neenelDesktop');
    this.iconic2='heemelDesktop';
  }else{this.mord='m';
  console.log('neenelMobile')
  this.iconic='neenelMobile';
  this.iconic='heemelMobile'
}

  console.log('current width'+this.currentSize+' in mode'+this.iconic)
    this.mainService.refresh2.subscribe(val=>{
      console.log('refresh2')
      this.refresh();
    })
    this.resizeservice.metricOnResize2$.subscribe(val=>{
      if(val.width>516){
        this.currentSize=val.width;
        this.upsize();
      }else{
        if(this.iconic!="neenelMobile"){
          this.iconic="neenelMobile";
        }
        this.currentSize=val.width;
        this.downSize();
      }
      console.log(this.mord);
      console.log(val.height);
      console.log(val.width);
    })
this.dataTableElements=[];

if (this.isEdit==true){
  this.editChosen=true;
}
/*
this.dss.notifyAbduct.subscribe((vale)=>{
  console.log(vale);
  console.log(this.dataTableElements)
  console.log('table abducting elements to service')
 // this.dss.abductItems(this.dataTableElements);
  //this.dss.openAdd();
  //this.dss.notifyHasAbducted();

})*/

  // this.dataSource = new RecordsDataSource(this.dataSubject );

   //setTimeout(() => this.dataSource!.paginator = this.paginator,500);
if (this.editChosen !=true){
  console.log('intiializing table in add component');
  console.log('checking for list input: ');
  //this.dataTableElements=this.dss.getThatShit();
  //setTimeout(() =>   this.dataSource = new MatTableDataSource<FormattedAppointment2>(this.dataTableElements),500);
}
if (this.editChosen == true){
   // this.dss.total(this.Item);
      this.sub =  this.mainService.appointmentSubject.subscribe(
            (dataMap) => {
             // let b:string[]=this.superPipe.transform(dataMap);
              Object.entries(dataMap).forEach(
                ([key,value])=>{
                  let dal=this.statify(value)!
                const newElement: FormattedAppointment3 = {
                  _id:value._id,
                  name: value.name,
                  number: value.number,
                  email: value.email,
                  date: value.date,
                  contactType:value.contactType,
                  fromAddress:value.fromAddress,
                  toAddress:value.toAddress,
                  additionalInfo:value.additionalInfo,
                  confirmed:value.confirmed,
                  completed:value.completed,
                  cancelled:value.cancelled,
                  paid:value.paid,
                  status:dal};
                      //    console.log('push again',newElement)
                        this.dataTableElements.push(newElement);
                    }
                );
                this.dataSubject.next(this.dataTableElements);
            });

            setTimeout(() => this.dingdingadondough(),350);
            setTimeout(() =>this.openPaginator=true,450);
            /*
            let ah=new ExampleDataSource();let damn:FormattedAppointment3[]=[];let d=0;
            for(let c of this.dataTableElements){
              if(d<=10){damn.push(c)}d++;}
              ah.setdata(damn);this.ah=ah;
            this.ah.paginator=this.paginator; */
           // setTimeout(() => this.table.dataSource=ah,300);
           // setTimeout(() =>   this.table.dataSource = this.dataTableElements,100);
            console.log('abducting elements')
            //setTimeout(() => this.dss.abductItems(this.dataTableElements),500);
           // setTimeout(() => this.dss.notifyAbduct.next(),900);
         // setTimeout(() =>   this.table.dataSource = this.dataTableElements,400);
          setTimeout(() =>  this.dataSource.sortingDataAccessor = (item, property) => {
            if (property === 'id') {     return item._id;}
            else if (property === 'Name') {return item.name;
            } else  if (property === 'Date') {return +item.date;}
            else  if (property === 'Email') {return item.email;}
            else {return ''}},500);
         // setTimeout(() => this.dataSource!.paginator = this.paginator,600);
         // setTimeout(() => this.dataSource!.sort = this.sort,650);
         setTimeout(() => this.table.renderRows(),550);
        }
         // setTimeout(() => console.log(this.ah.data),950);
        //  setTimeout(() => this.dataSource.data=this.ah.data,950);
         // setTimeout(() => this.table.renderRows(),500);
        }
        //  this.dataSource.paginator=this.paginator;

async first(){
  setTimeout(() =>   this.mainService.getAppointmentsUpdateListener().subscribe(val=>{
    this.mainService.signalGo(val.appointments);
  }),500)

this.mainService.getAppointments();
}
async second(){
  this.dataTableElements=[];
  this.sub =  this.mainService.appointmentSubject.subscribe(
    (dataMap) => {
     // let b:string[]=this.superPipe.transform(dataMap);
      Object.entries(dataMap).forEach(
        ([key,value])=>{
          let dal=this.statify(value)!
        const newElement: FormattedAppointment3 = {
          _id:value._id,
          name: value.name,
          number: value.number,
          email: value.email,
          date: value.date,
          contactType:value.contactType,
          fromAddress:value.fromAddress,
          toAddress:value.toAddress,
          additionalInfo:value.additionalInfo,
          confirmed:value.confirmed,
          completed:value.completed,
          paid:value.paid,
          cancelled:value.cancelled,
          status:dal

      };
                //  console.log('push again',newElement)
                this.dataTableElements.push(newElement);
            }
        );
        this.dataSubject.next(this.dataTableElements);
    });

}
refresh() {

  this.first().then(val=>{
    setTimeout(() =>  this.second().then(val=>{
 this.ah.paginator=this.paginator;
    if (this.dataSorted==true){
      let data = this.dataTableElements.slice();
      this.pageIndex=0;
      console.log('sorting');
          data = data.sort((a: FormattedAppointment3, b: FormattedAppointment3) => {
              const isAsc = this.sortDirection === 'asc';
              switch (this.currentSort) {
                  case 'id': console.log('id');return this.compare(a._id, b._id, isAsc);
                  case 'Name':console.log('Name'+a.name); return this.compare(a.name, b.name, isAsc);
                  case 'Date': return this.compare(a.date, b.date, isAsc);
                  case 'Email': return this.compare(a.email, b.email, isAsc);
           default: return 0;}});

      this.dataSubject.next(data);
      let newtable:FormattedAppointment3[]=[];
      let am=this.paginatorInterfaceIndex2(this.pagesize,this.pageIndex)
      this.dataSubject.subscribe(gil=>{
        console.log('pagesize: '+this.pagesize+' page Index: '+this.pageIndex)
        let index=0; let needle:FormattedAppointment3[]=[];console.log(am)
        console.log('getting from index '+am[0]+'to index '+am[1]);
          for (let h of gil){
            needle.push(h);
            if (index>=am[0] && index<am[1]){newtable.push(h);}index++;
          }})
          let ah=new ExampleDataSource();
          setTimeout(() =>  ah.setdata(newtable),400);
          setTimeout(() => this.ah=ah,600);
         setTimeout(() => this.table.renderRows(),800);
         setTimeout(() => this.table.renderRows(),1600);
    }
    else{
        this.pushCurrent().then(hell=>
          console.log('worked'))


    }

    }),500);


  })



}
dingdingadondough(){
  this.totalNum=this.dataTableElements.length;
  let ah=new ExampleDataSource();
  let damn:FormattedAppointment3[]=[];
  let d=0;
  for(let c of this.dataTableElements){
    if(d<=10){
     // console.log(c);
      damn.push(c)
    }d++;}
  ah.setdata(damn);
  this.ah=ah;
  this.ah.paginator=this.paginator;

}
async setSelected(id:number){
  let confirmed:boolean;
  for (let da of this.dataTableElements){
    if(da._id==id){
        this.mainService.selectedAppointment.next(da);
        confirmed=da.confirmed;
        return confirmed
    }}

}
openDialog(id:number)
{
      this.setSelected(id).then(confirmed=>{
        let a:InvoiceEvent={go:false,email:' ',_id:1}
    this.invoiceEvent.emit(a)
    this.confirmationShowing=false;
 const dialogRef = this.dialog.open(ActionDialog,{data:confirmed});
        dialogRef.afterClosed().subscribe((showSnackBar: string) => {
          this.confirmationShowing=false;
      if (showSnackBar=='confirm') {
          console.log('confirm');
        // snack.dismiss();
          const a = document.createElement('a');
          a.click();
          a.remove();
        // snack.dismiss();
        this.confirmAppointment(); }
     else if (showSnackBar=='cancel') {
          // snack.dismiss();
          const a = document.createElement('a');
          a.click();
          a.remove();

          // snack.dismiss();
          this.cancelAppointment(); }
          else if (showSnackBar=='invoice') {
            // snack.dismiss();
            const a = document.createElement('a');
            a.click();
            a.remove();

            // snack.dismiss();
            this.onCloseInvoice(); }
      else if (showSnackBar=='complete') {

          // snack.dismiss();
          const a = document.createElement('a');
          a.click();
          a.remove();
          this.onCloseComplete();
          // snack.dismiss();
           }

        } );

      })

  //const snack = this.snackBar.open('Snack bar open before dialog');
 }
cancelAppointment(){
  this.mainService.getSelectedListener().subscribe(val=>{
    this.confirmationShowing=false;
    this.mainService.cancelAppointment(val._id).subscribe(val=>{

      console.log(val);

    })
  });


}
completeAppointment(){
}


  confirmAppointment(){
    this.mainService.getSelectedListener().subscribe(val=>{
      this.nameShowing=val.name;
      this.dateShowing=val.date;
      this.fromShowing=val.fromAddress;
      this.toShowing=val.toAddress;
      this.showConfirmationForm()
    })}


   getValueFromObservable() {
    return new Promise<FormattedAppointment3>(resolve=>{
        this.mainService.getSelectedListener()
         .subscribe(
            (data:any) => {
                console.log(data);
                resolve(data);})})}


  submitConfirm(){
    this.getValueFromObservable().then(val=>{
      this.mainService.submitConfirm(val._id,this.form3.value.body).subscribe(val=>{
        console.log(val);
        this.confirmationShowing=false;
      })})  }
      backDatAssUp(){
        this.confirmationShowing=false;
      }


  showConfirmationForm(){
    this.form3=new FormGroup({
      body: new FormControl('',  {
     validators: [Validators.required, Validators.minLength(3)]
        })});this.confirmationShowing=true;}

        closeConfirmationForm(){
          //this.mainService.selectedAppointment.unsubscribe();
          this.confirmationShowing=false;
        }


expanding(){
if (this.photosToggled==true){
  this.photosToggled=false}}


expand(id:number){
for (let o of this.tiles){
  if (o.id==id){
    o.expanded=4
  }else{ o.expanded=0}}
this.changeStatus();}


changeStatus(): void {
  setTimeout(() => {
    if(this.status==false){
    this.status = true;}
    else if (this.status==true){
      this.status=false;}
    this._cdr.detectChanges()
  }, 200);}


shrink(id:number){
  for (let o of this.tiles){
      o.expanded=1}
  this.changeStatus();}


tileClicked(id:number){
  console.log(id)
  if(this.status==false){
    this.expand(id);}
  else if(this.status==true){
    this.shrink(id);}}


  generateTiles(id:number){
    if(this.photosToggled==true){
      this.photosToggled=false;
    }else{
    this.mainService.getPhotos(id).subscribe(val=>{
      console.log(val.message)
      let b = val.photos;let tiles:Tile[]=[];let f=0;
      for (let o of b){
        f=f+1;console.log(o)
        let tile:Tile={id:id+f, img:o,expanded:1};
        tiles.push(tile);
      }
      this.tiles=tiles;
    })
    this.photosToggled=true;}}


  ngAfterViewInit() {
    this.table.dataSource=this.ah;
    setTimeout(() => this.table.renderRows(),500);
    //setTimeout(() => this.table.renderRows(),100);
    setTimeout(() => console.log('rendered rows'),1800);  }
   // setTimeout(() => this.dataSubject.next(this.dataTableElements),900);
    //setTimeout(() =>   this.dataSource.data = this.dataTableElements,2000);
    //setTimeout(() =>   this.dataSource = new MatTableDataSource<Elemental>(this.dataTableElements),500);
    //this.dataSource.sort=this.sort;
  // this.dataSource!.paginator = this.paginator;
  //this.dataSource.sortingDataAccessor = (item, property) => {
//onSortData($event)
async pushCurrent(){
  let yeem:FormattedAppointment3[]=[];
  this.dataTableElements.forEach((value, index) => {

    if(this.pageIndex==0){ console.log('event pageindex registered as equal to 1');
      if(index<this.pagesize){console.log('pushing index < event.pagesize');
        yeem.push(value); }}
    if (this.pageIndex==1){
      if (index>this.pagesize && index <= this.pagesize*2){
        yeem.push(value);
      }}
    if (this.pageIndex>1){
      console.log('event pageIndex registered as greater than one');
      if(index>(this.pagesize*(this.pageIndex)) && index<=(this.pagesize*(this.pageIndex+1))){
        yeem.push(value);
      }}})
      let ah = new ExampleDataSource;
      // then you can assign data to your dataSource like so
      ah.setdata(yeem);
      this.ah=ah;
      this.table.renderRows();


}

  onPageFired(event:PageVent){
      let yeem:FormattedAppointment3[]=[];
    console.log('yeem')
    this.pagesize=event.pageSize;
    this.pageIndex=event.pageIndex;
    console.log('pageIndex: '+event.pageIndex+' pageSize: '+event.pageSize);
      this.dataTableElements.forEach((value, index) => {
        if(event.pageIndex==0){ console.log('event pageindex registered as equal to 1');
          if(index<event.pageSize){console.log('pushing index < event.pagesize');
            yeem.push(value); }}
        if (event.pageIndex==1){
          if (index>event.pageSize && index <= event.pageSize*2){
            yeem.push(value);
          }}
        if (event.pageIndex>1){
          console.log('event pageIndex registered as greater than one');
          if(index>(event.pageSize*(event.pageIndex)) && index<=(event.pageSize*(event.pageIndex+1))){
            yeem.push(value);
          }}})
      let ah = new ExampleDataSource;
    // then you can assign data to your dataSource like so
    ah.setdata(yeem);
    this.ah=ah;
    this.table.renderRows();}

/*
  getCurrentOptions() {
    const options: ViewOptions = {
      sortField: this.sort.active,
      sortDirection: this.sort.direction,
      page: this.paginator.pageIndex,
      pageSize: this.paginator.pageSize
    };return options;}
  getDefaultOptions() {
    const options: ViewOptions = {
      sortField: 'name',
      sortDirection: 'asc',
      page: 0,
      pageSize: this.pagesize
    }; return options;}
*/
  onDataSave(){}


  onFilePicked(event: Event) {
    this.isLoading=true;
    const file = (event.target as HTMLInputElement).files![0];
    this.form.patchValue({ file: file });
    this.form.get("file")!.updateValueAndValidity();
    const reader = new FileReader();
    reader.onload = () => {
      const d = reader.result as string;
      let b:string;
      if (d.length >150 ){
        b= d.toString().substring(0,150); }
      else{ b=d.toString()}
      let i=0;
      for(let m=0; m<b.length; m=m+30){
        this.badoot[i]=b.substring(m,m+30);
        console.log('newbadoot')
        i=i+1; }
      this.imagePreview=b;
    };
    reader.readAsText(file);
    this.isLoading=false;
  }


     paginatorInterfaceIndex(pagesize:number,currentpage:number){
          let a:number[]=[]
        if(currentpage==0){
          a.push(0);
          a.push(pagesize);    }
        else{
          a.push(pagesize*(currentpage+1));
          a.push(pagesize*(currentpage+2))}
          if (pagesize){}
          return a;
        }

     paginatorInterfaceIndex2(pagesize:number,currentpage:number){
      let a:number[]=[]
      console.log('P I I : size: '+pagesize+' index: '+currentpage)
    if(currentpage==0){
      a.push(0);
      a.push(pagesize);    }
    else{
      a.push(pagesize*(currentpage));
      a.push(pagesize*(currentpage+1))}

      return a;
    }


 onSortData(sort: Sort) {
      this.dataSorted=true;
      console.log(sort.active);
      this.currentSort=sort.active;
      this.sortDirection=sort.direction;

      let data = this.dataTableElements.slice();
      this.pageIndex=0;
      console.log('sorting');
      if (sort.active && sort.direction !== '') {
          data = data.sort((a: FormattedAppointment2, b: FormattedAppointment2) => {
              const isAsc = sort.direction === 'asc';
              switch (sort.active) {
                  case 'id': console.log('id');return this.compare(a._id, b._id, isAsc);
                  case 'Name':console.log('Name'+a.name); return this.compare(a.name, b.name, isAsc);
                  case 'Date': return this.compare(a.date, b.date, isAsc);
                  case 'Email': return this.compare(a.email, b.email, isAsc);
           default: return 0;}});}
      this.dataSubject.next(data);
      //this.table.dataSource=[];
      let newtable:FormattedAppointment3[]=[];
      this.dataSubject.subscribe(gil=>{let am=this.paginatorInterfaceIndex2(this.pagesize,this.pageIndex)
        let index=0; let needle:FormattedAppointment3[]=[];console.log(am)
          for (let h of gil){
            needle.push(h);
            if (index>=am[0] && index<am[1]){newtable.push(h);};index++;
          }
        this.dataTableElements=needle;
        })

      let ah=new ExampleDataSource();
      setTimeout(() =>  ah.setdata(newtable),400);
      setTimeout(() => this.ah=ah,600)
     setTimeout(() => this.table.renderRows(),800) }
public isAsc='asc';


  private compare(a:any, b:any, isAsc:any) {
      return (a < b ? -1 : 1) * (isAsc ? 1 : -1);}


  ngOnDestroy() {
      if (this.sub) {
          this.sub.unsubscribe();}}}



/*
export class RecordsDataSource extends MatTableDataSource<Element> {
  constructor(private subject: BehaviorSubject<Elemental[]>) {
      super();
  }
  connect(): BehaviorSubject<any[]> {
      return this.subject;
  }
  disconnect(): void {
}}*/





export class ExampleDataSource extends DataSource<any> {
  paginator!:MatPaginator;
   data:FormattedAppointment3[]=[];
  setdata(appointment:FormattedAppointment3[]){
    this.data=appointment;}
  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<FormattedAppointment3[]> {
    const rows:any = [];
    this.data.forEach(element => rows.push(element, { detailRow: true, element }));
    console.log(rows);
    return of(rows);}
  disconnect() { }}
export interface Close2Event{
  go:boolean;
  refresh:boolean;
}
