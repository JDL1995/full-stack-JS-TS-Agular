export interface returnable{
    items:string[];
    arraylist:{[key:string]:string[]}
}
export interface Elemental{
    id: number;
    lastname:string;
    firstname:string;
    email:string;
    job:string;
  }

  export interface ViewOptions {
    sortField: string;
    sortDirection: string;
    page: number;
    pageSize: number;
  }

  
export interface TablePaginationSettingsModel {
  /**
   * @description enable Pagination of rows
   */
  enablePagination: boolean;
  /**
   * @description Number of items to display on a page. By default, set to 50.
   */
  pageSize: number;
  /**
   * @description the set of provided page size options to display to the user.
   */
  pageSizeOptions: number[];
  /**
   * @description Whether to show the first/last buttons UI to the user.
   */
  showFirstLastButtons: boolean;
}