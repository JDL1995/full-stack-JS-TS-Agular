export interface PageVent{
    pageIndex:number;
    pageSize:number;
}