import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "src/app/auth/auth.guard";
import { ConsoleComponent } from './console/console.component';

//import { SignupComponent } from "./signup/signup.component";

const routes: Routes = [
  { path: "", component: ConsoleComponent, canActivate: [AuthGuard]  },

];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  providers:[AuthGuard]
})
export class ConsoleRoutingModule {}