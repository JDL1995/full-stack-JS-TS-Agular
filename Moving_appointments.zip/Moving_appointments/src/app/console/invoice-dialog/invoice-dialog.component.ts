import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-invoice-dialog',
  templateUrl: './invoice-dialog.component.html',
  styleUrls: ['./invoice-dialog.component.scss']
})
export class InvoiceDialogComponent implements OnInit {
  public confirmed!:{[key: string]:string[]}
  public completed!:boolean;
  public name!:string;
  public price!:number;
  public details!:string;
  public date!:string;
  constructor(
    public dialogRef: MatDialogRef<InvoiceDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data:{[key: string]:string}) { }

    ngOnInit(){
      this.name=this.data['name'];
      this.date=this.data['date'];
      this.details=this.data.details;

      this.price=+this.data['price'];

      
    }
  onYesClick(): void {
    this.dialogRef.close(true);
  }
 

}