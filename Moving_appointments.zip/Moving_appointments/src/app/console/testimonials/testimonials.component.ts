import { trigger, state, style, transition, animate } from '@angular/animations';
import { SelectionModel } from '@angular/cdk/collections';
import { DataSource } from '@angular/cdk/table';
import { AfterContentInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { Observable, of } from 'rxjs';
import { AppointmentService } from 'src/app/appointment/appointment.service';
import { Testimonial } from 'src/app/appointment/testimonial.model';
import { MainService } from '../mainService/mainService.service';
import { PageVent } from '../table/pageVent.model';
import { ExampleDataSource } from '../table/table.component';

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', visibility: 'hidden' })),
      state('expanded', style({ height: '*', visibility: 'visible' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ]
})
export class TestimonialsComponeent implements OnInit, AfterContentInit{
  isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  selection = new SelectionModel<Testimonial>(true, []);
  expandedElement: any;
  photosToggled=false;
  constructor(public appService:AppointmentService,public mainService:MainService) { }
  public pageIndex!:number;
  totalNum!:number;
 // displayedColumns2=['Name','Date','Status']
  pagesize=50;
 openPaginator=false;
  public dataTableElements!:Testimonial[];
  public idear=0;
  public idList:string[]=[];
  public ah!:ExampleDataSource2;
  @ViewChild('table')
  table!: MatTable<Testimonial>;
  public displayedColumns2=['Select','Name', 'Date', 'Visible'];
public testimonials!:Testimonial[];

isAllSelected() {
  const numSelected = this.selection.selected.length;
  const numRows = this.ah.data.length;
  return numSelected === numRows;
}

/** Selects all rows if they are not all selected; otherwise clear selection. */
masterToggle() {
  this.isAllSelected() ?
      this.selection.clear() :
      this.ah.data.forEach(row => this.selection.select(row));
}
isVis(a:boolean){

  //console.log(a)
  if(a==true){
    return true
  }
  else{
    return false
  }

}
toggleVisibility(){
  this.idList=[];
  console.log('wow')
  console.log(this.selection.selected)
  this.selection.selected.forEach(value=>{
   this.idList.push(value._id)
  })
  this.appService.changeVisibility(this.idList).subscribe(val=>{
    console.log(val)
    setTimeout(()=>{this.refresh()},650)
  })

}
refresh(){
  this.appService.getTestimonialsAdmin();
  this.appService.getTestimonialsUpdateListener().subscribe(testimonials=>{
    this.dataTableElements=testimonials.testimonials;
    this.totalNum=this.dataTableElements.length;
  })
  let ah=new ExampleDataSource2;
  //this.table.dataSource=this.ah;
  setTimeout(()=> console.log(this.testimonials),500);
  setTimeout(()=> ah.setdata(this.dataTableElements),250);
  setTimeout(()=> this.ah=ah,350);
  setTimeout(()=> this.table.renderRows(),650);



}
bingo(){
  let bingo:any[]=[];
  let a=0;
  for (let d of this.dataTableElements){
    if (a<10){
      bingo.push(d)
      a++;
    }
  }
  return bingo
}
expanding(){
  if (this.photosToggled==true){
    this.photosToggled=false}}
    ngAfterContentInit(){
      setTimeout(() => this.table.renderRows(),570);
      setTimeout(()=> this.openPaginator=true,800);
    }
  ngOnInit(): void {
    this.appService.getTestimonialsAdmin();
    this.appService.getTestimonialsUpdateListener().subscribe(testimonials=>{
      this.dataTableElements=testimonials.testimonials;
      this.totalNum=this.dataTableElements.length;
    })
    let ah=new ExampleDataSource2;
    let bingo:any=[];
    setTimeout(()=> bingo=this.bingo(),150);
    //this.table.dataSource=this.ah;
    setTimeout(()=> console.log(this.testimonials),500);
    setTimeout(()=> ah.setdata(bingo),250);
    setTimeout(()=> this.ah=ah,450);
     // this.dss.total(this.Item);
       
               // let b:string[]=this.superPipe.transform(dataMap);
        
           
  
              
              /*
              let ah=new ExampleDataSource();let damn:FormattedAppointment3[]=[];let d=0;       
              for(let c of this.dataTableElements){
                if(d<=10){damn.push(c)}d++;}
                ah.setdata(damn);this.ah=ah;
              this.ah.paginator=this.paginator; */
             // setTimeout(() => this.table.dataSource=ah,300);
             // setTimeout(() =>   this.table.dataSource = this.dataTableElements,100);
              console.log('abducting elements')
              //setTimeout(() => this.dss.abductItems(this.dataTableElements),500);
             // setTimeout(() => this.dss.notifyAbduct.next(),900);
           // setTimeout(() =>   this.table.dataSource = this.dataTableElements,400);
           
           // setTimeout(() => this.dataSource!.paginator = this.paginator,600);
           // setTimeout(() => this.dataSource!.sort = this.sort,650);
          
           // setTimeout(() => console.log(this.ah.data),950);
          //  setTimeout(() => this.dataSource.data=this.ah.data,950);
           // setTimeout(() => this.table.renderRows(),500);
          

  }
       

  onPageFired(event:PageVent){
    let yeem:Testimonial[]=[];
  console.log('yeem')
  this.pagesize=event.pageSize;
  this.pageIndex=event.pageIndex;
  console.log('pageIndex: '+event.pageIndex+' pageSize: '+event.pageSize);
    this.dataTableElements.forEach((value, index) => {
      if(event.pageIndex==0){ console.log('event pageindex registered as equal to 1');
        if(index<event.pageSize){console.log('pushing index < event.pagesize');
          yeem.push(value); }} 
      if (event.pageIndex==1){
        if (index>event.pageSize && index <= event.pageSize*2){
          yeem.push(value);
        }}
      if (event.pageIndex>1){
        console.log('event pageIndex registered as greater than one');
        if(index>(event.pageSize*(event.pageIndex)) && index<=(event.pageSize*(event.pageIndex+1))){
          yeem.push(value);
        }}})
    let ah = new ExampleDataSource2;
  // then you can assign data to your dataSource like so
  ah.setdata(yeem);
  this.ah=ah;
  this.table.renderRows();
}


}

export class ExampleDataSource2 extends DataSource<any> {
  
   data:Testimonial[]=[];
  setdata(appointment:Testimonial[]){
    this.data=appointment;}
  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<Testimonial[]> {
    const rows:any = [];
    this.data.forEach(element => rows.push(element, { detailRow: true, element }));
    console.log(rows);
    return of(rows);}
  disconnect() { }}
