export interface InvoiceEvent{
    go:boolean;
    email:string;
    _id:number;
}