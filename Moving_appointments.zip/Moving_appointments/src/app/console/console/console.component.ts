import { ChangeDetectorRef } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { FormattedAppointment } from 'src/app/formattedAppointment.model';
import { MainService } from 'src/app/console/mainService/mainService.service';
import {MatIconModule, MatIcon } from '@angular/material/icon';
import { AuthService } from 'src/app/auth/auth.service';
import { InvoiceEvent } from './invoiceEvent';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-console',
  templateUrl: './console.component.html',
  styleUrls: ['./console.component.scss']
})
export class ConsoleComponent implements OnInit {
  userIsAuthenticated = false;
  isLoading=false;
  public appointments!:FormattedAppointment[];
  private postsSub!: Subscription;
  private authStatusSub!: Subscription;
  public count!:number;
  public status=false;
  public showPayments=false;
  public showtable=false;
  public _id!:number;
  public email!:string;
  public showTestimonials=false;
  public showFinish=false;
  constructor(public mainService:MainService,
    private authService: AuthService,


    ) { }

setAppointments(){
  this.showTestimonials=false;
  this.showtable=true;
  this.showPayments=false;
}

setTestimonials(){
  this.showtable=false;
  this.showTestimonials=true;
  this.showPayments=false;
}
setPayments(){
  this.showtable=false;
  this.showTestimonials=false;
  this.showPayments=true;
}
  ngOnInit(): void {

    this.authService.autoAuthUser();
    this.isLoading = true;
    this.authStatusSub = this.authService.getAuthStatusListener().subscribe(
      authStatus => {
        this.isLoading = false;
      }
    );
    /*
    this.mainService.getAppointments();
    this.postsSub = this.mainService
      .getAppointmentsUpdateListener()
      .subscribe((postData: { appointments: FormattedAppointment[]}) => {
        this.isLoading = false;
        this.appointments = postData.appointments;
        console.log(this.appointments)
        this.mainService.signalGo(this.appointments);
        this.mainService.dooting.subscribe((val)=>{
          this.showtable=true;

          this.mainService.posting.next();


        })


      });
      this.mainService.getAppointmentCountUpdateListener().subscribe(count=>{
        this.count=count.count;

      })
      console.log(this.appointments);




    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authStatusSub = this.authService
      .getAuthStatusListener()
      .subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      });

      this.mainService.refresh.subscribe(val=>{
        this.isLoading = true;
        this.mainService.getAppointments();
        console.log('refresh1');
        this.postsSub = this.mainService
        .getAppointmentsUpdateListener()
        .subscribe((postData: { appointments: FormattedAppointment[]}) => {
          this.isLoading = false;
          this.appointments = postData.appointments;
          console.log(this.appointments)
          this.mainService.signalGo(this.appointments);
          this.mainService.dooting.subscribe((val)=>{
            //this.showtable=true;

            this.mainService.refresh2.next();


          })


        });


      })
*/
  }
  onClose(event:{go:boolean}){
    if (event.go==true){
      this.showFinish=false;
    }
  }

  onInvoice(event:InvoiceEvent){
    if (event.go==true){
     this._id= event._id
     this.email=event.email;
     this.showFinish=true;


    }
    else if(event.go==false){
      this.showFinish=false;
    }

  }

}
