import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { InvoiceDialogComponent } from '../invoice-dialog/invoice-dialog.component';
import { MainService } from '../mainService/mainService.service';

@Component({
  selector: 'app-finish',
  templateUrl: './finish.component.html',
  styleUrls: ['./finish.component.scss']
})
export class FinishComponent implements OnInit {

  constructor(    private dialog: MatDialog, private mainService:MainService, private snackBar:MatSnackBar ) { }
  @Input() _id!:number;
  @Output() closeEvent=new EventEmitter<{go:boolean}>();
  @Input() email!:string;
  public name!:string;
  public date!:string;
  public address!:string;
  //public data!:{[key:string]:string}
  public data={date:'',name:'',price:'',details:''}
  form!:FormGroup
  ngOnInit(): void {
    //this.mainService.getAppointment(this._id);
    
    this.mainService.getAppointment(this._id).subscribe(val=>{
      
      this.name=val.appointment.name.toString();
      this.date=val.appointment.date.toString();
      console.log(this.name);
      console.log(this.date);
      this.address=val.appointment.toAddress.toString();
      this.data.name=this.name;
      this.data.date=this.date;

    })

    this.form = new FormGroup({
      
      Price: new FormControl('', {
        validators: [Validators.required, Validators.minLength(3)]
      }),
      InvoiceDetails: new FormControl('',{
        validators:[Validators.required, Validators.minLength(3)]
      })
    })


  }
  onSubmit(){
    this.data.price=this.form.value.Price.toString();
    this.data.details=this.form.value.InvoiceDetails;
    setTimeout(() => this.openDialog(),300);


  }
  goBack(){
    let a={go:true}
    this.closeEvent.emit(a);
  }

  openDialog() 
  {
    const dialogRef = this.dialog.open(InvoiceDialogComponent,{data:this.data});
    //const snack = this.snackBar.open('Snack bar open before dialog');

    dialogRef.afterClosed().subscribe((showSnackBar: boolean) => {
      if (showSnackBar) {
       
       // snack.dismiss();
        const a = document.createElement('a');
        a.click();
        a.remove();
        this.onClose();
       // snack.dismiss();
        this.snackBar.open('Invoice sent to '+this.email, '', {
          duration: 2000,
        });
      }
    } );}
    onClose(){
      this.mainService.sendInvoice(+this.data.price,this._id,this.data.details,this.data.date,this.address,this.email).subscribe(val=>{
        console.log(val)
        setTimeout(()=>{
          let a={go:true}
          this.closeEvent.emit(a);
        })
      })

    }

}
