
export interface FormattedAppointment{
    _id:number,
    name: { type: String, required: true },
  number: { type: Number, required: true },
  email: { type: String, required: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  contactType: { type: String, required: true },
  fromAddress: { type: String, required: true },
  toAddress: { type: String, required: true },
  additionalInfo:{ type:String, required: false},
  confirmed:boolean,
  completed:boolean
  cancelled:boolean,
  paid:boolean
}
export interface FormattedAppointment2{
    _id:number,
    name:string,
  number:number,
  email:string,
  date:Date,
  contactType: string,
  fromAddress:string,
  toAddress: string,
  additionalInfo:string,
  confirmed:boolean,
  completed:boolean,
  cancelled:boolean,
  paid:boolean
}
export interface FormattedAppointment3{
  _id:number,
  name:string,
number:number,
email:string,
date:Date,
contactType: string,
fromAddress:string,
toAddress: string,
additionalInfo:string,
confirmed:boolean,
completed:boolean,
cancelled:boolean,
paid:boolean,
status:statusManager
}

export interface statusManager{
  text:string,
  color:string
}
