import { Injectable } from '@angular/core';
import { Observable, fromEvent, timer, Subject } from 'rxjs';
import { map, debounce } from 'rxjs/operators';
/**
 * Our goal : have observable from resize event who "emit" on each resize new width and height of screen.
 */
@Injectable({ providedIn: "root" })
export class ResizeService{
  sizeSubject= new Subject<number>()
public getWindowMetric = () => {
  const height = window.innerHeight;
  const width = window.innerWidth;
  return {height, width};
}

public getWindowMetric2() {
  const height = window.innerHeight;
  var width:number = +window.innerWidth;
  let a={width:width}
  //this.sizeSubject.next(width);
  return a;
}

public timeout:any|null = !null;
public metricOnResize$ = Observable.create((e: { next: (arg0: { height: number; width: number; }) => void; }) => {
  window.addEventListener("resize", () => {
    if(this.timeout)
      clearTimeout(this.timeout);

    this.timeout = setTimeout(() => e.next(this.getWindowMetric()), 500);
  });
});


// another way of doing it, is to use debounce

public metricOnResize2$ = fromEvent(window,'resize')
  .pipe(
    debounce(() => timer(500)),
    map(event => this.getWindowMetric())
  );
  
  }