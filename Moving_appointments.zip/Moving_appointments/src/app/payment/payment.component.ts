import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

import { StripeService, StripeCardComponent } from 'ngx-stripe';
import {
  StripeCardElementOptions,
  StripeElementsOptions
} from '@stripe/stripe-js';
import { AppointmentService } from '../appointment/appointment.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {
  paymentForm!: FormGroup;
  @ViewChild(StripeCardComponent) card!: StripeCardComponent;
  @Input() amount!:number;
  public clientSecret!:any;
  @Output() completed = new EventEmitter<{status:boolean}>()
  cardOptions: StripeCardElementOptions = {
    style: {
      base: {
        iconColor: '#666EE8',
        color: '#31325F',
        fontWeight: '300',
        fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
        fontSize: '18px',
        '::placeholder': {
          color: '#CFD7E0'
        }
      }
    }
  };

  elementsOptions: StripeElementsOptions = {
    locale: 'en'
  };

  stripeTest!: FormGroup;
  public this!:{[key:string]:string};public any!:any;
  constructor(private fb: FormBuilder, private stripeService: StripeService, private mainService:AppointmentService) {}
public onFinishPayment = new EventEmitter<boolean>();
  ngOnInit(): void {
    this.paymentForm = new FormGroup({
      name: new FormControl('', {
        validators: [Validators.required, Validators.minLength(3)]
      }),
    });
    this.stripeTest = this.fb.group({
      name: ['', [Validators.required]]
    });


  }

  createToken(): void {
    const name = this.paymentForm.value.name;
    this.stripeService
      .createToken(this.card.element, { name })
      .subscribe((result) => {
        if (result.token) {
          
          this.mainService.createCharge(this.amount,result.token.id).subscribe(val=>{
           
            let b = JSON.stringify(val);
            this.this=JSON.parse(b); 
          
            let mcgee=JSON.stringify(this.this.message);
              /**/
            this.any=JSON.parse(mcgee);
            if(this.any.status="succeeded"){
              console.log('charge has succeeded');
              this.completed.emit({status:true})
              //this.mainService.
            }
            console.log(val);

          })
          // Use the token
          console.log(result.token.id);
        } else if (result.error) {
          // Error creating the token
          console.log(result.error.message);
        }
      });
  }

}


/**<div class="mexican">
<form novalidate (ngSubmit)="createToken()" [formGroup]="stripeTest">
    <input type="text" formControlName="name" placeholder="Jane Doe">
    <ngx-stripe-card
      [options]="cardOptions"
      [elementsOptions]="elementsOptions"
    ></ngx-stripe-card>
    <button type="submit">
      Charge
    </button>
  </form>
  </div> */