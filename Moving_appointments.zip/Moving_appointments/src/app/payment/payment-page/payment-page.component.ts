import { _DisposeViewRepeaterStrategy } from '@angular/cdk/collections';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppointmentService } from 'src/app/appointment/appointment.service';
import { MainService } from 'src/app/console/mainService/mainService.service';
import { Payment } from './payment';

@Component({
  selector: 'app-payment-page',
  templateUrl: './payment-page.component.html',
  styleUrls: ['./payment-page.component.scss']
})
export class PaymentPageComponent implements OnInit {
public ger!:number;
public reg!:string;
public this!:{[key:string]:string};
public mainAmount!:number;
public thisPayment!:Payment;
public completed=false;
public meinObj!:any;
public showIt=false;
public name!:string;
public date!:string;
public time!:string;
public price!:string;
public details!:string;
public fromAddress!:string;
public toAddress!:string;
public any!:any;
  constructor(private mainService:AppointmentService,
    public route:ActivatedRoute,
    private mainMain:MainService) { }
    public email!:string;
  ngOnInit(): void {
    this.ger=+this.route.snapshot.params['id'];
    this.reg=this.route.snapshot.params['token'];
    this.mainService.getPayment(this.ger,this.reg).subscribe(val=>{

     this.meinObj=val;
     console.log(this.meinObj);
      let b = JSON.stringify(val);

      this.this=JSON.parse(b);
      let mcgee=JSON.stringify(this.this.payment);
      this.any=JSON.parse(mcgee);
      let _id=this.any._id;
      console.log(_id);
      console.log(this.any);
      if(this.any.paid==true){
        this.completed=true;
      }
      console.log(this.thisPayment);
      console.log(this.this.payment);
      console.log(this.this.payment);

      this.mainMain.getAppointment(+this.any._id).subscribe(val=>{

        this.date=val.appointment.date.toString();
        this.name=val.appointment.name.toString();
        this.time=val.appointment.time.toString();
        this.email=val.appointment.email.toString();
        this.fromAddress=val.appointment.fromAddress.toString()
        this.toAddress=val.appointment.toAddress.toString();

      })
      if (this.any.paid=='true'){
        this.completed=true;
      }
      else{
      this.mainAmount=this.any.amount;
      this.details=this.any.information;
      this.showIt=true;
      console.log(val);
      }
    })

  }
  onCompleted(event:{status:boolean}){
    console.log(this.email)
    if(event.status==true){
      this.mainService.markPaymentComplete(this.ger,this.reg).subscribe(val=>{
        console.log(val);

      })
      setTimeout(()=> this.mainService.sendPaymentCompletion(this.email,this.any.amount).subscribe(val=>{

      }) ,500)
      setTimeout(()=>this.completed=true,900)
    }

  }
}


/* <div class='details'>
    <div class='center'><h3>Invoice Details</h3></div>
    <br>
    <div  class="lefty">
    <ul>
        <li>{{name}}</li>
        <li>{{date}} , {{time}}</li>
        <li>from {{fromAddress}} to {{toAddress}}</li>
        <li>{{mainAmount}}</li>

    </ul>
    </div>
    <br>
    <p>{{details}}</p>
</div>
<div>
<mat-card>
<app-payment *ngIf="showIt" [amount]="mainAmount"></app-payment>
</mat-card>
</div>*/
