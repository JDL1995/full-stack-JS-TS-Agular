
export interface Payment{
    _id:number,
    token:string,
    paid:boolean,
    amount:number,
    information:string
}
    