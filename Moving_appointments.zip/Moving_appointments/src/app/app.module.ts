import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { ErrorComponent } from './error/error.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './header/header.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { FrontpageAdminComponent } from './frontpageadmin/frontpageAdmin.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorInterceptor } from './error-interceptor';
import { LogoutComponent } from './logout/logout.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Browser } from 'protractor';
import { MatDialogModule } from '@angular/material/dialog';
import { AuthInterceptor } from './auth/auth-interceptor';
import { AppointmentService } from './appointment/appointment.service';
import { MainService } from './console/mainService/mainService.service';
import { MakeComponent } from './testimonials/make/make.component';
import { AngularMaterialModule } from './angular-material.module';
import { SelectorComponent } from './testimonials/make/selector/selector.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxImageCompressService } from 'ngx-image-compress';

@NgModule({
  declarations: [
    AppComponent,
    FrontpageComponent,
    FrontpageAdminComponent,
    ErrorComponent,
    HeaderComponent,
    LogoutComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    CommonModule,
    BrowserAnimationsModule,
    MatDialogModule,
    AngularMaterialModule,
    ReactiveFormsModule
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }, ],
  bootstrap: [AppComponent],
  entryComponents:[ErrorComponent]
})
export class AppModule { }
