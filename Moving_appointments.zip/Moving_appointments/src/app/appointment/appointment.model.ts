export interface Appointment{
    name:string;
    email:string;
    phone:number;
    addressTo:string;
    addressFrom:string;
    day:number;
    month:number;
    year:number;
    hour:number;
    minute:number;
    morningNight:string;
    contactType:string;
    additionalInfo:string;
}
export interface transfer{
    name:string;
    date:string;
    from:string;
    to:string;
    email:string;
    phone:number;
}