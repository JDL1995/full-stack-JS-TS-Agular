import { formatDate } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import {Form, FormControl, FormGroup, Validators} from '@angular/forms';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { OwlDateTime } from 'ng-pick-datetime/date-time/date-time.class';
import { NgxImageCompressService } from 'ngx-image-compress';
import { Appointment } from '../appointment/appointment.model';

import { mimeType } from './mime-type.validator';
import { map } from 'rxjs/operators';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { AppointmentService } from './appointment.service';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { MainService } from '../console/mainService/mainService.service';


// <div class="details"><div class="textual">The more information you can provide us, the easier it will be for us to give you a quick, accurate estimate</div></div>
@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppointmentComponent implements OnInit {
  public dateTime3:Date=new Date();
  public files:string[]=[];
  public biles:File[]=[];
  dates:string[]=[];
  public uploadCount:number=0;
  public dateTime4!:Date;
  public monkeyArray:File[]=[];
  public dateTime:Date=new Date();
  public dateTime5:Date=new Date();
  public dateTime6:String='';
  public showdate:boolean=false;
  public showTable:boolean=false;
  public form!:FormGroup;
  public form1!:FormGroup;
  public dateSelected:boolean=false;
  public thisAppointment!:Appointment;
  public dateFormatted!:string;
  public superMonkeyArray:Blob[]=[];
  public contactType!:string;
  public isLoading=false;
  public payShow=false;
  public mainAmount!:number;
  status=true;
  imagePreview: string[]=[];
  //public dt1!:OwlDateTime<>;
    constructor(private dialog: MatDialog,
      private snackBar: MatSnackBar,
      private mainService:AppointmentService,
      private extraMain:MainService,
      public imageCompress:NgxImageCompressService,
      private _cdr: ChangeDetectorRef) { }
      changeStatus(): void {
  
        setTimeout(() => {
          this.status = true;
          this._cdr.detectChanges()
        }, 1500);
       }
  paySome(){
    this.mainAmount=this.form1.value.amount;
    /*
    this.mainService.paySome().subscribe(val=>{
      console.log(val)
    })*/
    setTimeout(() =>    this.payShow=true,200);
  }   
   public  recursiveAddPhoto = (ogvalue:number,currentProductId:number, index:number, arr:number[])=>{
        return this.mainService.uploadFile(ogvalue,this.monkeyArray[currentProductId]).pipe(
            map((response)=>{
                return {
                    data:response,
                    index: index+1,
                    arr:arr
                }
            }))
    };
  
getList(){
  this.extraMain.getDates();
  this.extraMain.getDatesObs().subscribe(val=>{
    console.log(val);
    val.forEach((value, index) => {
      console.log(value)
      
      this.dates.push(value);

    })
  })
  /*
    console.log(val);
    let a = JSON.stringify(val);
    let d = JSON.parse(a);
    console.log(d)
    console.log(d.list);
  })*/
}

  async postPhoto(amen:number,file:File){
    return this.mainService.uploadFile(amen,file).subscribe(val=>{
      console.log(val)
    })
  
  }
  checkdate(date:Date){
    const locale = 'en-US';
  let thisOne=formatDate(date, 'shortDate',locale);
  if (thisOne=='4/10/21'){
    return false;
  }
    for (let a of this.dates){
      if (thisOne==a){
        return false;
      }
    }

    return true;
    
  }

  public myFilter = (d: Date|null): boolean => {
    const day=this.checkdate(d!);
    console.log(d);
   
    // Prevent Saturday and Sunday from being selected.
    return day
}
  onClose(){
    console.log(this.monkeyArray.length);
    let randomCounter=this.monkeyArray.length;
    this.mainService.submitAppointment(this.thisAppointment).subscribe(val=>{
      console.log(val);let z = JSON.stringify(val);
  let dang:{[key:string]:string}
  dang=JSON.parse(z);console.log(dang['a']);let amen= dang['a'];
    let meeng=this.biles.length
    let productIds:number[]=[];
    for(let a=0; a<=meeng;a++){productIds.push(a)}console.log(productIds)

    let loop = (id: number) => {
     console.log(productIds)
      this.mainService.uploadFile(+amen,this.superMonkeyArray[id]as unknown as File)
        .subscribe((result) => {
          console.log(result);
          // This logic can be modified to any way you want if you don't want to mutate the `producIds` array
          if (productIds.length) {
            console.log(productIds) 
            setTimeout(() =>  100);
            loop(productIds.shift()!)  }  }) }
    loop(productIds.shift()!)
    console.log(productIds)
    setTimeout(() => location.reload(),750);
  })
  
  }
    openDialog() 
    {
      const dialogRef = this.dialog.open(ConfirmationDialogComponent);
      //const snack = this.snackBar.open('Snack bar open before dialog');
  
      dialogRef.afterClosed().subscribe((showSnackBar: boolean) => {
        if (showSnackBar) {
         this.onClose();
         // snack.dismiss();
          const a = document.createElement('a');
          a.click();
          a.remove();
         // snack.dismiss();
          this.snackBar.open('Confirmation Email sent to '+this.thisAppointment.email, '', {
            duration: 2000,
          });
        }
      } );}
  
       dataURItoBlob(dataURI:string) {
        // convert base64 to raw binary data held in a string
        var byteString = atob(dataURI.split(',')[1]);
    
        // separate out the mime component
        var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    
        // write the bytes of the string to an ArrayBuffer
        var arrayBuffer = new ArrayBuffer(byteString.length);
        var _ia = new Uint8Array(arrayBuffer);
        for (var i = 0; i < byteString.length; i++) {
            _ia[i] = byteString.charCodeAt(i);
        }
    
        var dataView = new DataView(arrayBuffer);
        var blob = new Blob([dataView], { type: mimeString });
        return blob;
    }
    
      compressFile(x:number) {
    
        this.imageCompress.uploadFile().then(({image, orientation}) => {
        
         
          console.log('Size in bytes was:', this.imageCompress.byteCount(image));
          this.isLoading=true;
          this.imageCompress.compressFile(image, orientation, 50, 50).then(
            result => {
              this.files[x]=result;
              this.uploadCount=this.uploadCount+1;
              console.log('size in bytes is now',this.imageCompress.byteCount(result))
      const file0 = result as unknown as File;
     // this.compressFile(file0,this.uploadCount)
      this.form.patchValue({ image: file0 });
      this.monkeyArray.push(this.form.value.image)
      this.form.get("image")?.updateValueAndValidity();
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview[this.uploadCount-1] = reader.result as string;
      };
      const file2=this.dataURItoBlob(result as unknown as string); 
      this.superMonkeyArray[this.uploadCount-1]=file2;
      reader.readAsDataURL(file2);
      this.isLoading=false;
      this.changeStatus();
            })
          })
          
          }
  
  
    ngOnInit(): void {
      this.getList();
  this.imagePreview[0]='';
  this.form1 = new FormGroup({amount: new FormControl('')})
      this.form = new FormGroup({
        dateTime: new FormControl('',   {}),
        firstName: new FormControl('', {validators: [Validators.required, Validators.minLength(3)]
        }),lastName: new FormControl('', 
{validators: [Validators.required, Validators.minLength(3)]}),
address1: new FormControl('', {validators: [Validators.required, Validators.minLength(3)]
}),address2: new FormControl('',  {validators: [Validators.required, Validators.minLength(3)]
}),email: new FormControl('', {validators: [Validators.required, Validators.minLength(3)]
}),number: new FormControl('', {validators: [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(10)]}),
additionalInfo: new FormControl('', 
),contactType: new FormControl('', {}),image: new FormControl(null, {
          asyncValidators: [mimeType]})})}
          /*FormControl(null, {validators: [Validators.required],
          asyncValidators: [mimeType]})})}*/ 
    onChange(data:any){
      const locale = 'en-US';
      this.dateTime6=formatDate(this.form.value.dateTime, 'short', locale);
      //this.dateTime4=this.dateTime3;
      this.dateSelected=true; }
  async convertArray(){
    
    let biles:File[]=[];
    this.files.forEach(function (value, i) {
      biles[i]=value as unknown as File;
  });
  return biles;
  }
  
    submitter(){
      this.submit();
  
      this.mainService.confirmationInfo.next({
        date:this.dateFormatted,
        from:this.thisAppointment.addressFrom,
        to:this.thisAppointment.addressTo,
        name:this.thisAppointment.name,
        phone:this.thisAppointment.phone,
        email:this.thisAppointment.email
      })
     this.convertArray().then(biles=>{
       this.biles=biles;
     })
      this.openDialog();
    }
    submit(){
      this.dateTime5=this.form.value.dateTime;
      this.showdate=true;
      const locale = 'en-US';
      const formattedDate = formatDate(this.dateTime5, 'short', locale);
      this.dateFormatted=formattedDate;
      console.log(formattedDate);
      if(this.form.value.contactType==1){
        this.contactType='Call'
      }
      else{
        this.contactType='Text'
      }
      this.parseDate(formattedDate);
      this.showTable=true;
    }
  
    onImagePicked(event: Event) {
      this.uploadCount=this.uploadCount+1;
      const file0 = (event.target as HTMLInputElement).files![0];
     // this.compressFile(file0,this.uploadCount)
      this.form.patchValue({ image: file0 });
      this.form.get("image")?.updateValueAndValidity();
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview[this.uploadCount-1] = reader.result as string;
      };
      reader.readAsDataURL(file0);
    }
    parseDate(app:string){
      let day:number;
      let month:number;
      let hour:number;
      let minute:number;
      let year:number;
      let morningNight:string;
      let a = [...app];
      let counter=0;
      let lastPos=0;
      for(let [index, i] of a.entries()){
        if (i=='/' && counter==0){
          if(index==1){
            month=+a[0]
            counter=counter+1
            lastPos=index;
          }
          if(index==2){
            month=+a[0].concat(a[1])
            counter=counter+1;
            lastPos=index;
          }
  
        }
        if (i=='/' && counter==1){
          if (index==lastPos+2){
            day=+a[lastPos+1];
            lastPos=index;
          }
          if (index==lastPos+3){
            day=+a[lastPos+1].concat(a[lastPos+2]);
            lastPos=index;
          }
  
        }
        if (i==',' ){
          year=+a[index-2].concat(a[index-1]);
        }
        if (i==':' ){
          if(a[index-2]==' '){
             hour=+a[index-1]
          }
          else{
            hour=+a[index-2].concat(a[index-2]);
          }
          minute=+a[index+1].concat(a[index+2]);
  
  
        }
        if (i=='P'){
          morningNight='PM'
        }
        if (i=='A'){
          morningNight='AM'
        }
      }
      this.thisAppointment={
        name:(this.form.value.firstName+' ').concat(this.form.value.lastName),
        email:this.form.value.email,
        addressTo:this.form.value.address2,
        addressFrom:this.form.value.address1,
        phone:this.form.value.number,
        contactType:this.contactType,
        additionalInfo:this.form.value.additionalInfo,
        day:day!,
      month:month!,
      year:year!,
    hour:hour!,
  minute:minute!,
  morningNight:morningNight!}
    }
  
  
  }


  /*
  export class recursive{
    constructor(public mainService:MainService,){}
  
     recursiveAddPhoto = (ogvalue:number,currentProductId:number, index:number, arr:number[],monkeyArray:File[])=>{
    return this.mainService.uploadFile(ogvalue,monkeyArray[currentProductId]).pipe(
        map((response)=>{
            return {
                data:response,
                index: index+1,
                arr:arr,
                monkeyArray:monkeyArray
            }
        }))
  };
  }*/
  
  /*
  
  <div class="example-wrapper">
      <h2>Trigger Picker by a Icon</h2>
      <label class="example-input-wrapper">
          Date Time
          <input placeholder="Date Time:" [(ngModel)]="dateTime" [owlDateTime]="dt2">
          <span class="example-trigger" [owlDateTimeTrigger]="dt2">
              <i class="fas fa-calendar-alt"></i>
          </span>
          <owl-date-time [hour12Timer] = "true" #dt2></owl-date-time>
      </label>
  
      <h4>Value From Picker: {{dateTime}}</h4>
  </div>
  
  */
  