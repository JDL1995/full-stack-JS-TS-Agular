import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";

//import { SignupComponent} from "./signup/signup.component";
import { AngularMaterialModule } from "../angular-material.module";

import { SnackService } from "../auth/snack.service";
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { AppointmentRoutingModule } from './appointment-routing.module';
import { AppointmentComponent } from './appointment.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from '../auth/auth-interceptor';
import { ErrorInterceptor } from '../error-interceptor';
import { AppointmentService } from './appointment.service';
import { NgxImageCompressService } from 'ngx-image-compress';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SuccessModule } from '../success/success.module';
import { SuccessComponent } from '../success/success.component';
import { NgxStripeModule } from 'ngx-stripe';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { PaymentComponent } from '../payment/payment.component';
import { PaymentPageComponent } from '../payment/payment-page/payment-page.component';
import { MainService } from '../console/mainService/mainService.service';

@NgModule({
  declarations: [AppointmentComponent,ConfirmationDialogComponent,PaymentComponent,PaymentPageComponent],
  imports: [
    CommonModule, AngularMaterialModule, FormsModule, RouterModule,
    MatCardModule,MatIconModule,AppointmentRoutingModule, OwlDateTimeModule,
    OwlNativeDateTimeModule, ReactiveFormsModule,MatDialogModule,
     HttpClientModule,MatButtonModule,SuccessModule, NgxStripeModule.forRoot('pk_test_51IdOqiLh3XJnPTEj9ktgWZap1DAB6qNDaKKBLpXypO7KjxmdXLuQDOPS9Jf60epnCXdFX23z2RGcjteXB8gCexAC00P7bau8qf')
  ],
  providers:[ 
    NgxImageCompressService,MainService],
    entryComponents:[SuccessComponent]
})
export class AppointmentModule { }