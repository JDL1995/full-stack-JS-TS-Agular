import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AppointmentComponent } from '../appointment/appointment.component';
import { PaymentPageComponent } from '../payment/payment-page/payment-page.component';

//import { SignupComponent } from "./signup/signup.component";

const routes: Routes = [
  { path: "", component: AppointmentComponent },
  { path: ":id/:token", component: PaymentPageComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class AppointmentRoutingModule {}