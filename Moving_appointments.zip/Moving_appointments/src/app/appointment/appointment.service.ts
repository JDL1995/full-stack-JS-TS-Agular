import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { map } from "rxjs/operators";
import { Router } from "@angular/router";
import { transfer } from "../appointment/appointment.model"
//import { environment } from "../environments/environment";
import { Appointment } from "../appointment/appointment.model"
import { FormattedAppointment, FormattedAppointment2, FormattedAppointment3 } from "../formattedAppointment.model"
//import { Post } from "./posts/post.model";

//import { stringToKeyValue } from "@angular/flex-layout/extended/typings/style/style-transforms";
import { AuthData } from "../auth/auth-data.model";
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { domain } from 'process';
import { _MatDialogContainerBase } from '@angular/material/dialog';
import { formatDate } from '@angular/common';
import { _DisposeViewRepeaterStrategy } from '@angular/cdk/collections';
import { StripeService, StripeCardComponent } from 'ngx-stripe';
import {
  StripeCardElementOptions,
  StripeElementsOptions
} from '@stripe/stripe-js';
import {Token} from  "@stripe/stripe-js"
import { listLazyRoutes } from '@angular/compiler/src/aot/lazy_routes';
import { Testimonial } from './testimonial.model';
import { Hero } from '../testimonials/make/selector/hero.model';
const appointment_url =  "http://localhost:3000/api/appointments";
const admin_url = "http://localhost:3000/admin/console";
const appointment_confirm_url="http://localhost:3000/api/confirm"
//const sendBackR="http://localhost:3000/admin/reset/resetit";
//const setBackR="http://localhost:3000/users/reset/confirmit";
@Injectable({ providedIn: "root" })
export class AppointmentService {
    private store:transfer={name:'',from:'',to:'',date:'',phone:1,email:''};
    private token!:string;
    public testimonials!:Testimonial[];
   public a:Testimonial={_id:'',name:'',date:'',testimony:'',image:'',isvisible:true};
   public b:Testimonial[]=[]
    public testimonialsUpdated = new Subject<{testimonials:Testimonial[]}>();
    public heroesUpdated = new Subject<{heroes:Hero[]}>();

    public confirmationInfo = new BehaviorSubject<transfer>(this.store);
    public postedata:any;
    public postedata2:any;
    public heroes!:Hero[];
    constructor(private http: HttpClient, private router: Router) {

    }
  
getSingle(token:string,email:string){
  let a={token:token,email:email}
  return this.http.post('http://localhost:3000/api/testimonials/getSingle',a)
}
    markPaymentComplete(_id:number,token:string){
      let a={_id:_id,
      token:token}
      return this.http.post('http://localhost:3000/api/pay/jdflakcj28vlk4v84vj9',a);

    }
    paySome(){
      var a={yes:'1'}
       return this.http.post('http://localhost:3000/api/pay',a);
     }
     getPayment(_id:number,token:string){

       var a={_id:_id,token:token}
       console.log(a);
      return this.http.post('http://localhost:3000/api/pay/get',a);
     }

     createCharge(amount:number,token:string){

      var a={amount:amount,token:token};

      return this.http.post('http://localhost:3000/api/pay/charge',a);

     }

   getIntent(amount:number){
    var a={amount:amount}
    return this.http.post('http://localhost:3000/api/pay/intent',a);
   }
submitAppointment(appointment:Appointment){
 
    console.log(appointment.email);
    let a=Object.keys(appointment).length;
    let daz=Object.entries(appointment);
    var alabamaMan:{[key:string]:string}={};
    console.log(a);
    let d=Object.keys(appointment);
    for (let y of d){
      for (let maz of daz){
        if (maz[0]==y){
          alabamaMan[y]=maz[1];
          console.log(maz[1])
        }
      }
    
    }
    
    console.log(alabamaMan);

    const postData = new FormData();

 // postData.append("image",files2);
    postData.append("name", appointment.name);
    postData.append("phone",appointment.phone.toString());
    postData.append("email",'sooo long gaybooooysss!!');
    postData.append("month",appointment.month.toString());
    postData.append("day",appointment.day.toString());
    postData.append("year",appointment.year.toString());
    postData.append("hour",appointment.hour.toString());
    postData.append("minute",appointment.minute.toString());
    postData.append("from",appointment.addressFrom);
    postData.append("to",appointment.addressTo);
    postData.append("morningNight",appointment.morningNight);
    postData.append("contactType",appointment.contactType);
    postData.append("additionalInfo",appointment.additionalInfo);
   
    return this.http.post(
        appointment_url,
        alabamaMan
      )
    /*
    .subscribe(response=>{
      console.log(response);
    let z = JSON.stringify(response);
    let dang:{[key:string]:string}
    dang=JSON.parse(z);
    console.log(dang['a']);

  
        let amen= dang['a'];
        this.ideer.next(amen);

    });
    */ 
   


  }
  uploadFile(a:number,file:File){
    const postData=new FormData();
    //console.log(x);
    console.log(a);
    postData.append("a", a.toString());
    postData.append("image", file);
    return this.http.post(
      appointment_url+"/photos",
      postData
    )
    
  }

  getTestimonialsAdmin():Promise<boolean> {
    this.http
      .get<{ message: string; testimonials: any; }>(
        'http://localhost:3000/api/testimonials/admin'
      )
      .pipe(
        map(postData => {
          this.postedata=postData;
         
          if(this.postedata.testimonials){
          return {
            testimonials: postData.testimonials.map((testimonial: {_id:string; name: any; date: any; isVisible:boolean;testimony:any;image:string}) => {
              let ah:boolean;
              let image;
              if(testimonial.isVisible==true){
                  ah=true;
              }
              else{
                ah=false;
              }
              if(!testimonial.image){
                 image=''
              }
              else{
                 image=testimonial.image
              }
              return {
                _id:testimonial._id,
                testimony:testimonial.testimony,
                name:testimonial.name,
                isVisible:testimonial.isVisible,
                date:testimonial.date,
                image:image
               
              };
            })
            
          };}
          else{
            return{
              testimony:'not available',
              name:'not available',
              isvisible:'not available',
              date:'not available',
            image:'not available'}}
        })
      )
      .subscribe(transformedPostData => {
        if(transformedPostData.testimonials){
        this.testimonials = transformedPostData.testimonials;
        
        this.testimonialsUpdated.next({
          testimonials: [...this.testimonials]
        });
      }});
      return new Promise((resolve, reject) => { resolve(true); })
  }
changeVisibility(idList:string[]){
  let a={idList:idList}
  return this.http.post('http://localhost:3000/api/testimonials/change',a)
}
  getTestimonials():Promise<boolean> {
    this.http
      .get<{ message: string; testimonials: any; }>(
        'http://localhost:3000/api/testimonials'
      )
      .pipe(
        map(postData => {
          this.postedata=postData;
         
          if(this.postedata.testimonials){
          return {
            testimonials: postData.testimonials.map((testimonial: {name: any; date: any; isVisible:boolean;testimony:any;image:string}) => {
              let ah:boolean;
              let image;
              if(testimonial.isVisible==true){
                  ah=true;
              }
              else{
                ah=false;
              }
              if(!testimonial.image){
                 image=''
              }
              else{
                 image=testimonial.image
              }
              return {
                _id:'',
                testimony:testimonial.testimony,
                name:testimonial.name,
                isVisible:testimonial.isVisible,
                date:testimonial.date,
                image:image
               
              };
            })
            
          };}
          else{
            return{
              testimony:'not available',
              name:'not available',
              isvisible:'not available',
              date:'not available',
            image:'not available'}}
        })
      )
      .subscribe(transformedPostData => {
        if(transformedPostData.testimonials){
        this.testimonials = transformedPostData.testimonials;
        
        this.testimonialsUpdated.next({
          testimonials: [...this.testimonials]
        });
      }});
      return new Promise((resolve, reject) => { resolve(true); })
  }
  getTestimonialsUpdateListener() {
    return this.testimonialsUpdated.asObservable();
  }
  getHeroes():Promise<boolean> {
    this.http
      .get<{ message: string; Heroes: any;   }>(
        'http://localhost:3000/api/testimonials/heroes'
      )
      .pipe(
        map(postData => {
          this.postedata2=postData;
         
          if(this.postedata2.Heroes){
          return {
            heroes: postData.Heroes.map((hero: {_id: any; picture:any; }) => {
             
              return {
                _id:hero._id,
                img:hero.picture
               
              };
            })
            
          };}
          else{
            return{
              _id:'not available',
              img:'not available',
              }}
        })
      )
      .subscribe(transformedPostData => {
        if(transformedPostData.heroes){
        this.heroes = transformedPostData.heroes;
        
        this.heroesUpdated.next({
          heroes: [...this.heroes]
        });
      }});
      return new Promise((resolve, reject) => { resolve(true); })
  }
  getHeroesUpdated() {
    return this.heroesUpdated.asObservable();
  }
  postTestimonial(_id:string,name:string,body:string,date:string){
    let a={name:name,body:body,date:date}
   return this.http.post('http://localhost:3000/api/testimonials',a)
  }
  upload(file:File){
    const postData=new FormData();
    //console.log(x);
    
    
    postData.append("image", file);
    return this.http.post(
      'http://localhost:3000/api/testimonials/withImage',
      postData
    )
    
  }
  async witImage(a:object):Promise<string>{
    return new Promise(resolve=>{ this.http.post<{_id:string}>('http://localhost:3000/api/testimonials/withImage',a).subscribe(val=>{
      console.log(val)
      resolve(val._id)
     })})
     
  }
  async witImageDos(a:string,b:File):Promise<any>{
    var postData=new FormData();
    postData.append("id", a);
    postData.append("image",b)
    return new Promise(resolve=>{ this.http.post(
      'http://localhost:3000/api/testimonials/withImage2',
      postData).subscribe(val=>{
       resolve(val)
      })})

  }
  async postTestimonialWithImage(_id:string,name:string,body:string,date:string,image:File):Promise<any>{
    console.log(image);
    const postData = new FormData();
  
    

    let a={_id:_id,name:name,body:body,date:date}
    console.log(a);
     var z=await this.witImage(a).then(val=>{
      return this.witImageDos(val,image);
       
    })
    return z
  }
  postTestimonialWithHero(_id:string,name:string,body:string,date:string,hero:string){
    let a={name:name,body:body,date:date,hero:hero}
return this.http.post('http://localhost:3000/api/testimonials/withHero',a)
  }
  runTheHeroes(){
    let a={};
    return this.http.post('http://localhost:3000/api/testimonials/heroes',a)
  }
  getAHero(_id:string){
    let a={_id:_id};
    return this.http.post('http://localhost:3000/api/testimonials/heroes/one',a)
  }
  sendPaymentCompletion(email:string,amount:string){
    console.log(email)
    let a={email:email,amount:amount}
    return this.http.post('http://localhost:3000/api/appointments/complete',a)
  }
}