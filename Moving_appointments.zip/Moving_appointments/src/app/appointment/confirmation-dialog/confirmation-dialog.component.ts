import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { AppointmentService } from '../appointment.service';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmationDialogComponent implements OnInit {
  public from!:string;
  public to!:string;
  public name!:string;
  public date!:string;
  public email!:string;
  public phone!:number;
  constructor(
    public dialogRef: MatDialogRef<ConfirmationDialogComponent>,
    public mainService:AppointmentService) { }

    ngOnInit(){
      this.mainService.confirmationInfo.subscribe(info=>{
        this.from=info.from;
        this.to=info.to;
        this.name=info.name;
        this.date=info.date;
        this.email=info.email;
        this.phone=info.phone;

      })
    }
  onYesClick(): void {
    this.dialogRef.close(true);

  }

}