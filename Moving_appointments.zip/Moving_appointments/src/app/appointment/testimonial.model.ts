export interface Testimonial{
    _id:string,
    name:string,
    date:string,
    testimony:string,
    isvisible:boolean,
    image:string
}