import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
//import { ConfirmService } from 'src/app/confirm.service';
import { Subscription } from 'rxjs';

import { FormsModule } from "@angular/forms";
import { AuthData } from '../auth-data.model';
import { ConfirmService } from '../confirm.service';
import { SnackService } from '../snack.service';


@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class ForgotComponent implements OnInit {
  private fineal!:string;
  message!:string;
  public gerry!:{[key: string]:string}
  public display!:string;
  public ger!:string;
  public reg!:string;
  private authStatusSub!: Subscription;
  isLoading = false;
  public hasSent!:boolean;
  constructor(
    public confirmService:ConfirmService,
    private snack:SnackService) { }

  ngOnInit() {
    this.hasSent=false;
  }
  
  async getConditionalDataUsingAsync(deet:string) {
    return deet;
    console.log('No issues, I will wait until promise is resolved..');
  }

  onSubmit(form:NgForm){
    this.confirmService.sendReset(form.value.email).subscribe(response=>{
      this.message=JSON.stringify(response);
      this.gerry=JSON.parse(this.message);
      this.fineal=this.gerry.message;
      
      this.getConditionalDataUsingAsync(this.fineal).then(value=>{
        this.notify(value);
      });
      this.isLoading=false;
      this.hasSent=true;
      //this.mam.message=this.gerry.message;
     
  });
  }

  notify(input:string){
    
    //this.anus=JSON.stringify(this.fineal);
    this.snack.updateDataSelection(input);
    this.snack.notification$.next();
  }


}
