import { Inject, Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject,BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { Router } from "@angular/router";
//import { msgOb } from "src/app/msgOb.model";
import { InjectionToken } from "@angular/core";
import { MAT_STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";

//export const UNIQUE_ID = new InjectionToken<string>(messae);
//const messae:string='';
//export const UNIQUE_ID_PROVIDER = {
 //   provide: UNIQUE_ID
//};
//export const tokens: Map<string, InjectionToken<SnackService>> = new Map();
 
@Injectable({ providedIn: "root" })
export class SnackService{
    //public deea:msgOb;
    public str: String = new String("Hello world");
    public becaz!:string;
    
    public notificationSource$: BehaviorSubject<string> = new BehaviorSubject('');
    public mcGee=this.notificationSource$.asObservable();

    public notification$: Subject<string> = new Subject();
  constructor(){}
  updateDataSelection(data: string){
      this.str=data;
      this.notificationSource$.next(data);
  }
  getDataSelection(){
    
  }
  generate(){

  }


}
