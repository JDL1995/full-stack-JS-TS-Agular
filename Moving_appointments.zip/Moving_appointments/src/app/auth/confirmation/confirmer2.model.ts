export interface confirmer2{
    email:string;
    token:string;
    password:string;
}