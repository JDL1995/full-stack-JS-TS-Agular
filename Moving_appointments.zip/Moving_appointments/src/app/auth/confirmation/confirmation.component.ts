import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { ConfirmService } from '../confirm.service';
import { confirmer } from './confirmer.model';
@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit {
  message!:string;
  public gerry!:{[key: string]:string}
  public display!:string;
  public ger!:string;
  public reg!:string;
  public showSuccess=false;
  private authStatusSub!: Subscription;
  isLoading = false;
  public xk2!:confirmer;
    constructor(
      public confirmService:ConfirmService,
      public route:ActivatedRoute
      ) { }
  public isShown:boolean=false;
    ngOnInit() {

      this.isShown=true;
     // this.route.paramMap.subscribe(params => {
      //    this.xk2.email=params.get('email');
     //     this.xk2.token=params.get('token');
     //   });
      this.ger=this.route.snapshot.params['email'];
      this.reg=this.route.snapshot.params['token'];
        this.confirmService.confirmAccount(this.ger,this.reg)
        .subscribe(response=>{
            this.message=JSON.stringify(response);
            this.gerry=JSON.parse(this.message);
            if(this.gerry.message=="success"){
              this.showSuccess=true;
            }
        })

      }

    }
