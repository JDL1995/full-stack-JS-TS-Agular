export interface confirmer{
    email:string;
    token:string;
}