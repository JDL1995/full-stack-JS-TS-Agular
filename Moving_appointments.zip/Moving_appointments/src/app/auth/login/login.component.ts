import { Component, OnInit, OnDestroy } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Router } from '@angular/router';
import { Subscription } from "rxjs";

import { AuthService } from "../auth.service";

@Component({
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"]
})
export class LoginComponent implements OnInit, OnDestroy {
  public gerry!: { [key: string]: string; };
  public message!:string;
  public final!:string;
  isLoading = false;
  private authStatusSub!: Subscription;

  constructor(public authService: AuthService, public router:Router) {}

  ngOnInit() {
    this.authStatusSub = this.authService.getAuthStatusListener().subscribe(
      authStatus => {
        this.isLoading = false;
      }

    );
    document.body.className = "selector";
    this.authService.everyTime().subscribe(message=>{
      this.message=JSON.stringify(message);
    this.gerry=JSON.parse(this.message);
    this.final=this.gerry.message;
    console.log(this.final);
    this.authService.goAhead.subscribe(val=>{
      this.router.navigate(['/auth/signup238rufuj289vhj2nvcrn2r3782r392nr9vjfksldfv'])

    })
    if(this.final=='go'){
      this.authService.goneAhead.next('okay');
      this.authService.goAhead.next()
    }

    })

  
  }
  oneTime(){
    this.authService.oneTime().subscribe(val=>{
      console.log(val);
    })

  }

  onLogin(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.isLoading = true;
    this.authService.login(form.value.email, form.value.password);
  }

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
  }
}
