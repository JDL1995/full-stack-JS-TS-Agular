import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { ResetComponent } from './confirmation/reset/reset.component';
import { ForgotComponent } from './forgot/forgot.component';

import { LoginComponent } from "./login/login.component";
import { SignupComponent } from './signup/signup.component';
//import { SignupComponent } from "./signup/signup.component";

const routes: Routes = [
  { path: "login893475934789gifhefgskskgj58967279gkfdhsjv", component: LoginComponent },
  { path: "reset/:email/:token", component:ResetComponent},
  { path: "confirm957439920458714/:email/:token", component:ConfirmationComponent},
  { path: "reset8732iuryfds7i4uhf78h24fksdhf2iuh824844858792/:email/:token", component:ResetComponent},
  { path: "signup238rufuj289vhj2nvcrn2r3782r392nr9vjfksldfv", component:SignupComponent},
  { path: "forgot8732iuryfds7i4uhf78h24fksdhf2iuh824844858792",component:ForgotComponent}
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class AuthRoutingModule {}
