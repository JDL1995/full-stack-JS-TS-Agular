import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { LoginComponent } from "./login/login.component";
//import { SignupComponent} from "./signup/signup.component";
import { AngularMaterialModule } from "../angular-material.module";
import { AuthRoutingModule } from "./auth-routing.module";
import { SnackService } from "./snack.service";
import { ForgotComponent } from './forgot/forgot.component';
import { ResetComponent } from './confirmation/reset/reset.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { MatCardModule } from '@angular/material/card';
import { SignupComponent } from '../auth/signup/signup.component';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [LoginComponent, SignupComponent, ConfirmationComponent,ForgotComponent,ResetComponent],
  imports: [
    CommonModule, AngularMaterialModule, FormsModule, AuthRoutingModule,RouterModule,MatCardModule,MatIconModule
  ]
})
export class AuthModule { }