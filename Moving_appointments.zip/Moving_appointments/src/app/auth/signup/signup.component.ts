import { Component, OnInit, OnDestroy,Input,Inject } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Subscription } from "rxjs";
import {
  MatSnackBarRef,
  MAT_SNACK_BAR_DATA
} from "@angular/material/snack-bar";
import { AuthService } from "../auth.service";
import {MatSnackBar
} from '@angular/material/snack-bar';
import { SnackService } from "../snack.service";
//import {msgOb } from "./msgOb.model"
//import { stringToKeyValue } from "@angular/flex-layout/extended/typings/style/style-transforms";

@Component({
  templateUrl: "./signup.component.html",
  styleUrls: ["./signup.component.scss"]
})
export class SignupComponent implements OnInit, OnDestroy {
  private message!: string;
  //gerry: string[]=[];
  //gerry: string[]=[];
  public gerry!: { [key: string]: string; };
  isLoading = false;
  //private horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  //private verticalPosition: MatSnackBarVerticalPosition = 'top';
  //private horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  //private verticalPosition: MatSnackBarVerticalPosition = 'top';
  private authStatusSub!: Subscription;
  public fineal!: string;
  public anus!: string;
  public hasSent!: boolean;
  public canShow:boolean=false;
  one = new Promise<string>((resolve, reject) => {});
  constructor(public authService: AuthService,
   private snack:SnackService,
   
   // private _snackbar:MatSnackBar
    ) {}

  ngOnInit() {
    this.authService.goneAhead.subscribe(val=>{
      if(val=='okay'){
        this.canShow=true;
      }

    })
    this.hasSent=false;
    this.authStatusSub = this.authService.getAuthStatusListener().subscribe(
      authStatus => {
        this.isLoading = false;
      }
    );
  }
  async getConditionalDataUsingAsync(deet:string) {
    return deet;
    console.log('No issues, I will wait until promise is resolved..');
  }
  

 

  onSignup(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.isLoading = true;
    this.authService.createUser(form.value.email, form.value.password, form.value.phone).subscribe(response=>{
      this.message=JSON.stringify(response);
      this.gerry=JSON.parse(this.message);
      this.fineal=this.gerry.message;
      
      this.getConditionalDataUsingAsync(this.fineal).then(value=>{
        this.notify(value);
      });
      this.isLoading=false;
      this.hasSent=true;
      //this.mam.message=this.gerry.message;
     
  });

  
  
  //this.ohBaby.jesus=this.gerry.message;
  // this._snackbar.openFromComponent(SuccessComponent,{duration:5000});
  }
  notify(input:string){
    
    //this.anus=JSON.stringify(this.fineal);
    this.snack.updateDataSelection(input);
    this.snack.notification$.next();
  }
  meinString(dasPut:string){
      return dasPut;
  }
  
  /*
  openSnackBar(details) {
    var details2=details;
    if(this.gerry.message){details2=this.gerry.message}
    this._snackbar.open(details2, 'End now', {
      duration: 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
  
  <snack-bar-component-example-snack [jesus]="gerry.message"></snack-bar-component-example-snack>
  */

  ngOnDestroy() {
    this.authStatusSub.unsubscribe();
  }
}
