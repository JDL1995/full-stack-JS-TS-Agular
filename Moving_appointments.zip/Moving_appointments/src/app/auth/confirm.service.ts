import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { map } from "rxjs/operators";
import { Router } from "@angular/router";

//import { environment } from "../environments/environment";
//import { Post } from "./posts/post.model";
import {confirmer} from "./confirmation/confirmer.model";
import {confirmer2} from "./confirmation/confirmer2.model";
//import { stringToKeyValue } from "@angular/flex-layout/extended/typings/style/style-transforms";
import { AuthData } from "../auth/auth-data.model";
const BACKEND_URL =  "http://localhost:3000/users/confirmation";
const sendBackR="http://localhost:3000/users/reset/resetit";
const setBackR="http://localhost:3000/users/reset/confirmit";
@Injectable({ providedIn: "root" })
export class ConfirmService {
  
  private token!:string;
  private confirmStatusListener = new Subject<boolean>();
  private email!:string;
  //private posts: Post[] = [];
  //private postsUpdated = new Subject<{ posts: Post[]; postCount: number }>();
  public newUrl!:string;
  constructor(private http: HttpClient, private router: Router) {}

  getConfirmStatusListener(){
  return this.confirmStatusListener.asObservable();
  }

  /*
  preConfirmAccount(email:string,token:string){
    const mcGee:confirmer={email:email, token:token};
    var purl:string='/';
     this.newUrl=BACKEND_URL.concat(mcGee.email.concat(purl.concat(mcGee.token.toString())));

     return this.newUrl;
   // this.http.post(this.newUrl, mcGee);
    }*/
    tokenExpiration(token:string){
      let transporter={token:token}
      return this.http.post('http://localhost:3000/users/checkToken',transporter)
      
    }
    
  confirmAccount(email:string,token:string){
    var reso;
    const mcGee:confirmer={email:email, token:token};
    var purl:string='/';
     //this.newUrl=BACKEND_URL.concat(mcGee.email.concat(purl.concat(mcGee.token.toString())));

      return this.http.post(BACKEND_URL, mcGee);

    }

    resetPass(email:string,token:string,password:string){
      const mcGee:confirmer2={email:email, token:token, password:password};
      return this.http.post(setBackR, mcGee);
  
    }

    sendReset(value: any){
      const mcGee:AuthData= { email: value, password: '' };
      return this.http.post(sendBackR,mcGee);
    }
    
    

  
}
