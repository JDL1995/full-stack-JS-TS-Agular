

const Appointment = require("../models/appointment");



class Rectangle {
    constructor(datelist) {
     this.datelist= datelist;
    }
   
    add(Appointment){
      if (Appointment.confirmed==true){
        this.datelist.push(Appointment.date)
      }
    }
   getList(Appointments){
      Appointments.forEach(element => this.add(element));
      return this.datelist;
    }
  }
  
  
  
  exports.getDates = (req, res, next) => {
  console.log('okay')
    const postQuery = Appointment.find();
    const rectangle= new Rectangle();
    let fetchedPosts;
    postQuery
      .then(documents => {
        console.log('fetchedPosts')
       fetchedPosts = documents;
      let ba= rectangle.getList(fetchedPosts)
        console.log(fetchedPosts);
        res.status(200).json({
            message:'fuck',
          list: ba
        });
      }).catch(error => {
        res.status(500).json({
          message: "Fetching appointments failed!"
        });
      });
  };
   