
const Appointment = require("../models/appointment");
const PostAdmin=require('../models/postAdmin');
const recordId=require('../models/recordId');
const pictureBlock=require('../models/pictureBlock');
const User=require('../models/user');
var nodemailer = require("nodemailer");

var AWS = require('aws-sdk');
AWS.config.update({region:'us-east-2'});

require('dotenv').config();
//require('dotenv').config({ path: '../full/custom/path/to/your/env/vars' })
getMainEmail=async()=>{
 const query= User.find();

  return query.then(user=>{
    console.log(user);
    console.log(user[0]);
    let c=user[0];
    console.log(c);
    console.log(c.email);
    return c.email;

  })


}
sendMail1= async(req)=>{
  let resp= await sendMail(req);
  // log or process resp;
   return resp;
}
sendMail3= async(req)=>{
  let resp= await sendMail2(req);
  // log or process resp;
   return resp;
}

async function sendMail(req,res,next){
  var userMail=req.mail;
  var body=req.body;
  var date=req.date;
  var from=req.from;
   host = '//localhost:4200';
   return new Promise((resolve,reject)=>{
   var transporter = nodemailer.createTransport({ host: "smtp.gmail.com", port:465, secure:true, auth: { user: "jon@jonlathrop.tech", pass: "sjrdgtxtaaiwdciz"}  });
   /*
   transporter.verify(function(error, success) {
     if (error) {
          console.log(error);
     } else {
          console.log('Server is ready to take our messages');
     }
  });*/
   var mailOptions = { from: 'jon@jonlathrop.com', to: userMail, subject: 'Fitzgerald Moving Services', html:'<p>Your appointment with Fitzgerald Moving Services is confirmed for ' + date + ' at the address: ' + from +'<br>'+body+' </p>'+'<br> Please call us at xxx-xxx-xxxx if you need to contact us for any reason'};
   transporter.sendMail(mailOptions, function (err) {
       if (err){
        console.log("error is "+err);
        resolve(false);
       }
       else{
        console.log('Email sent ');
        resolve(true);
       }
   });})


 }
 async function sendMail2(req,res,next){
  var userMail=req.mail;
  var body=req.body;
  var date=req.date;
  var from=req.from;
   host = '//localhost:4200';
   return new Promise((resolve,reject)=>{
   var transporter = nodemailer.createTransport({ host: "smtp.gmail.com", port:465, secure:true, auth: { user: "jon@jonlathrop.tech", pass: "sjrdgtxtaaiwdciz"}  });
   /*
   transporter.verify(function(error, success) {
     if (error) {
          console.log(error);
     } else {
          console.log('Server is ready to take our messages');
     }
  });*/
   var mailOptions = { from: 'jon@jonlathrop.com', to: userMail, subject: 'New Appointment ', html:'<p>A customer has made a new appointment for' + date + ' at the address: ' + from +'<br> any additional information:'+body+' </p>'+'<br> Please call us at xxx-xxx-xxxx if you need to contact us for any reason'};
   transporter.sendMail(mailOptions, function (err) {
       if (err){
        console.log("error is "+err);
        resolve(false);
       }
       else{
        console.log('Email sent ');
        resolve(true);
       }
   });})


 }
 async function sendMail5(req,res,next){
  var userMail=req.mail;

   host = '//localhost:4200';
   return new Promise((resolve,reject)=>{
   var transporter = nodemailer.createTransport({ host: "smtp.gmail.com", port:465, secure:true, auth: { user: "jon@jonlathrop.tech", pass: "sjrdgtxtaaiwdciz"}  });
   /*
   transporter.verify(function(error, success) {
     if (error) {
          console.log(error);
     } else {
          console.log('Server is ready to take our messages');
     }
  });*/
   var mailOptions = { from: 'jon@jonlathrop.com', to: userMail, subject: 'New Appointment ', html:'<p>We have received your moving appointment request, please give us a moment to review the details and respond to your request with a confirmation email <br> Fitzgerald Moving Services<br> xxx-xxx-xxxx'};
   transporter.sendMail(mailOptions, function (err) {
       if (err){
        console.log("error is "+err);
        resolve(false);
       }
       else{
        console.log('Email sent ');
        resolve(true);
       }
   });})


 }
 sendMail6= async(req)=>{
  let resp= await sendMail5(req);
  // log or process resp;
   return resp;
}


exports.postPhotos = (req, res, next) => {
 // req.body.a
 //console.log(req.file.filename)
 const url = req.protocol + "://" + req.get("host");
 if(req.file){


 let next1 = url.concat("/images/"+req.file.filename);
  pictureBlock.findOne({_id:req.body.a}).then(pb=>{
    if(pb.photos!=null){
    mayne=pb.photos;}
    else{
      mayne=[];
    }
    mayne.push(next1);
    pb.photos=mayne
    pb.save().then(createdPost => {
      console.log('memer');
      res.status(201).json({
        message: "Photo really added successfully"
       /* appointment: {
          ...createdPost,
          id: createdPost._id
        }*/
      });
    })
    .catch(error => {
      res.status(500).json({
        message: "Adding photo failed!"
      });
    });


  })

}
else{

  res.status(201).json({
    message: "Photos added successfully"
   /* appointment: {
      ...createdPost,
      id: createdPost._id
    }*/
  });

}
}
exports.getAppointment = (req, res, next) => {
  console.log(req.query._id);
  let deemerreeemerheeemer=+req.query._id;
  Appointment.findOne({_id:{$eq:deemerreeemerheeemer}}).then(app=>{
    res.status(200).json({appointment:app})
  }
  ).catch(error => {
    res.status(500).json({
     message: "getting appointment failed! "
   });
 });

}
exports.setPaid = (req, res, next) => {
  console.log(req.body.bady);
  console.log(req.body._id);
  let deemerreeemerheeemer=+req.body._id;
  Appointment.findOne({_id:{$eq:deemerreeemerheeemer}}).then(app=>{
app.paid=true;
res.status(201).json({message:'set paid complete'})

  }).catch(error=>{
    console.log(error);
  })

}

exports.appointmentConfirm = (req, res, next) => {
  console.log(req.body.bady);
  console.log(req.body._id);
  let deemerreeemerheeemer=+req.body._id;
  Appointment.findOne({_id:{$eq:deemerreeemerheeemer}}).then(app=>{

    var options={mail:app.email, body:req.body.bady, date:app.date,from:app.fromAddress}
    app.confirmed=true;

    app.save().then(sendMail1(options).then(result => {
      console.log(result);
      if (result  ==true){
        console.log('anally true')
        res.status(201).json({
          message: "Success! Confrimation Email sent to "+app.email
        });

      }
      if (result  ==false){
        res.status(402).json({
          message: "sending the email failed! Check that it is a valid Email Address"
        });

      console.log('anally false')


      }
    // let b= MakeQuerablePromise(result);
     console.log('anal mcgee');
     console.log('|');
     console.log('|');
     console.log('|');
     //onsole.log("Final fulfilled: ", b.isFulfilled());
   // console.log("Final rejected: ", b.isRejected());
      console.log(result);




    })).catch(error => {
       res.status(500).json({
        message: "sending the email failed! Check that it is a valid Email Address"
      });
    });



})

}
function MakeQuerablePromise(promise) {
  // Don't modify any promise that has been already modified.
  if (promise.isResolved) return promise;

  // Set initial state
  var isPending = true;
  var isRejected = false;
  var isFulfilled = false;

  // Observe the promise, saving the fulfillment in a closure scope.
  var result = promise.then(
      function(v) {
          isFulfilled = true;
          isPending = false;
          return v;
      },
      function(e) {
          isRejected = true;
          isPending = false;
          throw e;
      }
  );

  result.isFulfilled = function() { return isFulfilled; };
  result.isPending = function() { return isPending; };
  result.isRejected = function() { return isRejected; };
  return result;
}

exports.cancelAppointment = (req, res, next) => {
  Appointment.findOne({_id:req.body._id}).then(appointment=>{
    appointment.cancelled=true;
    appointment.save().then(result=>{
      res.status(200).json({message:'Your mother is a bitch'})
    }).catch(error=>{  res.status(500).json({
      message: "didn't cancel appointment!"
    });

    })

  })

}
exports.completeAppointment = (req, res, next) => {
  Appointment.findOne({_id:req.body._id}).then(appointment=>{
    appointment.completed=true;
    appointment.save().then(result=>{
      res.status(200).json({message:'Your mother is a bitch'})
    }).catch(error=>{  res.status(500).json({
      message: "didn't complete appointment!"
    });

    })

  })

}
async function sendNotify(){
  console.log(process.env.AWS_REGION);

/*
  console.log("Message = " + req.message);
  console.log("Number = " + req.number);
  console.log("Subject = " + req.query.subject); */


  var message="you have received a new appointment request";
  var params = {
      Message: message,
      PhoneNumber: '18329298971',
      MessageAttributes: {
          'AWS.SNS.SMS.SenderID': {
              'DataType': 'String',
              'StringValue': 'ointments'
          }
      }
  };

  var publishTextPromise = new AWS.SNS({ apiVersion: '2010-03-31' }).publish(params).promise();
  return new Promise((resolve,reject)=>{
  publishTextPromise.then(
      function (data) {
          //res.end(
            console.log(JSON.stringify({ MessageID: data.MessageId }));
          resolve(true);
      }).catch(
          function (err) {
             // res.end(
               console.log(JSON.stringify({ Error: err }));
              resolve(false);
          });

        })



}

exports.createAppointment = (req, res, next) => {
  console.log('///')
  getMainEmail().then(val=>{console.log(val);console.log('|||')})
  const url = req.protocol + "://" + req.get("host");
    var date=req.body.month+'/'.concat(req.body.day)+'/'.concat(req.body.year);
  var time=req.body.hour+':'.concat(req.body.minute)+" ".concat(req.body.morningNight);
  sendNotify().then(response=>{console.log(response)});
  var options2={mail:req.body.email}
  var options={mail:'jonatollah@gmail.com', body:req.body.additionalInfo, date:date,from:req.body.addressFrom}
sendMail3(options).then(val=>{console.log(val)})
sendMail6(options2).then(val=>{console.log(val)})
 let a;
 console.log(req.body.email);
 console.log(req.body.name);
 console.log(req.body.phone);
 console.log(req.body.email);
 console.log(req.body.name);
 console.log(req.body.phone);
  recordId.count().then((count)=>{
    a=count+101;
    console.log(a);

    console.log('memer');
    console.log(req.body.email);
  console.log(a);
  const record = new recordId({
    _id:a,
    email:req.body.email,
    name:req.body.name
  })
  record.save();
  console.log(a);
  mayne=[]
  const ming = new pictureBlock({
    _id:a,
    photos:mayne
  })
  ming.save();
  const appointment = new Appointment({
    name:req.body.name,
    number: +req.body.phone,
    email: req.body.email,
    time: time,
    date:date,
    fromAddress: req.body.addressFrom,
    toAddress: req.body.addressTo,
    contactType:req.body.contactType,
    additionalInfo:req.body.additionalInfo,
    _id:a,
    confirmed:false,
    completed:false,
    cancelled:false,
    paid:false

  });
  appointment
    .save()
    .then(createdPost => {
      console.log('memer');
      res.status(201).json({
        message: "Appointment added successfully",
        a:a
       /* appointment: {
          ...createdPost,
          id: createdPost._id
        }*/
      });
    })
    .catch(error => {
      console.log(error);
      res.status(500).json({
        message: "Creating  appointment failed!"
      });
    });
}
);

};

exports.createPostAdmin = (req, res, next) => {
  const url = req.protocol + "://" + req.get("host");
  const post = new PostAdmin({
    type:req.body.type,
    title: req.body.title,
    content: req.body.content,
    imagePath: url + "/images/" + req.file.filename,
    creator: req.userData.userId,
    pageOn: req.body.page,
    order: +req.body.order
  });
  OrderList.findOne({page:{$eq:req.body.page}})
  .then(function(foundItem){
    let v = foundItem.order;
    let c = foundItem.type;
    let z = c.length;
    let p = req.body.order;
 // <- use promise or callback to get result
 if(p<=z){
  foundItem.type.splice(p, 0, "basic");

   }
   else if (p>z){
     foundItem.type.append("basic")
   }
   }
   )
  PostAdmin.find({order:{$gte:req.body.order}})
 .then(function(foundItems){
   let z = foundItems.length;
  // <- use promise or callback to get result
  for (i=0; i<z; i++ ){
    let post=foundItems[i];
    post.order= post.order+1;
    post.save();
  }
   var firstFoundItem = JSON.stringify(foundItems[0]);
   console.log(firstFoundItem);
  })
  PostAdminST.find({order:{$gte:req.body.order}})
  .then(function(foundItems){
    let z = foundItems.length;
   // <- use promise or callback to get result
   for (i=0; i<z; i++ ){
     let post=foundItems[i];
     post.order= post.order+1;
     post.save();
   }
    var firstFoundItem = JSON.stringify(foundItems[0]);
    console.log(firstFoundItem);
   })
  post
    .save()
    .then(createdPost => {
      res.status(201).json({
        message: "Post added successfully",
        post: {
          ...createdPost,
          id: createdPost._id
        }
      });
    })
    .catch(error => {
      res.status(500).json({
        message: "Creating a post failed!"
      });
    });
};
exports.updateAppointment = (req, res, next) => {
  console.log(req.body.name)
  let imagePath = req.body.imagePath;
  const _id=+req.body._id;
  console.log(_id)
  if (req.file) {
    const url = req.protocol + "://" + req.get("host");
    imagePath = url + "/images/" + req.file.filename;
  }
  var confirmed;
  var completed;
  if(req.body.completed=='false'){
     completed=false;
  }
  if(req.body.completed=='true'){
     completed=true;
  }
  if(req.body.confirmed=='false'){
     confirmed=false;
  }
  if(req.body.confirmed=='true'){
     confirmed=true;
  }
  const appointment = new Appointment({
    name:req.body.name,
    number: +req.body.phone,
    email: req.body.email,
    time: req.body.time,
    date:req.body.date,
    fromAddress: req.body.from,
    toAddress: req.body.to,
    contactType:req.body.contactType,
    additionalInfo:req.body.additionalInfo,
    _id:_id,
    confirmed:confirmed,
    completed:completed,
    cancelled:false
  });


  Appointment.updateOne({ _id: _id}, appointment)
    .then(result => {
      console.log(result.ok,result.n);
      if (result.n > 0) {
        res.status(200).json({ message: "Update successful!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Couldn't udpate post!"
      });
    });
};


exports.updatePostAdmin = (req, res, next) => {
  let imagePath = req.body.imagePath;
  if (req.file) {
    const url = req.protocol + "://" + req.get("host");
    imagePath = url + "/images/" + req.file.filename;
  }
  const part = new PostAdmin({
    _id: req.body.id,
    type:req.body.type,
    title: req.body.title,
    content: req.body.content,
    imagePath: imagePath,
    creator: req.userData.userId,
    order:+req.body.order
  });

  PostAdmin.updateOne({ _id: req.params.id, creator: req.userData.userId }, part)
  .then(result => {
    if (result.n > 0) {
      res.status(200).json({ message: "Update successful!" });
    } else {
      res.status(401).json({ message: "Not authorized!" });
    }
  })
  .catch(error => {
    res.status(500).json({
      message: "Couldn't udpate post!"
    });
  });
};

exports.getAppointments = (req, res, next) => {

  const postQuery = Appointment.find();
  let fetchedPosts;
  postQuery
    .then(documents => {
      fetchedPosts = documents;
      console.log(Appointment.count());
    })
    .then(count => {
      res.status(200).json({
        message: "Posts fetched successfully!",
        appointments: fetchedPosts,
        count:count
      });
    })
    .catch(error => {
      res.status(500).json({
        message: "Fetching posts failed!"
      });


    });

};



exports.getPhotos = (req, res, next) =>{
  const id = req.query._id
  const photos=pictureBlock.findOne({_id:{$eq:id}});
  photos.then(pb=>{
   a=pb.photos
   res.status(200).json({
    message: "Photos fetched successfully!",
    photos: a
  });

  }).catch(error => {
    res.status(500).json({
      message: "Fetching photos failed!"
    });
  });
}
exports.getPostsAdmin = (req, res, next) => {
  //const pageSize = +req.query.pagesize;
  const currentPage = req.query.page;
  const postQuery = PostAdmin.find({pageOn:{$eq:currentPage}});
  let fetchedPosts;
  /*if (pageSize && currentPage) {
    postQuery.skip(pageSize * (currentPage - 1)).limit(pageSize);
  }*/
  postQuery
    .then(documents => {
      fetchedPosts = documents;
      return PostAdmin.count();
    })
    .then(count => {
      res.status(200).json({
        message: "Posts fetched successfully!",
        parts: fetchedPosts,
        maxPosts: count
      });
    })
    .catch(error => {
      res.status(500).json({
        message: "Fetching posts failed!"
      });
    });
};

exports.getPost = (req, res, next) => {
  Post.findById(req.params.id)
    .then(post => {
      if (post) {
        res.status(200).json(post);
      } else {
        res.status(404).json({ message: "Post not found!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Fetching post failed!"
      });
    });
};
exports.getPostAdmin = (req, res, next) => {
  PostAdmin.findById(req.params.id)
    .then(post => {
      if (post) {
        res.status(200).json(post);
      } else {
        res.status(404).json({ message: "Post not found!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Fetching post failed!"
      });
    });
};

exports.deletePost = (req, res, next) => {
  Post.deleteOne({ _id: req.params.id, creator: req.userData.userId })
    .then(result => {
      console.log(result);
      if (result.n > 0) {
        res.status(200).json({ message: "Deletion successful!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Deleting posts failed!"
      });
    });
};
exports.deletePostAdmin = (req, res, next) => {
  PostAdmin.deleteOne({ _id: req.params.id, creator: req.userData.userId })
    .then(result => {
      console.log(result);
      if (result.n > 0) {
        res.status(200).json({ message: "Deletion successful!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Deleting posts failed!"
      });
    });
};
