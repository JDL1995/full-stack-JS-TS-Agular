const stripe = require('stripe')('sk_test_51IdOqiLh3XJnPTEjEJIku6vCMXOpwwH4VOc3kVVy2QfMcp3xrOJzczXtLFAsicGPoeuV9fRWoX99dAsg20SLi5Jt00B3UlDhJH');
var crypto = require("crypto");
const Payment=require("../models/payment");
//var elements = stripe.elements();
var nodemailer = require("nodemailer");
const Testimonial = require("../models/testimonial");

async function sendMail(req,res,next){
  var userMail=req.mail;
  var url=req.url;
  var body=req.body;
  var date=req.date;
  var from=req.to;
   host = '//localhost:4200';
   return new Promise((resolve,reject)=>{
   var transporter = nodemailer.createTransport({ host: "smtp.gmail.com", port:465, secure:true, auth: { user: "jon@jonlathrop.tech", pass: "sjrdgtxtaaiwdciz"}  });
   /*
   transporter.verify(function(error, success) {
     if (error) {
          console.log(error);
     } else {
          console.log('Server is ready to take our messages');
     }
  });*/
   var mailOptions = { from: 'jon@jonlathrop.com', to: userMail, subject: 'Fitzgerald Moving Services', html:'<p>Thank you for Moving with Fitzgerald Moving Services<br>'+'<b>Invoice:</b>'+body+' <br> please click the link to complete payment for the move ' + ' to ' + from +' on '+date+' </p><br>'+url+'<br> Please call us at xxx-xxx-xxxx if you are unable to complete the payment'};
   transporter.sendMail(mailOptions, function (err) {
       if (err){
        console.log("error is "+err);
        resolve(false);
       }
       else{
        console.log('Email sent ');
        resolve(true);
       }
   });
  })
 }


exports.createCharge=(req,res,next)=>{

 stripe.charges.create({
        amount: req.body.amount*100,
        currency: 'usd',
        source: req.body.token,
        description: 'My First Test Charge (created for API docs)',
      }).then(result=>res.status(201).json({message:result}))

}
exports.markComplete=(req,res,next)=>{
  let deemerreeemerheeemer=+req.body._id;
  Payment.findOne({_id:{$eq:deemerreeemerheeemer},token:{$eq:req.body.token}}).then(payment=>{
    payment.paid=true;
    payment.save().then(val=>{
 res.status(200).json({message:'done'})

    })
  }
  ).catch(error => {
     res.status(500).json({
     message: "fuck "
   });
 });
}
exports.getPayment=(req,res,next)=>{
  console.log(req.body.token);
  console.log(req.body._id);
  let deemerreeemerheeemer=+req.body._id;
  Payment.findOne({_id:{$eq:deemerreeemerheeemer},token:{$eq:req.body.token}}).then(payment=>{
    res.status(200).json({payment:payment})
  }
  ).catch(error => {
     res.status(500).json({
     message: "getting payment failed! "
   });
 });
}
/*
exports.createIntent = (req, res, next) => {
    var price = req.body.amount;
    // Create a PaymentIntent with the order amount and currency
    const paymentIntent = await stripe.paymentIntents.create({
      amount: price,
      currency: "usd"
    });
    res.send({
        clientSecret: paymentIntent.client_secret
      });

}
*/


exports.sendInvoice=(req,res,next)=>{

  var token=crypto.randomBytes(16).toString('hex');
  console.log(token);

  var url="http://localhost:4200/appointments/"+req.body._id+'/'+token;
  a = new Payment({_id:req.body._id,token:token,amount:req.body.price,paid:false,information:req.body.body,email:req.body.email })
  var options={url:url,mail:req.body.email, body:req.body.body, date:req.body.date,to:req.body.address}
  a.save().then(sendMail(options).then(result =>
    {
    console.log(result);
    if (result  ==true){
      console.log('anally true')

       res.status(201).json({
        message: "Success! Confrimation Email sent to "+req.body.email
      });
    }
    if (result  ==false){
      res.status(402).json({
        message: "sending the email failed! Check that it is a valid Email Address"
      });
    console.log('anally false');
    }
  // let b= MakeQuerablePromise(result);
   console.log('anal mcgee');
   console.log('|');
   console.log('|');
   console.log('|');
   //onsole.log("Final fulfilled: ", b.isFulfilled());
 // console.log("Final rejected: ", b.isRejected());
    console.log(result);
  })).catch(error => {
    res.status(500).json({
     message: "Couldn't save Payment"
   });
 })
}
exports.getPayments = (req,res,next) =>{
  const query=Payment.find();
  query.then(documents=>{
    res.status(201).json({payment:documents})
  }).catch(error=>{
    console.log(error)
  })
}
exports.pay = (req, res, next) => {
    var cardElement = elements.create('card');
    stripe.customers
    .create({
      email: 'customer@example.com',
      id:1001
    })
    .then((customer) => {
      // have access to the customer object
      return stripe.invoiceItems
        .create({
          customer: customer.id, // set the customer id
          amount: 2500, // 25
          currency: 'usd',
          description: 'One-time setup fee',
        })
        .then((invoiceItem) => {
          return stripe.invoices.create({
            collection_method: 'send_invoice',
            customer: invoiceItem.customer,
          });
        })
        .then((invoice) => {
            console.log('got it')
          // New invoice created on a new customer
        })
        .catch((err) => {
          // Deal with an error
        });
    });
  }
  exports.paymentCompleted=(req,res,next)=>{
    var token=crypto.randomBytes(16).toString('hex');
    console.log(token);
    console.log(req.body.email);

    var url="http://localhost:4200/testimonials/make/"+token+'/'+req.body.email;
    let a={mail:req.body.email,amount:req.body.amount,url:url}
    const test=new Testimonial({token:token,email:req.body.email,name:' ',date:'',testimony:' ',image:' ',isVisible:false})
    test.save().catch(error=>{console.log(error); res.status(500).json({message:'failed to make new blank Testimonial'})})
    sendMail5(a).then(resp=>{
      res.status(201).json({message:'success'})
    }).catch(error=>{
      res.status(500).json({message:'failure'})
    })


  }

  sendMail5= async(req)=>{
    let resp= await sendMail4(req);
    // log or process resp;
     return resp;
  }
   async function sendMail4(req,res,next){
    var userMail=req.mail;
    var amount=req.amount;
    var url=req.url;
    var from=req.from;
     host = '//localhost:4200';
     return new Promise((resolve,reject)=>{
     var transporter = nodemailer.createTransport({ host: "smtp.gmail.com", port:465, secure:true, auth: { user: "jon@jonlathrop.tech", pass: "sjrdgtxtaaiwdciz"}  });
     /*
     transporter.verify(function(error, success) {
       if (error) {
            console.log(error);
       } else {
            console.log('Server is ready to take our messages');
       }
    });*/
     var mailOptions = { from: 'jon@jonlathrop.tech', to: userMail, subject: 'Payment Confirmation ', html:'<p>Your card payment to Fitzgerald moving services has been completed for the amount: ' + amount + '<br> We invite you to create a personal review to go on our website by clicking the following link: '+url+` </p>'+'<br> Thank you for your business <br> Fitzgerald Moving Services <br> xxx-xxx-xxxx <br> www.fitzgeraldmovingservices.com '`};
     transporter.sendMail(mailOptions, function (err) {
         if (err){
          console.log("error is "+err);
          resolve(false);
         }
         else{
          console.log('Email sent ');
          resolve(true);
         }
     });})


   }
