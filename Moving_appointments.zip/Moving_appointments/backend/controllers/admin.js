const BlogInfo = require("../models/bloginfo");
const PostAdminST=require("../models/postAdminST");
const PostAdmin=require('../models/postAdmin');
const OrderList=require('../models/orderlist');
exports.updateBlogInfo= (req, res, next) => {
    BlogInfo.findOne({page:{$eq:req.body.page}}).then((bloginfo=>{
        bloginfo.title=req.body.title;
       bloginfo.save()
       .then((result)=>{
        if (!result.writeError) {
            res.status(200).json({ message: "Update successful!" });
          } else {
            res.status(401).json({ message: "Not authorized!" });
          }
        })
        .catch(error => {
          res.status(500).json({
            message: "Couldn't udpate post!"+bloginfo._id
          });
        });

       }))
       

    }
  

  exports.getPosts = (req, res, next) => {
    const page = req.query.page;
    const postQuery = BlogInfo.find({page:{$eq:page}});
    /*const postQuery = BlogInfo.find({page:{$eq:page}},{$exists: true}).toArray(function(err,doc){
        if(doc){
            res.status(200).json({
                message: "Posts fetched successfully!",
                bloginfo: fetchedPosts
                
              });
        }
        else if(!doc){
            res.status(200).json({
            message: "Fetching posts failed! no posts to fetch"
        });
        }
    })*/
    let fetchedPosts;

    postQuery
      .then(documents => {
        fetchedPosts = documents;
        return BlogInfo.count();
      })
      .then(count => {
        res.status(200).json({
          message: "Posts fetched successfully!",
          bloginfo: fetchedPosts
        });
      })
      .catch(error => {
        res.status(500).json({
          message: "Fetching posts failed!"
        });
      });

  };

  exports.getBlogInfo = (req, res, next) => {
     let anus=req.query.page;
    BlogInfo.findOne({page:{$eq:req.query.page}})
      .then(bloginfo => {
        if (bloginfo) {
          res.status(200).json(bloginfo);
        } else {
          res.status(404).json({ message: anus });
        }
      })
      .catch(error => {
        res.status(500).json({
          message: anus
        });
      });
  };
  exports.createBlogInfo = (req, res, next) => {
      let analstring=req.body.title;
      let analsting=req.body.page;
    const blogInfo = new BlogInfo({
      page: analsting,
      title: analstring
    });
    blogInfo.save().then(createdInfo => {

        res.status(201).json({
          message: "Info added successfully",
          blogInfo: {
            page:'anal',
            title:'anal'
          }
        });
      })
      .catch(error => {
        res.status(500).json({
          message: analsting
        });
      });
  };
 exports.instOrderList = (req,res,next)=>{

     jt=req.body.page;
    const j = new OrderList({
        page:jt,
        type:['1']
    });
    j.save().then(val => {
    res.status(200).json({
        message: "list created successfully!"
      }
      );
      }).catch(error => {
        res.status(500).json({
          message: "Creating a list failed!" + jt 
        });
      });

 }

  exports.getOrderList = (req,res,next)=>{
const page=req.query.page;
    OrderList.findOne({page:{$eq:page}})
    .then(items => {
        let vam=items.type;
        res.status(200).json({
          message: "orderlist fetched successfully!",
          orderlist: items
        });
      }).catch(error => {
        res.status(500).json({
          message: "finding orderlist failed anally!"
        });
      });

      
  }

  exports.createPostAdminST = (req, res, next) => {
    const url = req.protocol + "://" + req.get("host");
    const post = new PostAdminST({
      type:req.body.type,
      title: req.body.title,
      subtitle:req.body.subtitle,
      content: req.body.content,
      imagePath: url + "/images/" + req.file.filename,
      creator: req.userData.userId,
      pageOn: req.body.page,
      order:+req.body.order
    });
    const localOrder=
    OrderList.findOne({page:{$eq:req.body.page}})
    .then(function(foundItem){ 
      let v = foundItem.order;
      let c = foundItem.type;
      let z = c.length;
      let p = +req.body.order;
   // <- use promise or callback to get result
   if(p<=z){
    foundItem.type.splice(p, 0, "st");
  
  }
     else if (p>z){
       foundItem.type.append("st");
     }
     }
     ).catch(error=>{
      res.status(500).json({
        message: "finding a list failed!"
     })})

    PostAdmin.find({order:{$gte:+req.body.order}})
   .then(function(foundItems){ 
     let z = foundItems.length;
    // <- use promise or callback to get result
    for (i=0; i<z; i++ ){
      let post=foundItems[i];
      post.order= post.order+1;
      post.save();
    }
     var firstFoundItem = JSON.stringify(foundItems[0]);
     console.log(firstFoundItem);
    }).catch(error=>{
      res.status(500).json({
        message: "finding a PostAdmin Order failed!"
     })})

    PostAdminST.find({order:{$gte:+req.body.order}})
    .then(function(foundItems){ 
      let z = foundItems.length;
     // <- use promise or callback to get result
     for (i=0; i<z; i++ ){
       let post=foundItems[i];
       post.order= post.order+1;
       post.save();
     }
      var firstFoundItem = JSON.stringify(foundItems[0]);
      console.log(firstFoundItem);
     }).catch(error=>{
      res.status(500).json({
        message: "finding a PostAdmin Order failed!"
     })})
    post
      .save()
      .then(createdPost => {
        res.status(201).json({
          message: "Post added successfully",
          post: {
            ...createdPost,
            id: createdPost._id
          }
        });
      })
      .catch(error => {
        res.status(500).json({
          message: "Creating a post failed anally!"
        });
      });
  };
  exports.updatePostAdminST = (req, res, next) => {
    let imagePath = req.body.imagePath;
    if (req.file) {
      const url = req.protocol + "://" + req.get("host");
      imagePath = url + "/images/" + req.file.filename;
    }
    const part = new PostAdminST({
      _id: req.body.id,
      type:req.body.type,
      title: req.body.title,
      subtitle:req.body.subtitle,
      content: req.body.content,
      imagePath: imagePath,
      creator: req.userData.userId,
      order:+req.body.order
    });
    PostAdminST.updateOne({ _id: req.params.id, creator: req.userData.userId }, part)
    .then(result => {
      if (result.n > 0) {
        res.status(200).json({ message: "Update successful!" });
      } else {
        res.status(401).json({ message: "Not authorized!" });
      }
    })
    .catch(error => {
      res.status(500).json({
        message: "Couldn't udpate post!"
      });
    });
  };

  exports.getPostsAdminST = (req, res, next) => {
    //const pageSize = +req.query.pagesize;
    const currentPage = req.query.page;
    const postQuery = PostAdminST.find({pageOn:{$eq:currentPage}});
    let fetchedPosts;
    /*if (pageSize && currentPage) {
      postQuery.skip(pageSize * (currentPage - 1)).limit(pageSize);
    }*/
    postQuery
      .then(documents => {
        fetchedPosts = documents;
        return PostAdminST.count();
      })
      .then(count => {
        res.status(200).json({
          message: "Posts fetched successfully!",
          partsST: fetchedPosts
        });
      })
      .catch(error => {
        res.status(500).json({
          message: "Fetching posts failed!"
        });
      });
  };
  exports.getPostAdminST = (req, res, next) => {
    PostAdminST.findById(req.params.id)
      .then(post => {
        if (post) {
          res.status(200).json(post);
        } else {
          res.status(404).json({ message: "Post not found!" });
        }
      })
      .catch(error => {
        res.status(500).json({
          message: "Fetching post failed!"
        });
      });
  };
  exports.deletePostAdminST = (req, res, next) => {
    PostAdminST.deleteOne({ _id: req.params.id, creator: req.userData.userId })
      .then(result => {
        console.log(result);
        if (result.n > 0) {
          res.status(200).json({ message: "Deletion successful!" });
        } else {
          res.status(401).json({ message: "Not authorized!" });
        }
      })
      .catch(error => {
        res.status(500).json({
          message: "Deleting posts failed!"
        });
      });
  };

  /*  BlogInfo.replaceOne({ _id:{$eq:bloginfo._id }}, blog)
        .then(result => {
          if (result.n > 0) {
            res.status(200).json({ message: "Update successful!" });
          } else {
            res.status(401).json({ message: "Not authorized!" });
          }
        })
        .catch(error => {
          res.status(500).json({
            message: "Couldn't udpate post!"+bloginfo._id
          });
        });*/

        exports.getOrderSelect = (req, res, next) => {
            let page = req.body.page;
            
          
          }