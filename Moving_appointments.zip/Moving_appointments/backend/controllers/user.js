const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Token = require("../models/token");
const User = require("../models/user");
var nodemailer = require("nodemailer");
var crypto = require("crypto");
const Toker = require("../models/tokemeister");
const OneTime=require("../models/oneTime");
var mongoose = require("mongoose");
const JWT_KEY="secret_this_should_be_longer";


exports.addAOneTime= (req, res, next) => {
  var j = new OneTime({Once:false});
  j.save();
  res.status(201).json({message:"go"})
  
}

exports.oneTime= (req, res, next) => {

  OneTime.findOne().then(function(foundItem){ 
    if(!foundItem){
      res.status(201).json({message:"nyet"})
    }
 else if(foundItem.Once==false){
    foundItem.Once=true;
    foundItem.save();
  res.status(201).json({message:"go"})
  }
  else{
    res.status(201).json({message:"stop"})
  }

  })
 
}
exports.confirmAppointment=(req,res,next) =>{
  var j = new Toker;
  j.mail=req.body.email;
  j.token=req.body
  j.phoneNumber=req.body.number;
  j.contactType=req.body.contactType;

  var token = new Token({ _userId: user._id, token: crypto.randomBytes(16).toString('hex') });



}
exports.resetPassword= (req, res, next) => {
  var j = new Toker;
  j.mail=req.body.email;
  let fetchedUser;
  User.findOne({ email: req.body.email })
    .then(user => {
      if (!user) {
        return res.status(401).json({
          message: "User Does Not Exist with that email"
        });
      }
      var token = new Token({ _userId: user._id, token: crypto.randomBytes(16).toString('hex') });
      j.toke=token.token;
      j.type='reset';
      token.save()
      .then(sendMail(j)).then(result => {
        res.status(201).json({
          message: "Success! Password Reset email sent to: " + j.mail + '.',
          result: result
        });
      })
      fetchedUser = user;
    });
  }

function sendMail(req,res,next){
 var userMail=req.mail;
 var tokier=req.toke;
 var type=req.type;
 var specvar;
 var host;
 var textVar;
 var superSpecvar;
 if (type=='reset')
 {
   specvar='/auth/reset8732iuryfds7i4uhf78h24fksdhf2iuh824844858792/';
   textVar='reset your password by clicking the following link: ';
 }
 if (type=='create')
 {
  specvar='/auth/confirm957439920458714/';
  textVar='You may confirm your account by clicking the following link: ';

}
 else if (type=='appointmentConfirmation'){
specvar='/confirmation/';

zz=req.contactType
a="call you at the phone number "
b="text you at the phone number "

c=req.phonenumber

phonenumber=req.
textVar='Your moving appointment with Fitzgerald Moving Services has been registered!  We will  '+' to confirm the appointment:';
  }

  host = '//localhost:4200';
  
  var transporter = nodemailer.createTransport({ host: "smtp.gmail.com", port:465, secure:true, auth: { user: "jon@jonlathrop.tech", pass: "sjrdgtxtaaiwdciz"}  });
  /*
  transporter.verify(function(error, success) {
    if (error) {
         console.log(error);
    } else {
         console.log('Server is ready to take our messages');
    }
 });*/

  var mailOptions = { from: 'jon@jonlathrop.com', to: userMail, subject: 'Fitzgerald Moving Services', html: textVar +'<p><a href= "http:' + host + specvar + userMail + '/' + tokier + '"> here</a> </p>'};
  transporter.sendMail(mailOptions, function (err) {
      if (err){

        return res.status(402).json({message:"failed to mail"})
          console.log(err);

      }
      else{

          res.status(201).json({message:"success"});

      }


  });

  
}
exports.checkToken = (req, res, next) => {
  let val=req.body.token;
  Token.findOne({token:val}).then(tokke=>{
    let bastard = tokke.createdAt;
    console.log(bastard);
    return res.status(201).json({createdAt:bastard})
  })
}
exports.createUser = (req, res, next) => {

  User.findOne({email: req.body.email}).then(user=>{

    if(user) {
      return res.status(400).json({message: "account already exists"});
       }
       })
  var j = new Toker;
  j.mail=req.body.email;
  j.type='create';
  bcrypt.hash(req.body.password, 10).then(hash => {
    const user = new User({
      email: req.body.email,
      password: hash,
      phoneNumber:req.body.phone
    });
    var token = new Token({ _userId: user._id, token: crypto.randomBytes(16).toString('hex') });
    j.toke=token.token;
    token.save();
    user
      .save()
      .then(sendMail(j)).then(result => {
        res.status(201).json({
          message: "User created! Verification email sent to: " + j.mail + '.',
          result: result
        });
      })
  });
}

exports.userLogin = (req, res, next) => {
  let fetchedUser;
  User.findOne({ email: req.body.email })
    .then(user => {
      if (!user) {
        return res.status(401).json({
          message: "Auth failed"
        });
      }
      if(user.isVerified==false){
        return res.status(401).json({
          message: "User Not Verified, check email"
        });
      }
      fetchedUser = user;
      return bcrypt.compare(req.body.password, user.password);
    })
    .then(result => {
      if (!result) {
        return res.status(401).json({
          message: "Auth failed"
        });
      }
      const token = jwt.sign(
        { email: fetchedUser.email, userId: fetchedUser._id },
        JWT_KEY,
        { expiresIn: "1h" }
      );
      res.status(200).json({
        token: token,
        expiresIn: 3600,
        userId: fetchedUser._id,
        isAdmin:fetchedUser.isAdmin
      });
    })
    .catch(err => {
      return res.status(401).json({
        message: "Invalid authentication credentials!"
      });
    });
  }

  exports.confirmEmail=(req, res, next)=>{
    var temp = mongoose.Types.ObjectId();
    //var token = req.body.token;
    Token.findOne({ token: req.body.token})
    .then(token=>{
        if (!token){
            return res.status(400).json({message:'your verification link may have expired, please click on resend for a new link'});
        }
        else{
            temp=token._userId;}});       
    User.findOne({email: req.body.email})
    .then(user => {
            if (!user){
                return res.status(401).json({message:'we were unable to find a user for this verification, please sign up'});
                }
            else if (user.isVerified){
                return res.status(200).json({message:'User has been already verified.  Please Login'});
                }
            else{
              if (req.body.email="jond99@protonmail.com"){
                user.isAdmin=true;
              }
                user.isVerified = true;
                user.save(function (err) {
                    if(err){
                        return res.status(500).json({message: err.message});
                    }
                    else{
                        return res.status(200).json({message:'your account has been successfully verified'});
                          }
                      });
                }
            });
        }

  exports.confirmReset=(req, res, next)=>{
    let fetchedUser;
    let pw = req.body.password;
    var temp = mongoose.Types.ObjectId();
    //var token = req.body.token;
    Token.findOne({ token: req.body.token})
    .then(token=>{
        if (!token){
            return res.status(400).json({message:'your verification link may have expired, please click on resend for a new link'});
        }
        else{
            temp=token._userId;}});       
    User.findOne({email: req.body.email})
    .then(user => {
      fetchedUser=user;
            if (!user){
                return res.status(401).json({message:'we were unable to find a user for this verification, please sign up'});
                }
            else{
              bcrypt.hash(pw, 10).then(hash => {
                  user.password=hash;
              
                user.save(function (err) {
                    if(err){
                        return res.status(500).json({message: err.message});
                    }
                    else{
                       res.status(200).json({message:'your password has been successfully reset'});
                         
                      }
                })})
            }
        });
      }