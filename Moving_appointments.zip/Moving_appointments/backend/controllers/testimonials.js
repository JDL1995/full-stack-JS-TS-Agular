const testimonial=require("../models/testimonial");
const Hero=require("../models/hero")
var ObjectId = require('mongodb').ObjectID;
exports.postTestimonials = (req, res, next) => {
console.log(req.body.hero);
testimonial.findOne({_id:req.body._id}).then(testimonial=>{

    if (req.body.hero){
        console.log(req.body.hero)
        Hero.findOne({_id:req.body.hero._id}).then(hero=>{
        testimonial.name=req.body.name,
        testimonial.date=req.body.date,
        testimonial.testimony=req.body.body,
        testimonial.image=req.body.hero,
        testimonial.isVisible=true})
        testimonial.save().then(result=>{
            res.status(201).json({message:'success'})
        })
        }
        
    else{

        testimonial.name=req.body.name,
        testimonial.date=req.body.date,
        testimonial.testimony=req.body.body
        testimonial.isVisible=true
      testimonial.save().then(resp=>{
            res.status(201).json({message:'success'});
        })
    }
      

    }
   ).catch(error=>{
       console.log(error)
       res.status(500).json({message:'failed to find testimonial'})
   })

}
    
 

    exports.withImage=(req,res,next)=>{
        console.log(req.body._id)
        let a =new ObjectId(req.body._id)
        testimonial.findOne({_id:a}).then(testimonial=>{
        testimonial.name=req.body.name,
        testimonial.date=req.body.date,
        testimonial.testimony=req.body.body
        testimonial.isVisible=true
      testimonial.save().then(resp=>{
            res.status(201).json({_id:resp.id})
        })}).catch(error=>{
            console.log(error)
            res.status(500).json({message:'failed'})
        })

    }
    exports.withImage2=(req,res,next)=>{
        const url = req.protocol + "://" + req.get("host");

        let next1 = url.concat("/images/"+req.file.filename);
        console.log(next1);
        testimonial.findOne({_id:req.body.id}).then(testimonial=>{
            console.log(testimonial);
            testimonial.image=next1
            testimonial.save().then(resp=>{
                res.status(201).json({message:'success!'})
            })

        }).catch(error=>{
            console.log(error);
        })
       

    }
    exports.getSingle=(req,res,next)=>{
        testimonial.findOne({token:req.body.token,email:req.body.email}).then(testimonial=>{
            res.status(201).json({_id:testimonial._id})
        }).catch(error=>{
            res.status(500).json({message:'failed to find testimonial'})
        })
    }
    
    exports.getTestimonials = (req, res, next) => {
        let testimonials=[];
        const postQuery = testimonial.find();
        let fetchedPosts;
        postQuery
          .then(documents => {
            fetchedPosts = documents;
            fetchedPosts.forEach(value=>{
                console.log(value)
                if (value.isVisible==true){
                    testimonials.push(value);
                }
            })
                res.status(200).json({
                    message: "testimonials fetched successfully!",
                    testimonials: testimonials
                  });
            
          }).catch(error => {
              console.log(error);
            res.status(500).json({
              message: "Fetching testimonials failed!"
            });
          });
      };
      
      
      exports.changeVisibility = (req, res, next) => {
          console.log(req.body.idList)
        req.body.idList.forEach(value=>{
            testimonial.findOne({_id:value}).then(testimonial=>{
                console.log(testimonial)
                if(testimonial.isVisible==true){
                    testimonial.isVisible=false
                }
                else if(testimonial.isVisible==false){
                    testimonial.isVisible=true
                }
                testimonial.save()
            })
            
        })
        res.status(201).json({message:'success'}) 

      }

      exports.getTestimonialsAdmin = (req, res, next) => {
        
        const postQuery = testimonial.find();
        let fetchedPosts;
        postQuery
          .then(documents => {
            fetchedPosts = documents;
            
                res.status(200).json({
                    message: "testimonials fetched successfully! for admin",
                    testimonials: fetchedPosts
                  });
            
          }).catch(error => {
              console.log(error);
            res.status(500).json({
              message: "Fetching testimonials failed!"
            });
          });
      };



exports.runTheHeroes=(req,res,next)=>{
var titleList=["pleased-ok-guy","beared-middle-age","blissful-latina","cheerful-black-girl","cheerful-black-man","happy-couple","confident-businessman","serene-blonde","harry-potter","smiling-hero-man","young-asian-girl","happy-arm-crossed-man","cool-shy-chick","female-student","whiskey-businessman","older-american-woman"];
var b=titleList.length;
var respond=false;
titleList.forEach((value, index) => {
    let img="http://localhost:3000/images/"+value+".jpg";
    let a = new Hero({_id:value,picture:img});
    a.save();
    if(index==(b-1)){
        respond=true;

    }
})
if(respond==true){
res.status(200).json({message:'Heroes have been run'})
}

}

exports.getAHero=(req,res,next)=>{
    Hero.findOne({_id:req.body._id}).then(hero=>{
        res.status(201).json({hero})
    })
}

exports.getHeroes = (req, res, next) => {
console.log('anal');
    const postQuery = Hero.find();
    let heroes;
    postQuery
      .then(documents => {
          console.log(documents)
        heroes = documents;
        //console.log(Appointment.count());

      }).then(val=>{
        res.status(200).json({
            message: "Heroes fetched successfully!",
            Heroes: heroes
          });
      }).catch(error => {
        res.status(500).json({
          message: "Fetching posts failed!"
        });
      });
  };