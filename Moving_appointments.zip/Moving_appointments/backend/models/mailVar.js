class Mailvar{
    

}
module.exports= Mailvar;