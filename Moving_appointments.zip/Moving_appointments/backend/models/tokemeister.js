
class Toker{
    constructor(toke,mail,type,phoneNumber,contactType){
        this.toke=toke;
       this.mail= mail;
        this.type=type;
        this.phoneNumber=phoneNumber;
        this.contactType=contactType;

    }
   
}
module.exports = Toker;