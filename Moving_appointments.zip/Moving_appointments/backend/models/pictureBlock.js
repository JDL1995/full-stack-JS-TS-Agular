const mongoose = require("mongoose");

const pictureBlock = mongoose.Schema({
    _id:{type:Number, required: true },
    photos:{type:[String], required: true }
});

module.exports = mongoose.model("pictureBlock", pictureBlock);
