const mongoose = require("mongoose");

const postSchema = mongoose.Schema({
  type: { type: String, required: true },
  title: { type: String, required: true },
  content: { type: String, required: true },
  imagePath: { type: String, required: true },
  creator: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  pageOn:{type: String, required:true },
  order:{ type: Number, required:true}
});

module.exports = mongoose.model("PostAdminST", postSchema);
