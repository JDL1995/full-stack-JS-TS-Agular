const mongoose = require("mongoose");

const appointmentSchema = mongoose.Schema({
  name: { type: String, required: true },
  number: { type: Number, required: true },
  email: { type: String, required: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  contactType: { type: String, required: true },
  fromAddress: { type: String, required: true },
  toAddress: { type: String, required: true },
  additionalInfo:{ type:String, required: false},
  _id: { type:Number, required: true},
  confirmed: { type:Boolean, required: true},
  completed: { type:Boolean, required: true},
  cancelled:{type:Boolean,required:true},
  paid:{type:Boolean,required:true}

});

module.exports = mongoose.model("Appointment", appointmentSchema);
