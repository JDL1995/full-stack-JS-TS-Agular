const mongoose = require("mongoose");

const testimonial = mongoose.Schema({
    token:{type:String,required:true},
    email:{type:String,required:true},
    name:{type:String, required:true},
    date:{ type:String, required: false },
    testimony:{type:String, required: true },
    image:{type:String,required:false},
    isVisible:{type:Boolean, required:true}
});

module.exports = mongoose.model("testimonial", testimonial);
