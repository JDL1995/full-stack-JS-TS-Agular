const mongoose = require("mongoose");

const orderListSchema = mongoose.Schema({
    page:{type:String, required:true},
    type:{ type:[String], required: true }
});

module.exports = mongoose.model("OrderList", orderListSchema);
