const mongoose = require("mongoose");

const payment = mongoose.Schema({
    _id:{type:Number, required:true},
    email:{type:String, required:true},
    token:{type:String, required:true},
    information:{type:String, required:true},
   paid:{type:Boolean, required:true},
   amount:{type:Number, required:true}
});

module.exports = mongoose.model("payment", payment);
