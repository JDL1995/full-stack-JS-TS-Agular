const mongoose = require("mongoose");

const onetime = mongoose.Schema({
   Once:{type:Boolean, required:true}
});

module.exports = mongoose.model("OneTime", onetime);
