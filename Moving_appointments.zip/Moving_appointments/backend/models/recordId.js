const mongoose = require("mongoose");

const recordId = mongoose.Schema({
    email:{type:String, required:true},
    name:{ type:String, required: true },
    _id:{type:Number, required: true }
});

module.exports = mongoose.model("recordId", recordId);
