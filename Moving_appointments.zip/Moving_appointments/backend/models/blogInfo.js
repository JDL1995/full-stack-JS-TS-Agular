const mongoose = require("mongoose");

const blogInfoSchema = mongoose.Schema({
    page:{type:String, required:true},
  title:{ type: String, required: true }
});

module.exports = mongoose.model("BlogInfo", blogInfoSchema);
