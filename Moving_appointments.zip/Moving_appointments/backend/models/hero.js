const mongoose = require("mongoose");

const HeroSchema = mongoose.Schema({
    _id:{type:String, required:true},
    picture:{ type:String, required: true }
});

module.exports = mongoose.model("Hero", HeroSchema);
