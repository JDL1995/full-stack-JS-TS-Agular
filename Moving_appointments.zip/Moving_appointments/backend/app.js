const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const confirmRoutes=require("./routes/confirm")
const adminRoutes=require("./routes/administrate");
const postsRoutes = require("./routes/posts");
const userRoutes = require("./routes/user");
const confirmRoute = require("./routes/confirma");
const payRoute = require("./routes/pay");
const dateRoute = require("./routes/date");
const testimonials = require("./routes/testimonials");
//const userRoutes = require("./routes/user");
//const adminRoutes = require("./routes/admin");
const app = express();
const uri='mongodb://superuser:password@127.0.0.1:27017/admin'
const g="mongodb+srv://jon:jon@cluster0.n3aai.mongodb.net/Senor?retryWrites=true&w=majority"
mongoose
  .connect('mongodb://localhost:27017/test', {useNewUrlParser: true})
  .then(() => {
    console.log("Connected to database!");
  })
  .catch(() => {
    console.log("Connection failed!");
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use("/images", express.static(path.join(__dirname, "images")));
//app.use("/",express.static(path.join(__dirname, "angular")));
//app.options('*', function (req,res) { res.sendStatus(200); });
app.use((req, res, next) => {
  
 
  //console.log(req.headers);
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Origin", "http://localhost:4200");
  res.setHeader(
    "Access-Control-Allow-Headers","*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
 // res.setHeader("Access-Control-Expose-Headers");
  
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PATCH, PUT, DELETE, OPTIONS"
  );
  /*
  if ('OPTIONS' === req.method) {
    //respond with 200
    res.send(200);
  }*/
 
  /*
  if ('GET' === req.method) {
    //respond with 200
    res.send(200);
  }*/

  next();
});

app.use("/dates", dateRoute);
app.use("/admin", adminRoutes);
app.use("/users", confirmRoutes);
app.use("/api/appointments", postsRoutes);
app.use("/api/confirm", confirmRoute);
app.use("/user", userRoutes);
app.use("/api/pay", payRoute);
app.use("/api/getOne", payRoute);
app.use("/api/testimonials",testimonials);


//app.use("/api/admin", adminRoutes);


module.exports = app;
