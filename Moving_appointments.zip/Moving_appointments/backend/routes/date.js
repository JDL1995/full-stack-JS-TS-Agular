const express = require("express");
const checkAuth = require("../middleware/check-auth");
const dateController = require("../controllers/date");
const extractFile = require("../middleware/file");

//const checkAuth = require("../middleware/check-auth");
//const extractFile = require("../middleware/file");

const router = express.Router();


router.get("", dateController.getDates);

module.exports = router;
