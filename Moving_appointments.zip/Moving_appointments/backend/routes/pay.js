const express = require("express");
const checkAuth = require("../middleware/check-auth");
const payController = require("../controllers/pay");
const extractFile = require("../middleware/file");
const PostController = require("../controllers/posts");
const router = express.Router();
router.post("",payController.pay);
router.post("/charge",payController.createCharge)
router.post("/get",payController.getPayment)
router.get("/appointment", PostController.getAppointment);
router.post("/gorilla",payController.sendInvoice);
router.post("/jdflakcj28vlk4v84vj9",payController.markComplete);
module.exports = router;