const express = require("express");
const checkAuth = require("../middleware/check-auth");
const PostController = require("../controllers/posts");
const extractFile = require("../middleware/file");

//const checkAuth = require("../middleware/check-auth");
//const extractFile = require("../middleware/file");

const router = express.Router();

router.post("",PostController.appointmentConfirm);

module.exports = router;
