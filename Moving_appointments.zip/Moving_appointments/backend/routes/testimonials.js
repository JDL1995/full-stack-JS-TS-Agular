const express = require("express");
const checkAuth = require("../middleware/check-auth");
const testController = require("../controllers/testimonials");
const extractFile = require("../middleware/file");

//const checkAuth = require("../middleware/check-auth");
//const extractFile = require("../middleware/file");

const router = express.Router();

router.post("",testController.postTestimonials);
router.get("",testController.getTestimonials);
router.get("/admin",testController.getTestimonialsAdmin);
router.post("/change",testController.changeVisibility);
router.post("/getSingle",testController.getSingle);
router.post("/withHero",testController.postTestimonials);
router.post("/withImage",testController.withImage);
router.post("/withImage2",extractFile,testController.withImage2);
router.get("/heroes",testController.getHeroes);
router.post("/heroes",testController.runTheHeroes);
router.post("/heroes/one",testController.getAHero);
module.exports = router;
