const express = require("express");

const UserController = require("../controllers/user");


const router = express.Router();

router.post('/confirmation', UserController.confirmEmail);

router.post('/reset/resetit', UserController.resetPassword);

router.post('/reset/confirmit', UserController.confirmReset);
router.post("/checkToken",UserController.checkToken)



module.exports = router;