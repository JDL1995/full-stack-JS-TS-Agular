const express = require("express");
const checkAuth = require("../middleware/check-auth");
const extractFile = require("../middleware/file");
const adminController = require("../controllers/admin");


const router = express.Router();

router.post("", checkAuth, adminController.createBlogInfo);

router.put("", checkAuth, adminController.updateBlogInfo);

router.get("", adminController.getPosts);

router.post("/st", checkAuth, extractFile, adminController.createPostAdminST);

router.put("/st/:id", checkAuth, extractFile, adminController.updatePostAdminST);

router.get("/st", adminController.getPostsAdminST);

router.get("/list", adminController.getOrderList);

router.get("/st/:id", checkAuth, extractFile, adminController.getPostAdminST);

router.delete("/st/:id", checkAuth, extractFile, adminController.deletePostAdminST);


router.post("/list/inst", checkAuth, adminController.instOrderList);

module.exports=router;