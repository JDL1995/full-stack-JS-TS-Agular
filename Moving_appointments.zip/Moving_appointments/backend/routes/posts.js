const express = require("express");
const checkAuth = require("../middleware/check-auth");
const PostController = require("../controllers/posts");
const extractFile = require("../middleware/file");
const payController = require("../controllers/pay");

//const checkAuth = require("../middleware/check-auth");
//const extractFile = require("../middleware/file");

const router = express.Router();

router.post("",PostController.createAppointment);
router.put("",checkAuth,PostController.updateAppointment);
router.post("/photos",extractFile,PostController.postPhotos);
router.post("/complete",payController.paymentCompleted);
router.post("/setpaid",PostController.setPaid);
router.get("/payments",payController.getPayments);
router.get("/photos",checkAuth,PostController.getPhotos);
router.get("",checkAuth, PostController.getAppointments);
//router.get("/dates", PostController.getDates);
router.post("/gorilla",extractFile,PostController.postPhotos);
router.post("/cancel",checkAuth,PostController.cancelAppointment);
router.post("/complete1",PostController.completeAppointment);
module.exports = router;
